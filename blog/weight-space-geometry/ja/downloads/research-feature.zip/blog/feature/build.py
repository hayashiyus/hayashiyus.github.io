#!/usr/bin/env python3
"""Build the self-contained English research feature from research.md + manifest metadata."""
from pathlib import Path
from package_feature import public_text
from figure_math_captions import render_caption
from functools import lru_cache
import html, json, re, shutil, subprocess, hashlib
import markdown

ROOT=Path(__file__).resolve().parent; OUT=ROOT/'site'; ASSET_SRC=ROOT/'assets'; MANIFEST=ASSET_SRC/'figures.json'; DRAFT=ROOT/'research.md'
def safe(s): return html.escape(s, quote=True)
def dimension(value, fallback):
    try: value=int(value)
    except (TypeError, ValueError): return fallback
    return value if value > 0 else fallback
def load_manifest():
    if not MANIFEST.exists(): return {}
    raw=json.loads(MANIFEST.read_text()); rows=raw.get('figures',raw) if isinstance(raw,dict) else raw
    return {x.get('id'):x for x in rows if isinstance(x,dict) and x.get('id')}
def asset_path(data, key='file'):
    fn=data.get(key) if data else None
    if isinstance(fn,dict): fn=fn.get('file') or fn.get('path')
    return ASSET_SRC/fn if fn else None
@lru_cache(maxsize=128)
def asset_url(path):
    # A new glyph rendering must not reuse the previous CDN-cached image/video.
    return 'assets/'+path.relative_to(ASSET_SRC).as_posix()+'?v='+hashlib.sha256(path.read_bytes()).hexdigest()[:12]
def figure(fid, data, number=None, viewer=False):
    if not data:
        return f'<figure class="figure pending"><figcaption><span class="label">Figure {safe(fid)}</span>Asset unavailable for this build.</figcaption></figure>'
    p=asset_path(data) or asset_path(data,'path')
    if not p or not p.exists(): return f'<figure class="figure pending"><figcaption><span class="label">Figure {safe(fid)}</span>Asset unavailable for this build.</figcaption></figure>'
    # Viewer pages set <base href="../">, so use the site-relative asset path
    # here; a second ../ would resolve outside the feature site.
    asset_root='assets/'
    target=asset_url(p); alt=data.get('alt',fid); cap=data.get('caption','')
    caption_html=render_caption(cap,render_katex)
    frame_w=dimension(data.get('width'),1600); frame_h=dimension(data.get('height'),1000)
    animation=data.get('animation'); anim_path=animation if isinstance(animation,str) else (animation or {}).get('file') if isinstance(animation,dict) else None
    anim_p=ASSET_SRC/anim_path if anim_path else None
    video=data.get('video') or data.get('mp4')
    if isinstance(video,dict): video=video.get('file') or video.get('path')
    video_p=ASSET_SRC/video if isinstance(video,str) else None
    has_gif=bool(anim_p and anim_p.exists())
    has_video=bool(video_p and video_p.exists())
    animated=has_gif or has_video or data.get('type')=='gif'
    autoplay=bool(data.get('autoplay')) and has_video
    if has_video:
        fallback=asset_url(anim_p) if has_gif else ''
        attrs=f' data-motion data-video="{safe(asset_url(video_p))}" data-static="{safe(target)}"'
        if fallback: attrs+=f' data-animation="{safe(fallback)}"'
        if autoplay: attrs+=' data-autoplay="true"'
    elif has_gif:
        attrs=f' data-motion data-animation="{safe(asset_url(anim_p))}" data-static="{safe(target)}"'
    else:
        attrs=''
    source_label={'allegory':'Allegory','analytic':'Exact mathematical model','measurement':'Measurement'}.get(data.get('source_class'),'Figure')
    if fid=='fisher': source_label='Measurement + analytic model'
    figure_name={'anatomy':'Execution','reconstruction':'Reconstruction','controls':'Controls','fisher':'Local geometry','reachability':'Reachability','duality':'Metric projection','efficiency':'Equal-effect geometry','impossibility':'A shared-weight constraint','coordinates':'Dual coordinates'}.get(fid,'Figure')
    label='Cover · Allegory' if fid=='cover' else f'{figure_name} · {source_label}'
    loading='eager' if fid=='cover' else 'lazy'
    motion_label='Pause animation' if autoplay else 'Play motion'
    motion_note='Animation plays automatically · reduced motion keeps a still frame' if autoplay else 'Static by default · play at your pace'
    motion=f'<div class="motion"><button type="button" aria-pressed="false">{motion_label}</button><span>{motion_note}</span></div>' if animated else ''
    video_target=asset_url(video_p) if has_video else ''
    gif_target=asset_url(anim_p) if has_gif else ''
    video_attrs='autoplay muted loop playsinline preload="auto"' if autoplay else 'controls playsinline preload="none"'
    video_markup=f'<video class="motion-video" width="{frame_w}" height="{frame_h}" {video_attrs} poster="{safe(target)}" hidden aria-label="Motion for figure {safe(fid)}"><source src="{safe(video_target)}" type="video/mp4"></video>' if has_video else ''
    original_link=f' <a class="source-original" href="{safe(target)}" download>Source asset (original) ↧</a>'
    gif_link=f' <a class="gif-download" href="{safe(gif_target)}" download>Source asset (GIF) ↧</a>' if has_gif else ''
    video_link=f' <a class="video-alternative" href="{safe(video_target)}" download>Source asset (MP4) ↧</a>' if has_video else ''
    image_markup=f'<img class="static-frame" src="{safe(target)}" alt="{safe(alt)}" width="{frame_w}" height="{frame_h}" loading="{loading}">'
    # Keep the optional video outside the static-image link so its controls do
    # not inherit navigation, while keeping both layers in the art container.
    static_markup=image_markup if viewer else f'<a class="figure-link" href="figures/{safe(fid)}.html">{image_markup}</a>'
    art=f'<div class="figure-art">{static_markup}{video_markup}</div>'
    if not viewer:
        return f'<figure class="figure breakout" id="figure-{safe(fid)}"{attrs}>{art}<figcaption><span class="label">{safe(label)}</span>{caption_html} <a href="figures/{safe(fid)}.html">View full size ↗</a>{original_link}{gif_link}{video_link}</figcaption>{motion}</figure>'
    return f'<figure class="figure viewer-figure" id="figure-{safe(fid)}"{attrs}>{art}<figcaption><span class="label">{safe(label)}</span>{caption_html}{original_link}{gif_link}{video_link}</figcaption>{motion}</figure>'
def render_katex(expressions):
    """Render all TeX through the vendored KaTeX 0.16.11 runtime."""
    if not expressions: return []
    runtime=ROOT/'vendor'/'katex'/'katex.min.js'
    if not runtime.exists(): return [f'<span class="math">{safe(x[0])}</span>' for x in expressions]
    script="const k=require(process.argv[1]); let b=''; process.stdin.on('data',x=>b+=x).on('end',()=>{const a=JSON.parse(b); process.stdout.write(JSON.stringify(a.map(x=>k.renderToString(x[0],{displayMode:x[1],throwOnError:false}))))});"
    try:
        p=subprocess.run(['node','-e',script,str(runtime)],input=json.dumps(expressions),text=True,capture_output=True,check=True)
        return json.loads(p.stdout)
    except (OSError,subprocess.CalledProcessError,json.JSONDecodeError):
        return [f'<span class="math">{safe(x[0])}</span>' for x in expressions]
def demos(which):
    if which=='steering':
        content='''<section class="demo" data-gate aria-labelledby="gate-title"><h3 id="gate-title">A gate is a signed command</h3><p>Changing <span class="math">s</span> scales the arrow <span class="math">d·s</span>; negative values reverse it.</p><svg viewBox="0 0 520 150" role="img" aria-label="Signed gate schematic"><path d="M28 75H492M260 15V137" stroke="#6f86aa" opacity=".5"/><line data-arrow x1="260" y1="75" x2="260" y2="49" stroke="#82b0ff" stroke-width="5"/><circle cx="260" cy="75" r="5" fill="#285fc5"/><text x="272" y="28" fill="#314c75">d · s</text></svg><div class="demo-controls"><label for="gate-range">s</label><input id="gate-range" type="range" min="-2" max="2" step=".1" value="1"><output>1.0</output><span data-negative>positive gate applies the command</span></div></section>'''
        symbol,command=render_katex([('s',False),(r'd\,s',False)])
        content=content.replace('<span class="math">s</span>',symbol).replace('<span class="math">d·s</span>',command)
        content=content.replace('<label for="gate-range">s</label>','<label for="gate-range">'+symbol+'</label>')
        content=content.replace('<text x="272" y="28" fill="#314c75">d · s</text>', '<foreignObject x="272" y="7" width="110" height="45"><div xmlns="http://www.w3.org/1999/xhtml" style="font-size:24px;color:#314c75">'+command+'</div></foreignObject>')
        return content
    return '''<section class="demo" data-metric aria-labelledby="metric-title"><h3 id="metric-title">A metric changes the cheapest direction</h3><p>Fixed schematic Fisher metric <span class="math">F=[[2,.5],[.5,1]]</span>; projection <span class="math">P(v)=(vₓ+.25vᵧ,0)</span>.</p><svg viewBox="0 0 520 180" role="img" aria-label="Metric projection schematic"><path d="M45 145H480M260 18V160" stroke="#6f86aa" opacity=".5"/><path data-vector d="M260 130L390 60" stroke="#f1c276" stroke-width="4"/><path data-projection d="M260 130L390 130" stroke="#82b0ff" stroke-width="5"/><circle data-point cx="390" cy="60" r="6" fill="#f1c276"/><circle data-projected-point cx="390" cy="130" r="6" fill="#82b0ff"/><text x="400" y="57" fill="#dbe8ff">v</text><text x="400" y="125" fill="#dbe8ff">P(v)</text></svg><div class="demo-controls"><label>vₓ <input data-x type="range" min="-2" max="2" step=".1" value="1"></label><label>vᵧ <input data-v type="range" min="-2" max="2" step=".1" value="1"></label><output data-proj>P(v)=(1.25, 0)</output></div></section>'''
def render(md, manifest):
    # Parse prose and fenced code inside the expandable proof sections.
    md=md.replace('<details class="proof">','<details class="proof" markdown="1">')
    tokens=[]
    math_tokens=[]
    interactive=[]
    def mathrep(tex, display):
        tex=tex.strip().replace(r'\(', '(').replace(r'\)', ')')
        math_tokens.append((tex,display)); return f'@@MATH{len(math_tokens)-1}@@'
    def repl(m): tokens.append(figure(m.group(1),manifest.get(m.group(1)),len(tokens)+1)); return f'@@FIG{len(tokens)-1}@@'
    def interactive_repl(m): interactive.append(m.group(1)); return f'@@INTERACTIVE{len(interactive)-1}@@'
    md=re.sub(r'\{\{FIG:([\w-]+)\}\}',repl,md)
    md=re.sub(r'\{\{INTERACTIVE:([\w-]+)\}\}',interactive_repl,md)
    md=re.sub(r'\\\[\s*(.*?)\s*\\\]',lambda m:mathrep(m.group(1),True),md,flags=re.S)
    md=re.sub(r'\\\((.*?)\\\)',lambda m:mathrep(m.group(1),False),md,flags=re.S)
    md=re.sub(r'\$\$([^$]+)\$\$',lambda m:mathrep(m.group(1),True),md)
    md=re.sub(r'(?<!\$)\$([^$\n]+)\$(?!\$)',lambda m:mathrep(m.group(1),False),md)
    body=markdown.markdown(md,extensions=['tables','fenced_code','footnotes','sane_lists','md_in_html'])
    for i,f in enumerate(tokens): body=body.replace(f'@@FIG{i}@@',f)
    for i,f in enumerate(render_katex(math_tokens)):
        body=body.replace(f'@@MATH{i}@@',f)
    for i,name in enumerate(interactive): body=body.replace(f'@@INTERACTIVE{i}@@',demos(name))
    body=body.replace('<p><figure','<figure').replace('</figure></p>','</figure>')
    return body
def main():
    OUT.mkdir(parents=True,exist_ok=True); (OUT/'assets').mkdir(exist_ok=True)
    manifest=load_manifest(); source=DRAFT.read_text() if DRAFT.exists() else '# Research feature\n\nDraft pending.'
    source=re.sub(r'^#\s+.*\n+', '', source, count=1)
    source=re.sub(r'^##\s+.*\n+', '', source, count=1)
    source=source.replace('{{FIG:cover}}','',1)
    body=render(source,manifest)
    # Headings provide compact contents while preserving the draft as source of truth.
    ids=[]
    # Keep section links stable as the approved prose and headings evolve.
    section_anchors=[
        '1-what-did-astra-actually-have-to-solve',
        '2-how-can-a-0-016-edit-behave-like-a-program',
        '3-was-the-switch-really-doing-the-work',
        '4-what-does-fisher-geometry-predict-and-where-does-it-fail',
        '5-what-can-one-writer-realize-and-how-does-the-metric-choose',
        'which-geometry-defines-the-closest-move',
        'can-the-same-behavioral-effect-cost-less',
        '6-why-can-t-one-shared-edit-implement-every-steering-request',
        '7-where-does-amari-s-duality-enter',
        '8-what-should-we-conclude-now',
        'sources',
    ]
    def heading(m):
        level,text=m.group(1),re.sub('<[^>]+>','',m.group(2))
        slug=section_anchors[len(ids)]
        ids.append((slug,text))
        return f'<h{level} id="{slug}">{m.group(2)}</h{level}>'
    body=re.sub(r'<h([23])>(.*?)</h\1>',heading,body)
    assert len(ids)==len(section_anchors),'Update stable anchors when the article structure changes.'
    toc=''.join(f'<li><a href="#{safe(s)}">{safe(t)}</a></li>' for s,t in ids)
    cover=figure('cover',manifest.get('cover'))
    asset_version=hashlib.sha256((ROOT/'site.css').read_bytes()+(ROOT/'site.js').read_bytes()).hexdigest()[:12]
    html_doc=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="icon" href="data:,"><title>A Small Switch in a Vast Machine</title><meta name="description" content="Why Astra could edit Qwen—and what information geometry explains."><link rel="canonical" href="https://hayashiyus.github.io/blog/weight-space-geometry/en/"><link rel="alternate" hreflang="ja" href="https://hayashiyus.github.io/blog/weight-space-geometry/ja/"><meta property="og:type" content="article"><meta property="og:title" content="A Small Switch in a Vast Machine"><meta property="og:description" content="Why Astra could edit Qwen—and what information geometry explains."><meta property="og:url" content="https://hayashiyus.github.io/blog/weight-space-geometry/en/"><meta property="og:image" content="https://hayashiyus.github.io/blog/weight-space-geometry/en/assets/v22/poster-callouts.jpg"><meta name="twitter:card" content="summary_large_image"><link rel="stylesheet" href="site.css?v={asset_version}"><link rel="stylesheet" href="vendor/katex/katex.min.css"></head><body><div class="progress" aria-hidden="true"><i></i></div><header class="masthead"><span class="eyebrow">Engineering research feature</span><nav><a href="../ja/">日本語</a><a href="#contents">Contents</a><a href="https://www.figma.com/design/ot7ouesgGj6UOvQ93PPHUE?node-id=194-11" rel="noreferrer">Figma</a></nav></header><section class="cover"><div class="cover-copy"><span class="kicker">Weight-space programming</span><h1>A Small Switch in a Vast Machine</h1><p class="dek">Why Astra could edit Qwen—and what information geometry explains</p><p class="byline">hayashiyus · Published 8 November 2026 · 25 min read</p></div>{cover}</section><div class="layout" id="contents"><aside class="toc"><strong>Contents</strong><ol>{toc}</ol></aside><main class="article">{body}</main></div><footer class="site-footer"><details><summary>Publication and reproducibility</summary><p><strong>BibTeX</strong></p><pre>@article{{hayashi2026switch, title={{A Small Switch in a Vast Machine}}, author={{Hayashi, Yusuke}}, year={{2026}}, note={{Engineering research feature}}}}</pre><p><a href="data/measurements.json">Measurement data</a> · <a href="data/pilot_status.json">Pilot status</a> · <a href="repro/README.md">Reproduction guide</a> · <a href="downloads/research-feature.zip">Source archive</a></p></details><p><a href="../ja/">Japanese version</a> · <a href="https://www.figma.com/design/ot7ouesgGj6UOvQ93PPHUE?node-id=194-11" rel="noreferrer">Figma</a></p></footer><script src="site.js?v={asset_version}"></script></body></html>'''
    (OUT/'index.html').write_text(html_doc)
    # Keep each figure inspectable on its own page while preserving the article anchor.
    (OUT/'figures').mkdir(exist_ok=True)
    for fid, data in manifest.items():
        source=asset_path(data) or asset_path(data,'path')
        if not source or not source.exists():
            continue
        viewer_html=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="icon" href="data:,"><base href="../"><title>Figure {safe(fid)} · A Small Switch in a Vast Machine</title><link rel="stylesheet" href="site.css?v={asset_version}"><link rel="stylesheet" href="vendor/katex/katex.min.css"></head><body class="figure-viewer"><div class="progress" aria-hidden="true"><i></i></div><header class="masthead"><span class="eyebrow">Figure viewer</span><nav><a href="index.html#figure-{safe(fid)}">Back to article ↩</a></nav></header><main class="viewer"><a class="back-to-article" href="index.html#figure-{safe(fid)}">← Back to article</a>{figure(fid,data,viewer=True)}</main><script src="site.js?v={asset_version}"></script></body></html>'''
        (OUT/'figures'/f'{fid}.html').write_text(viewer_html)
    for old in (OUT/'assets').rglob('*'):
        if old.is_file(): old.unlink()
    if ASSET_SRC.exists():
        wanted=set()
        for item in manifest.values():
            for key in ('file','path','animation','video','mp4','model'):
                value=item.get(key)
                if isinstance(value,dict): value=value.get('file') or value.get('path')
                if isinstance(value,str): wanted.add(value)
        for name in list(wanted):
            stem=Path(name).stem
            sibling=Path(name).with_name(stem+'.svg')
            if (ASSET_SRC/sibling).exists(): wanted.add(sibling.as_posix())
        for name in wanted:
            p=ASSET_SRC/name
            if p.is_file():
                dest=OUT/'assets'/p.relative_to(ASSET_SRC); dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,dest)
        # Optional paper textures/palette metadata are copied when supplied, but are
        # deliberately not required for a normal build.
        for optional in (ASSET_SRC/'paper'/'washi.png', ASSET_SRC/'paper'/'palette.json'):
            if optional.is_file():
                dest=OUT/'assets'/optional.relative_to(ASSET_SRC); dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(optional,dest)
    shutil.copy2(ROOT/'site.css',OUT/'site.css'); shutil.copy2(ROOT/'site.js',OUT/'site.js')
    if (ROOT/'vendor').exists(): shutil.copytree(ROOT/'vendor',OUT/'vendor',dirs_exist_ok=True)
    (OUT/'data').mkdir(exist_ok=True); (OUT/'repro').mkdir(exist_ok=True); (OUT/'downloads').mkdir(exist_ok=True)
    for folder in (OUT/'data',OUT/'repro',OUT/'downloads'):
        for old in folder.rglob('*'):
            if old.is_file(): old.unlink()
    public_files=[(ROOT.parent/'data'/'measurements.json',OUT/'data'/'measurements.json'),(ROOT/'pilot_status.json',OUT/'data'/'pilot_status.json'),(ROOT.parent/'repro'/'README.md',OUT/'repro'/'README.md'),(ROOT.parent/'repro'/'environment.md',OUT/'repro'/'environment.md'),(ROOT.parent/'repro'/'prepare.py',OUT/'repro'/'prepare.py'),(ROOT.parent/'repro'/'contrast_texts.json',OUT/'repro'/'contrast_texts.json'),(ROOT.parent/'repro'/'UPSTREAM_LICENSE',OUT/'repro'/'UPSTREAM_LICENSE'),(ROOT.parent.parent/'theory'/'activation_information_geometry.md',OUT/'repro'/'activation_information_geometry.md'),(ROOT.parent.parent/'experiments'/'plans'/'e5_dual_edit_v2.md',OUT/'repro'/'e5_dual_edit_v2.md')]
    archive=ROOT.parent/'research-feature.zip'
    public_files.append((archive,OUT/'downloads'/'research-feature.zip'))
    for src,dst in public_files:
        if src.exists():
            dst.parent.mkdir(parents=True,exist_ok=True)
            if src.suffix in ('.md','.py','.json'):
                text=public_text(src)
                dst.write_text(text)
            else: shutil.copy2(src,dst)
    print(f'Built {OUT/"index.html"} ({len(ids)} sections, {len(manifest)} figures)')
if __name__=='__main__': main()
