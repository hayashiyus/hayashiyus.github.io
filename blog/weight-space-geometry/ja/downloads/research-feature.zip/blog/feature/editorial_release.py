"""Validate the approved editorial revision before historical QA is replayed.

The historical checks keep their frozen baselines. Only a hash-verified,
explicitly recorded editorial revision is reversed for those checks.
"""
from collections import Counter
from functools import lru_cache
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
RECORD = ROOT/'translations/editorial-revision.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def math(text):
    return Counter((a or b).strip() for a, b in re.findall(r'\\\[(.*?)\\\]|\\\((.*?)\\\)', text, re.S))


def numbers(text):
    return set(re.findall(r'(?<![A-Za-z])[-+−]?\d+(?:[.,]\d+)*(?:%|/\d+)?', text))


@lru_cache(maxsize=1)
def validate():
    if not RECORD.exists():
        return None
    record = json.loads(RECORD.read_text())
    results = {'scope': 'Approved editorial content, not a new empirical validation.', 'article': {}, 'captions': {}}
    current_text = {}
    for lang, entry in record['articles'].items():
        before, approved, current = [ROOT/entry[k] for k in ('before', 'approved', 'current')]
        assert sha(before)==entry['before_sha256'], f'{lang}: historical snapshot changed'
        assert sha(approved)==entry['approved_sha256'], f'{lang}: approved snapshot changed'
        a, b = before.read_text(), current.read_text()
        checks = {
            'matches_approved_text': current.read_bytes()==approved.read_bytes(),
            'math_multiset_preserved': math(a)==math(b),
            'math_expression_count': sum(math(b).values()),
            'code_preserved': re.findall(r'~~~.*?~~~',a,re.S)==re.findall(r'~~~.*?~~~',b,re.S),
            'figure_and_interactive_order_preserved': re.findall(r'\{\{[^}]+\}\}',a)==re.findall(r'\{\{[^}]+\}\}',b),
            'external_sources_preserved': set(re.findall(r'https?://[^)\s>]+',a))==set(re.findall(r'https?://[^)\s>]+',b)),
            'baseline_numeric_tokens_preserved': not (numbers(a)-numbers(b)),
        }
        assert all(checks.values()), (lang, checks)
        results['article'][lang]=checks
        current_text[lang]=b
    results['bilingual_math_equal']=math(current_text['en'])==math(current_text['ja'])
    assert results['bilingual_math_equal']
    for lang, entry in record['manifests'].items():
        before, current = ROOT/entry['before'], ROOT/entry['current']
        assert sha(before)==entry['before_sha256'], f'{lang}: caption baseline changed'
        assert sha(current)==entry['current_sha256'], f'{lang}: reviewed captions changed'
        old, new = json.loads(before.read_text()), json.loads(current.read_text())
        assert [f['id'] for f in old['figures']]==[f['id'] for f in new['figures']]
        for a,b in zip(old['figures'],new['figures']):
            assert a=={k:v for k,v in b.items() if k!='caption_summary'}, (lang,b['id'],'original metadata/caption changed')
            assert b.get('caption_summary','').strip(), (lang,b['id'],'missing takeaway')
        assert {k:v for k,v in old.items() if k!='figures'}=={k:v for k,v in new.items() if k!='figures'}
        results['captions'][lang]={'full_captions_and_all_existing_metadata_preserved': True,'takeaway_count':len(new['figures'])}
    results['status']='PASS'
    results['revision_record_sha256']=sha(RECORD)
    (ROOT/'translations/editorial-release-qa.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
    return record


def historical_article(text, lang):
    record=validate()
    if not record:
        return text
    entry=record['articles'][lang]
    assert text==(ROOT/entry['approved']).read_text()
    return (ROOT/entry['before']).read_text()


def historical_manifest(manifest, lang):
    record=validate()
    if not record:
        return manifest
    entry=record['manifests'][lang]
    assert manifest==json.loads((ROOT/entry['current']).read_text())
    return json.loads((ROOT/entry['before']).read_text())


if __name__=='__main__':
    validate()
    print((ROOT/'translations/editorial-release-qa.json').read_text())
