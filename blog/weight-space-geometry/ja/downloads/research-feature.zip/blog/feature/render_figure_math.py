#!/usr/bin/env python3
"""Rebuild selected article figures using the shared article KaTeX typography."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess

import atlas_v3 as v3
import atlas_v4 as v4
import atlas_v5 as v5
import geometry_v20 as geometry
import math_typesetting as typeset

ROOT = Path(__file__).resolve().parent


def jobs():
    return [
        ('anatomy','v5/mechanism',v5.mechanism,108),
        ('reconstruction','v3/reconstruction',v3.reconstruction,0),
        ('controls','v3/controls',v3.controls,0),
        ('fisher','v3/fisher',v3.fisher,4),
        ('reachability','v20/geometry/reachability',geometry.reachability,96),
        ('duality','v20/geometry/duality',geometry.duality,96),
        ('efficiency','v20/geometry/efficiency',geometry.efficiency,96),
        ('coordinates','v4/coordinates',v4.coordinates,48),
        ('impossibility','v3/impossibility',v3.impossibility,0),
    ]


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--stills-only',action='store_true')
    args=parser.parse_args()
    snapshot = ROOT.parent.parent/'output/math-typesetting/before'
    snapshot.mkdir(parents=True,exist_ok=True)
    for _,stem,_,_ in jobs():
        for suffix in ('.png','.svg'):
            source=ROOT/'assets'/(stem+suffix)
            target=snapshot/(stem.replace('/','-')+suffix)
            if source.exists() and not target.exists():shutil.copy2(source,target)
    with typeset.collect():
        for _,_,fn,frames in jobs():
            fn()
            for i in range(frames):fn(i/(frames-1))
        for t in (.30,.63,.97):v5.mechanism(t)
    typeset.prepare()
    # These checks concern only unchanged model/data definitions.
    v3.verify();v4.verify();v5.verify();geometry.verify()
    for fid,stem,fn,frames in jobs():
        if args.stills_only or not frames:
            path=ROOT/'assets'/(stem+'.svg');path.write_text(fn().finish())
            subprocess.run(['rsvg-convert','-o',str(path.with_suffix('.png')),str(path)],check=True)
        elif fid=='anatomy':
            old=v4.O;v4.O=v5.O
            try:v4.save('mechanism',fn,108,100)
            finally:v4.O=old
        elif fid=='fisher':v3.save('fisher',fn(),(4,fn,1200))
        elif fid=='coordinates':v4.save('coordinates',fn,48,125)
        else:geometry.save_media(fid,fn,96)
        print('Rendered '+fid+(' (still)' if args.stills_only else ''),flush=True)
    for label,t in [('A',.30),('B',.63),('C',.97)]:
        (v5.O/f'mechanism-{label}.svg').write_text(v5.mechanism(t).finish())
    result={'scope':'Typography-only rebuild; source model/data checks passed.',
            'katex_runtime_sha256':typeset.RUNTIME_HASH,'render_scale':typeset.SCALE,
            'unique_labels':len(typeset.REQUESTS),'stills_only':args.stills_only,
            'figures':{fid:{'path':stem+'.svg','sha256':hashlib.sha256((ROOT/'assets'/(stem+'.svg')).read_bytes()).hexdigest()} for fid,stem,_,_ in jobs()}}
    (ROOT/'assets/math/verification.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':main()
