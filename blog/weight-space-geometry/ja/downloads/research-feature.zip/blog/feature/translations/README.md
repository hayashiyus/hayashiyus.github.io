# 日本語で推敲するための原稿

編集対象は `../research.ja.md` です。図注と代替テキストは `../assets/figures.ja.json` にあります。日本語版の本文・数式・図注・折り畳み・脚注を、現在の英語版と対応づけています。

## 推奨する進め方

1. 日本語版を読み、言いたいこと、説明の順序、語り口を `research.ja.md` で整える。
2. 数値・数式・専門用語・主張の強さを変えた箇所は、意図した変更かを確認する。特に「局所的」「未完了」「実測ではなく模式図」といった条件は、表現上の飾りではない。
3. 英語へ戻す際は、日本語だけを新規翻訳するのではなく、英語原文と日本語の変更前後を比較し、改稿の意図を英語原文へ反映する。
4. 最後に英語の自然さと技術的な意味の維持を別々に確認する。AIによる英文校正も、著者の意図が保たれているかの確認に代わるものではない。

## 対応を残すファイル

- `research.en.source.md`：翻訳時点の英語原文。変更しない。
- `research.en.before-revision.md`：日本語推敲を反映する直前の英語原稿。
- `research.ja.approved.md`：著者が確認した日本語推敲稿。英語への反映元として保存。
- `figures.en.before-revision.json`：英語の図注を推敲する前のマニフェスト。
- `english-revision-qa.json`：英語改稿後の数式・数値・図・参照の照合記録。
- `research.ja.initial.md`：日本語訳の初版。変更しない。
- `research.ja.before-polish.md`：今回の全面推敲前の原稿。変更前後を確認するために保存。
- `alignment.json`：原文・訳文のハッシュ、節対応、数式などの照合記録。
- `../research.ja.md`：ユーザーが推敲する本文。
- `../assets/figures.ja.json`：推敲する図注・代替テキスト。

数式、プログラム、図の参照記号、脚注のID、リンク先は原文と対応を保っています。図・動画に焼き込まれた英語は、承認済みの作品をそのまま使用しています。図注と表紙動画の注釈対訳を日本語で読めるようにしています。これは原文の翻訳であり、文献や実験の再監査ではありません。

## 表示を更新する

リポジトリのルートで実行します。

```sh
python3 blog/feature/build_ja.py --publish-local
```

日本語版は `http://localhost:8876/blog/weight-space-geometry/ja/` に出力されます。公開済みの外部サイトへのアップロードは行いません。

用語は原則として、activation＝活性化、steering＝ステアリング、metric＝計量、weight edit＝重み編集、reachable＝実現可能、pullback＝引き戻し、natural gradient＝自然勾配、と統一しています。prefixはモデルへ与える先行トークン列を指し、技術用語として英語表記を残しています。

## 今回の日本語推敲

2026年11月7日、本文全体・図注・見出し・証明の説明を、日本語として読みやすい語順と段落構成に整えました。実験については目的、結果、そこから言える範囲を分け、幾何の説明は図の読み方から数式の意味へつなげています。

日本語推敲の段階では、英語原稿、英語版ページ、原図・動画は変更しませんでした。

数式・数値・コード等の機械照合と、英語原文との意味の照合を分けて実施しました。照合は翻訳・推敲による意味の変化を確認するもので、論文や実験を新たに監査したものではありません。

## 確認済みの日本語稿から英語版へ

著者が日本語稿を確認し、英語への反映を指示した後、英語本文と全10図の図注・代替テキストを改稿しました。日本語の説明順と段落構成を反映し、語順や言い回しは自然な研究英語に整えています。確認済みの日本語本文・図注と、画像・動画のファイルは変更していません。

英語改稿前の原稿と確認済みの日本語稿の両方に対して、数式・数値・コード・図順・リンク・脚注の照合を行っています。意味の照合では、測定結果と原著報告、局所近似と有限変化、実証済みの結果と提案段階の手法を区別し、主張の強さと留保を確認しました。

```sh
python3 blog/feature/verify_english_revision.py
python3 blog/feature/build.py
python3 blog/feature/build_ja.py --publish-local
```

改稿した英語版のローカル確認先は `http://localhost:8876/blog/weight-space-geometry/en/` です。既存の節リンクは維持しています。英語の折り畳み内も本文・コードとして描画するようにしました。外部サイトへの公開操作は行っていません。

## 公開前の最終確認（2026年11月8日）

著者の公開指示に基づき、日英双方で、効果を揃える最適化式には目的関数の微分がゼロでない条件を明記し、一般的な実現可能性の主張を局所線形化モデルに限定しました。数式そのものと実験数値は変更していません。旧日本語稿へのリンクを現行版に更新し、末尾の日本語による美術説明は「表紙の原画」の構えを述べたものだと明確にしました。

変更の前後と理由は `prepublication-corrections.json` に記録しています。著者確認済みの `research.ja.approved.md` は上書きせず、照合スクリプトでは記録した修正だけを適用した原稿と比較します。公開前監査は翻訳時の保全検査とは区別しています。

## 著者確認済みの構成改稿（2026年11月9日）

承認された日英の全文改稿を反映し、工学上の判断を明示しました。中心式は本文に残し、定義と証明を展開式にしています。図注の `caption_summary` は常時表示する要点、`caption` は設定・数値・留保を含む元の全文で、後者を折り畳み内に表示します。画像・動画は変更していません。

`editorial-20261109/` に直前の原稿と承認済み原稿を保存し、`editorial-revision.json` にハッシュを記録しました。`../editorial_release.py` が現行原稿と図注を検査した後、従来の検査はこの記録だけを逆適用して古い基準と比較します。過去の原稿や照合基準を上書きして検査を通すことはしません。本文・図注を次に改稿するときも、日英の意味と実験条件を照合し、意図した変更を記録してください。

## 承認後の追補（append-only）

承認済み原稿を変更する必要がある場合は、既存のスナップショットを上書きせず、追補JSONに日英それぞれの一意な `old`/`new` 置換、承認理由、追加外部ソースを記録します。追補ファイルのSHA-256を `editorial-revision.json` の `article_amendments` に固定し、ガードは承認稿へ置換を一度だけ適用した結果と現行本文が一致する場合だけ通します。追加ソースは追補に列挙したURLだけを許可し、図注・数式・コード・数値・図順は従来どおり不変です。

## Research outlook and audience revision (2026-11-09)

`audience-outlook-20261109.json` records the subsequent bilingual opening and conclusion revision and its primary-source additions. It foregrounds the contribution of the case analysis and an explicitly proposed recursive-improvement experiment. The previous approved snapshots and amendment remain unchanged. Equations, experimental results and figure captions are preserved.

`research-program-framing-20261109.json` sharpens the opening contribution and final research-program framing without changing the evidence or mathematical scope.
