#!/usr/bin/env python3
"""Check protected content after incorporating the approved Japanese revision.

This is an editorial preservation check, not a scientific validation. Semantic
review of the claims and their qualifications is recorded separately.
"""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

from verify_translation import protected

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compare(source, target):
    before, after = protected(source), protected(target)
    checks = {}
    for key in before:
        ordered = key in ('display_math', 'code_blocks', 'figure_order', 'interactive_order')
        passed = before[key] == after[key] if ordered else Counter(before[key]) == Counter(after[key])
        checks[key] = {'passed': passed, 'source_count': len(before[key]), 'revised_count': len(after[key])}
        if not passed:
            checks[key]['missing'] = list((Counter(before[key])-Counter(after[key])).elements())
            checks[key]['extra'] = list((Counter(after[key])-Counter(before[key])).elements())
    headings = lambda text: re.findall(r'^(#{2,3}) ', text, re.M)
    checks['heading_structure'] = {'passed': headings(source) == headings(target)}
    return checks


def main():
    source = ROOT/'translations/research.en.before-revision.md'
    approved = ROOT/'translations/research.ja.approved.md'
    current = ROOT/'research.md'
    checks = compare(source.read_text(), current.read_text())
    corrections = json.loads((ROOT/'translations/prepublication-corrections.json').read_text())
    expected_japanese = approved.read_text()
    for change in corrections['changes']['ja']:
        assert expected_japanese.count(change['old']) == 1
        expected_japanese = expected_japanese.replace(change['old'], change['new'])
    checks['approved_japanese_with_recorded_errata'] = {'passed': expected_japanese == (ROOT/'research.ja.md').read_text()}
    checks['english_errata_present'] = {'passed': all(change['new'] in current.read_text() for change in corrections['changes']['en'])}
    # Compare against the approved Japanese as well as the original English.
    bilingual = compare((ROOT/'research.ja.md').read_text(), current.read_text())
    old_figures = json.loads((ROOT/'translations/figures.en.before-revision.json').read_text())
    new_figures = json.loads((ROOT/'assets/figures.json').read_text())
    strip_copy = lambda document: {**document, 'figures': [{k:v for k,v in row.items() if k not in ('caption','alt')} for row in document['figures']]}
    checks['figure_assets_unchanged'] = {'passed': strip_copy(old_figures) == strip_copy(new_figures)}
    numeric = lambda text: Counter(re.findall(r'[-+−]?\d*\.\d+%?|\d+', text))
    captions = {}
    for old, new in zip(old_figures['figures'], new_figures['figures']):
        captions[old['id']] = {'passed': old['id']==new['id'] and numeric(old.get('caption',''))==numeric(new.get('caption',''))}
    groups = (checks, bilingual, captions)
    result = {
        'status': 'PASS' if all(item['passed'] for group in groups for item in group.values()) else 'FAIL',
        'scope': 'Protected editorial content only; semantic and rendered reviews are separate.',
        'english_source_sha256': sha(source), 'approved_japanese_sha256': sha(approved),
        'revised_english_sha256': sha(current),
        'prepublication_corrections': 'prepublication-corrections.json',
        'current_japanese_sha256': sha(ROOT/'research.ja.md'),
        'original_english_comparison': checks, 'approved_japanese_comparison': bilingual,
        'caption_numbers': captions,
    }
    (ROOT/'translations/english-revision-qa.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if result['status'] != 'PASS':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
