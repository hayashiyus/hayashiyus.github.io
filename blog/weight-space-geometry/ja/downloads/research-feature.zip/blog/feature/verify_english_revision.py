#!/usr/bin/env python3
"""Check protected content after incorporating the approved Japanese revision.

This is an editorial preservation check, not a scientific validation. Semantic
review of the claims and their qualifications is recorded separately.
"""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

from verify_translation import protected

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compare(source, target):
    before, after = protected(source), protected(target)
    checks = {}
    for key in before:
        ordered = key in ('display_math', 'code_blocks', 'figure_order', 'interactive_order')
        passed = before[key] == after[key] if ordered else Counter(before[key]) == Counter(after[key])
        checks[key] = {'passed': passed, 'source_count': len(before[key]), 'revised_count': len(after[key])}
        if not passed:
            checks[key]['missing'] = list((Counter(before[key])-Counter(after[key])).elements())
            checks[key]['extra'] = list((Counter(after[key])-Counter(before[key])).elements())
    headings = lambda text: re.findall(r'^(#{2,3}) ', text, re.M)
    checks['heading_structure'] = {'passed': headings(source) == headings(target)}
    return checks


def main():
    source = ROOT/'translations/research.en.before-revision.md'
    approved = ROOT/'translations/research.ja.approved.md'
    current = ROOT/'research.md'
    checks = compare(source.read_text(), current.read_text())
    corrections = json.loads((ROOT/'translations/prepublication-corrections.json').read_text())
    redesign = json.loads((ROOT/'translations/execution-redesign.json').read_text())
    atlas_revision = json.loads((ROOT/'translations/atlas-redesign.json').read_text())
    expected_japanese = approved.read_text()
    for change in corrections['changes']['ja']:
        assert expected_japanese.count(change['old']) == 1
        expected_japanese = expected_japanese.replace(change['old'], change['new'])
    current_japanese_for_approval = (ROOT/'research.ja.md').read_text()
    for change in atlas_revision['article_changes']['ja']:
        assert current_japanese_for_approval.count(change['new']) == 1
        current_japanese_for_approval = current_japanese_for_approval.replace(change['new'], change['old'])
    for change in redesign['article_changes']['ja']:
        assert current_japanese_for_approval.count(change['new']) == 1
        current_japanese_for_approval = current_japanese_for_approval.replace(change['new'], change['old'])
    checks['approved_japanese_with_recorded_errata'] = {'passed': expected_japanese == current_japanese_for_approval}
    checks['english_errata_present'] = {'passed': all(change['new'] in current.read_text() for change in corrections['changes']['en'])}
    current_text = current.read_text()
    checks['execution_redesign_english_present'] = {'passed': all(change['new'] in current_text and change['old'] not in current_text for change in redesign['article_changes']['en'])}
    current_japanese_text = (ROOT/'research.ja.md').read_text()
    checks['execution_redesign_japanese_present'] = {'passed': all(change['new'] in current_japanese_text and change['old'] not in current_japanese_text for change in redesign['article_changes']['ja'])}
    for lang, text in [('en',current_text),('ja',current_japanese_text)]:
        checks['atlas_redesign_'+lang+'_present'] = {'passed': all(text.count(change['new']) == 1 and change['old'] not in text for change in atlas_revision['article_changes'][lang])}
    # Compare against the approved Japanese as well as the original English.
    bilingual = compare((ROOT/'research.ja.md').read_text(), current.read_text())
    old_figures = json.loads((ROOT/'translations/figures.en.before-revision.json').read_text())
    new_figures = json.loads((ROOT/'assets/figures.json').read_text())
    japanese_figures = json.loads((ROOT/'assets/figures.ja.json').read_text())
    for fid, record in atlas_revision['figures'].items():
        checks['atlas_metadata_'+fid] = {'passed':
            next(row for row in new_figures['figures'] if row['id']==fid)==record['new_en'] and
            next(row for row in japanese_figures['figures'] if row['id']==fid)==record['new_ja']}
    anatomy = next(row for row in new_figures['figures'] if row['id'] == redesign['figure']['id'])
    expected = redesign['figure']['new']
    checks['anatomy_redesign_metadata'] = {'passed': all(anatomy.get(k) == v for k,v in expected.items()), 'expected': expected}
    unchanged_old = [row for row in old_figures['figures'] if row['id'] != redesign['figure']['id']]
    # Undo only exactly recorded v24 mutations before comparing the earlier baseline.
    unchanged_new = [atlas_revision['figures'].get(row['id'],{}).get('old_en',row) for row in new_figures['figures'] if row['id'] != redesign['figure']['id']]
    strip_copy = lambda rows: [{k:v for k,v in row.items() if k not in ('caption','alt')} for row in rows]
    checks['figure_assets_unchanged_except_recorded_redesigns'] = {'passed': strip_copy(unchanged_old) == strip_copy(unchanged_new)}
    numeric = lambda text: Counter(re.findall(r'[-+−]?\d*\.\d+%?|\d+', text))
    captions = {}
    for old, new in zip(old_figures['figures'], new_figures['figures']):
        old_numbers, new_numbers = Counter(numeric(old.get('caption',''))), Counter(numeric(new.get('caption','')))
        if old['id'] == redesign['figure']['id']:
            expected_caption = redesign['caption_changes']['en']['new']
            passed = new.get('caption') == expected_caption and not (old_numbers-new_numbers)
        elif old['id'] in atlas_revision['figures']:
            record=atlas_revision['figures'][old['id']]
            passed = new == record['new_en'] and not (old_numbers-new_numbers)
        else:
            passed = old['id']==new['id'] and old_numbers == new_numbers
        captions[old['id']] = {'passed': passed, 'old_numbers_preserved': not (old_numbers-new_numbers)}
    groups = (checks, bilingual, captions)
    result = {
        'status': 'PASS' if all(item['passed'] for group in groups for item in group.values()) else 'FAIL',
        'scope': 'Protected editorial content only; semantic and rendered reviews are separate.',
        'english_source_sha256': sha(source), 'approved_japanese_sha256': sha(approved),
        'revised_english_sha256': sha(current),
        'prepublication_corrections': 'prepublication-corrections.json',
        'current_japanese_sha256': sha(ROOT/'research.ja.md'),
        'original_english_comparison': checks, 'approved_japanese_comparison': bilingual,
        'caption_numbers': captions,
    }
    (ROOT/'translations/english-revision-qa.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if result['status'] != 'PASS':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
