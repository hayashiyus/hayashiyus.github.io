# A Small Switch in a Vast Machine

Bilingual research feature, **8 November 2026**, by hayashiyus.

The original authors' large benchmark result, our smaller numerical probes, and exact mathematical examples are explicitly distinguished. Full MATH-500 reproduction and fixed-program P-Astra evaluation are not completed.

## Rebuild the article

From the extracted archive root (Python 3 and Node.js required):

```sh
python3 -m pip install numpy pillow markdown beautifulsoup4
python3 blog/feature/verify_translation.py
python3 blog/feature/verify_english_revision.py
python3 blog/feature/build.py
python3 blog/feature/build_ja.py
python3 blog/feature/stage_publication.py --out dist
python3 -m http.server 8876 --directory dist
```

Open `/blog/weight-space-geometry/en/` or `/blog/weight-space-geometry/ja/`. Copy the downloaded `research-feature.zip` into `blog/` before building if the staged site should also offer that download; the archive cannot contain itself.

The selected media are defined by `assets/figures.json`: v22 cover motion, v5 mechanism, v20 reachability/projection/equal-effect geometry, v4 dual coordinates, and v3 numerical-result figures. The archive includes the selected images, GIFs and MP4s, mathematical model data, measurement aggregates, and vendored KaTeX with its license. No image-generation API call is needed to rebuild the site. Earlier paintings and rendering scripts are retained as provenance, not selected article assets. Reference photographs are not bundled.

The cover and the reachability, metric-projection, and equal-effect geometry plates play automatically unless reduced motion is requested. The mechanism, Fisher-dose, and dual-coordinate animations start as stills with an explicit play control. Downloadable GIFs remain available. For complete motion regeneration, see `assets/v22/README.md`; the static site can be rebuilt from the included finished media without rerunning the solver. The E5 plan is a research-planning snapshot, not a standalone runnable experiment; internal dependencies referenced by that plan are not bundled.

## Formula typography

The current figure labels and animation frames use the article's vendored KaTeX
0.16.11 runtime, CSS and fonts. TeX is laid out in Chromium and captured against
transparency at 4x resolution; each SVG keeps the TeX in `data-tex` and embeds
the resulting label. Prose and plotted geometry remain editable SVG elements.
The label cache is included in `assets/math/`, so rendering does not depend on
Unicode superscript/subscript characters or locally installed substitute fonts.
Figure captions and the interactive gate also use article KaTeX.

To rebuild the selected figures, install Google Chrome, `rsvg-convert`, FFmpeg,
and the Python `playwright` package, then run:

```sh
python3 blog/feature/render_figure_math.py --stills-only
python3 blog/feature/render_figure_math.py
```

The first command permits static layout review before rerendering animations.
It preserves the underlying toy models, measurements, frame counts and timing.
The cover contains no formulas and is not rerendered by this command.

## Figma provenance (underlying v11 painting)

https://www.figma.com/design/ot7ouesgGj6UOvQ93PPHUE?node-id=58-11

Page **55:11 — v11 Kabuki · poised motion** records the underlying Figma painting; raw output is `55:12`, with final raw/source composition at `57:11` and original base at `57:12`. Three editable image-fill regions are recorded at `57:14`, `57:16`, and `57:18`; the final annotated native cover is `58:11` with painting `58:31` and twelve editable text layers. The v11 image preserves the pale graphite/watercolor background, boats, and serpentine canal while showing only slight spring/dance motion in the two adult male Kabuki actors and near-white timber canal. User reference photographs are not bundled. Pages **39:11 / 42:11 / 46:11** preserve v9, v10 remains the rejected dramatic-leap test, and v8/v7/v5/v4/v3 remain preserved as prior history. The Figma UI export was inspected separately from the programmatically rendered PNGs.

See `art/PROVENANCE.md` for image generation, visual references, and the distinctions between allegory, analytic models and measurements. BetaTomorrow/deep Manifold did not author or endorse these illustrations.

## Reproduce the numerical probes

See `../repro/README.md` and `../repro/environment.md`. The corresponding Python sources are included under `experiments/wsp_geometry`, `experiments/wsp_controls`, and `experiments/wsp_generation`. Downloading the pinned model and benchmark requires network access and separate storage; running the measurements requires compatible GPU software. The archive does not contain model weights.

The build script copies explicitly selected public files. Internal connection scripts, credentials, host details and private work logs are excluded.
