# A Small Switch in a Vast Machine

Bilingual research feature, published **8 November 2026**, updated **10 November 2026**, by hayashiyus.

The original authors' large benchmark result, our smaller numerical probes, and exact mathematical examples are explicitly distinguished. Full MATH-500 reproduction and fixed-program P-Astra evaluation are not completed.

## Rebuild the article

From the extracted archive root (Python 3 and Node.js required):

```sh
python3 -m pip install numpy pillow markdown beautifulsoup4
python3 blog/feature/editorial_release.py
python3 blog/feature/verify_translation.py
python3 blog/feature/verify_english_revision.py
python3 blog/feature/build.py
python3 blog/feature/build_ja.py
python3 blog/feature/stage_publication.py --out dist
python3 -m http.server 8876 --directory dist
```

Open `/blog/weight-space-geometry/en/` or `/blog/weight-space-geometry/ja/`. Copy the downloaded `research-feature.zip` into `blog/` before building if the staged site should also offer that download; the archive cannot contain itself.

The selected media are defined by `assets/figures.json`: v22 cover motion, v23 execution, and the eight v24 mathematical and numerical-result plates. The archive includes the selected images, GIFs and MP4s, mathematical model data, measurement aggregates, and vendored KaTeX with its license. No image-generation API call is needed to rebuild the site. Earlier paintings and rendering scripts are retained as provenance, not selected article assets. Reference photographs are not bundled.

The cover retains its automatic looping playback. Each of the seven non-cover videos plays once after its art remains substantially visible for 600 ms. At most one non-cover video runs at a time. Leaving the viewport or backgrounding the tab pauses an unfinished video; returning resumes it after the same dwell. Completion restores the static summary, and deliberate stopping disables further automatic playback for that figure until page reload. Reduced-motion preference suppresses automatic playback while retaining manual controls. Browser autoplay denial leaves a usable still and play button. Downloadable GIFs remain available. For complete cover motion regeneration, see `assets/v22/README.md`; the static site can be rebuilt from the included finished media without rerunning the solver. The E5 plan is a research-planning snapshot, not a standalone runnable experiment; internal dependencies referenced by that plan are not bundled.

## Formula typography

The current figure labels and animation frames use the article's vendored KaTeX
0.16.11 runtime, CSS and fonts. TeX is laid out in Chromium and captured against
transparency at 4x resolution; each SVG keeps the TeX in `data-tex` and embeds
the resulting label. Prose and plotted geometry remain editable SVG elements.
The label cache is included in `assets/math/`, so rendering does not depend on
Unicode superscript/subscript characters or locally installed substitute fonts.
Figure captions and the interactive gate also use article KaTeX.

To rebuild the selected figures, install Google Chrome, `rsvg-convert`, FFmpeg,
and the Python `playwright` package, then run:

```sh
python3 blog/feature/render_figure_math.py --stills-only
python3 blog/feature/render_figure_math.py
```

The first command permits static layout review before rerendering animations.
It preserves the underlying toy models, measurements, frame counts and timing.
The cover contains no formulas and is not rerendered by this command.

## Figma provenance (underlying v11 painting)

https://www.figma.com/design/ot7ouesgGj6UOvQ93PPHUE?node-id=58-11

Page **55:11 — v11 Kabuki · poised motion** records the underlying Figma painting; raw output is `55:12`, with final raw/source composition at `57:11` and original base at `57:12`. Three editable image-fill regions are recorded at `57:14`, `57:16`, and `57:18`; the final annotated native cover is `58:11` with painting `58:31` and twelve editable text layers. The v11 image preserves the pale graphite/watercolor background, boats, and serpentine canal while showing only slight spring/dance motion in the two adult male Kabuki actors and near-white timber canal. User reference photographs are not bundled. Pages **39:11 / 42:11 / 46:11** preserve v9, v10 remains the rejected dramatic-leap test, and v8/v7/v5/v4/v3 remain preserved as prior history. The Figma UI export was inspected separately from the programmatically rendered PNGs.

See `art/PROVENANCE.md` for image generation, visual references, and the distinctions between allegory, analytic models and measurements. BetaTomorrow/deep Manifold did not author or endorse these illustrations.

## Reproduce the numerical probes

See `../repro/README.md` and `../repro/environment.md`. The corresponding Python sources are included under `experiments/wsp_geometry`, `experiments/wsp_controls`, and `experiments/wsp_generation`. Downloading the pinned model and benchmark requires network access and separate storage; running the measurements requires compatible GPU software. The archive does not contain model weights.

The build script copies explicitly selected public files. Internal connection scripts, credentials, host details and private work logs are excluded.


## Visual mathematics atlas v24

All eight non-cover plates other than the retained v23 execution plate now use the v24 atlas. Six have synchronized 12-second MP4/GIF motion; reconstruction and controls retain measured static charts. See `assets/v24/README.md` for model semantics, source modules, editable Figma provenance, and rebuild commands. The cover assets and the execution plate remain unchanged.

## Editorial revision and layered captions (9 November 2026)

The author-approved English and Japanese drafts clarify the engineering decisions, retain the central identities in the main text, and place definitions and proofs in foldouts. Every figure has an always-visible takeaway (`caption_summary`); its original full caption, mathematical settings, limitations and source-file downloads remain in a native keyboard-accessible disclosure. The figure-viewer pages use the same structure. Images, videos and motion behavior are unchanged.

`translations/editorial-revision.json` pins the approved manuscripts and the reviewed caption manifests. `editorial_release.py` checks the actual current files against that record, preserves every original formula/code block and all original caption metadata, and checks bilingual math. Historical QA then reverses only this verified revision before comparing older frozen baselines; it does not overwrite those baselines. The archive includes both snapshots and the current text. These checks establish editorial preservation, not new empirical findings or measured human-comprehension gains.
