"""Exact typography substitutions for the existing, reviewed figure captions.

The caption wording and numbers stay in the bilingual manifests. This map
replaces only their mathematical strings at render time, using article KaTeX.
"""
import html
import re

FORMULAS = {
    'A=(1,0)':r'A=(1,0)', 'B=(0,1)':r'B=(0,1)', 'C=(−1,0)':r'C=(-1,0)',
    'W=I':r'W=I', 'k=(1,0)':r'k=(1,0)', 'd=(0,.7)':r'd=(0,.7)',
    'ΔW=d kᵀ':r'\Delta W=dk^\top', 'd(kᵀa)':r'd(k^\top a)',
    'F=diag(1,3)':r'F=\operatorname{diag}(1,3)', 'F=I':r'F=I',
    'ΔW*=VA⁺=diag(.35,.55)':r'\Delta W^*=VA^+=\operatorname{diag}(.35,.55)',
    'ΔW':r'\Delta W',
    '½(u−v)ᵀF(u−v)':r'\tfrac12(u-v)^\top F(u-v)',
    'F=[[2,.5],[.5,1]]':r'F=\begin{pmatrix}2&.5\\.5&1\end{pmatrix}',
    'v=(.8,1.4)':r'v=(.8,1.4)', 'u₂=0':r'u_2=0',
    '(1.15,0)':r'(1.15,0)', '(.8,0)':r'(.8,0)', 'b=(1,.8)':r'b=(1,.8)',
    'bᵀd=.6':r'b^\top d=.6', '½dᵀFd':r'\tfrac12d^\top Fd',
    'd*=.6F⁻¹b/(bᵀF⁻¹b)':r'd_* = \frac{.6F^{-1}b}{b^\top F^{-1}b}',
    'h_i=log(p_i/p_3)':r'h_i=\log(p_i/p_3)', 'h_w(x)=wx':r'h_w(x)=wx',
    'x=±1':r'x=\pm1', '(δw,−δw)':r'(\delta w,-\delta w)',
    '(+d,+d)':r'(+d,+d)', 'd≠0':r'd\ne0',
}
PATTERN = re.compile('|'.join(re.escape(s) for s in sorted(FORMULAS,key=len,reverse=True)))


def render_caption(text, render_katex):
    matches = list(PATTERN.finditer(text))
    if not matches:return html.escape(text,quote=True)
    rendered = render_katex([(FORMULAS[m[0]],False) for m in matches])
    parts=[];position=0
    for match,formula in zip(matches,rendered):
        parts.extend([html.escape(text[position:match.start()],quote=True),formula])
        position=match.end()
    parts.append(html.escape(text[position:],quote=True))
    return ''.join(parts)
