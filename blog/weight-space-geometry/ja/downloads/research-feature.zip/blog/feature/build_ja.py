#!/usr/bin/env python3
"""Build the editable Japanese translation using the existing article renderer.

No translation service runs here. research.ja.md and figures.ja.json are the
human-editable sources; English formulas/media and rendering are shared.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import shutil
from bs4 import BeautifulSoup, NavigableString
import build as base

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'site-ja'
PUBLISH=ROOT.parent/'publish/blog/weight-space-geometry/ja'

UI={
    'Engineering research feature':'機械学習の研究ブログ',
    'Contents':'目次',
    'Cover · Allegory':'表紙 · 寓意画',
    'Execution · Exact mathematical model':'作用の仕組み · 厳密な数学モデル',
    'Reconstruction · Measurement':'編集の再構成 · 測定結果',
    'Controls · Measurement':'対照実験 · 測定結果',
    'Local geometry · Measurement + analytic model':'局所的な幾何 · 測定結果と解析モデル',
    'Reachability · Exact mathematical model':'実現可能性 · 厳密な数学モデル',
    'Metric projection · Exact mathematical model':'計量に基づく射影 · 厳密な数学モデル',
    'Equal-effect geometry · Exact mathematical model':'効果を揃えた比較 · 厳密な数学モデル',
    'A shared-weight constraint · Exact mathematical model':'共有重みの制約 · 厳密な数学モデル',
    'Dual coordinates · Exact mathematical model':'双対座標 · 厳密な数学モデル',
    'Pause animation':'アニメーションを停止',
    'Play motion':'アニメーションを再生',
    'Animation plays automatically · reduced motion keeps a still frame':'自動再生 · 動きを減らす設定では静止画を表示',
    'Static by default · play at your pace':'最初は静止画を表示 · 好きなタイミングで再生',
    'Plays once when in view · pause at any time':'図が見えたら一度だけ自動再生 · いつでも停止できます',
    'Source asset (original) ↧':'原画像 ↧',
    'Source asset (GIF) ↧':'GIF ↧',
    'Source asset (MP4) ↧':'MP4 ↧',
    'View full size ↗':'大きく表示 ↗',
    'Figure viewer':'図の拡大表示',
    'Back to article ↩':'本文へ戻る ↩',
    '← Back to article':'← 本文へ戻る',
    'Publication and reproducibility':'引用情報と再現手順',
    'Measurement data':'測定データ',
    'Pilot status':'予備実験の状況',
    'Reproduction guide':'再現手順',
    'Source archive':'ソース一式',
    'Japanese companion':'英語原文',
    'Japanese version':'英語原文',
    'A gate is a signed command':'ゲートの符号が、介入の向きを決める',
    'Changing':'係数',
    'scales the arrow':'を変えると、矢印',
    '; negative values reverse it.':'の大きさが変わる。負の値では向きが反転する。',
    'positive gate applies the command':'正のゲート：指令をそのまま適用',
    'A metric changes the cheapest direction':'計量が変わると、最も低コストの方向も変わる',
    'Fixed schematic Fisher metric':'模式例のFisher計量',
    '; projection':'、射影',
}

JS_UI={
    'Plays once when in view · pause at any time':'図が見えたら一度だけ自動再生 · いつでも停止できます',
    'Pause animation':'アニメーションを停止',
    'Pause / show still':'停止して静止画を表示',
    'Resume animation':'アニメーションを再開',
    'Play motion':'アニメーションを再生',
    'Replay motion':'もう一度再生',
    'Static view · play if you prefer':'静止画を表示 · 必要なときだけ再生できます',
    'negative gate reverses the command':'負のゲート：指令の向きが反転',
    'positive gate applies the command':'正のゲート：指令をそのまま適用',
    'zero gate makes no change':'ゲートがゼロ：変化なし',
}

COVER_GLOSS=[
    ('Follow the current. / No intervention.','流れに沿って進む。介入はしない。'),
    ('Change the flow. / Weight edit','流れを変える。重み編集に対応する。'),
    ('Carried by the current. / Into the side opening.','流れに運ばれ、側方の開口部へ向かう。'),
    ('Push the boat. / Activation steering','船を押す。活性化のステアリングに対応する。'),
    ('The same side exit. / Different actions and paths.','出口は同じ。ただし、操作も軌道も異なる。'),
    ('Main channel · recorded exit / Side exit · frame held / Recorded paths',
     '本流の出口を通過／側方の出口を通過した場面で静止／記録した軌跡。'),
]

def translate_ui(soup):
    for text in list(soup.find_all(string=True)):
        if text.parent.name in ('script','style','pre','code','annotation'):continue
        key=str(text).strip()
        if key in UI:
            original=str(text)
            left=original[:len(original)-len(original.lstrip())]
            right=original[len(original.rstrip()):]
            text.replace_with(left+UI[key]+right)
    for video in soup.select('video[aria-label]'):
        video['aria-label']='図のアニメーション'
    for svg in soup.select('[data-gate] svg'):svg['aria-label']='符号付きゲートの模式図'
    for svg in soup.select('[data-metric] svg'):svg['aria-label']='計量に基づく射影の模式図'

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--publish-local',action='store_true');args=ap.parse_args()
    draft=ROOT/'research.ja.md'
    if not draft.exists():raise SystemExit('Missing research.ja.md; build does not generate or overwrite translations.')
    source=draft.read_text();title=re.search(r'^# (.+)$',source,re.M)[1];dek=re.search(r'^## (.+)$',source,re.M)[1]
    manifest=base.load_manifest()
    if not (ROOT/'site/index.html').exists():base.main()
    localized=json.loads((ROOT/'assets/figures.ja.json').read_text())['figures']
    assert {r['id'] for r in localized}==set(manifest),'Japanese figure coverage differs from English.'
    for row in localized:
        manifest[row['id']].update({k:v for k,v in row.items() if k in ('caption','alt')})
    base.OUT=OUT;base.DRAFT=draft;base.load_manifest=lambda:manifest
    original_render=base.render
    base.render=lambda md,m:original_render(md.replace('<details class="proof">','<details class="proof" markdown="1">'),m)
    base.main()
    en_doc=BeautifulSoup((ROOT/'site/index.html').read_text(),'html.parser')
    en_headings=en_doc.select('.article > h2, .article > h3')
    for path in [OUT/'index.html',*sorted((OUT/'figures').glob('*.html'))]:
        soup=BeautifulSoup(path.read_text(),'html.parser');soup.html['lang']='ja'
        soup.title.string=title if path.name=='index.html' else f'図の拡大表示 · {title}'
        translate_ui(soup)
        if path.name=='index.html':
            h1=soup.select_one('.cover h1');h1.clear()
            # Keep a Japanese word intact at the mobile title wrap.
            pieces=title.split('、',1)
            for i,piece in enumerate(pieces):
                span=soup.new_tag('span');span.string=piece+('、' if i==0 and len(pieces)>1 else '')
                h1.append(span)
                if i==0 and len(pieces)>1:h1.append(soup.new_tag('wbr'))
            soup.select_one('.cover .dek').string=dek
            soup.select_one('.cover .byline').string='hayashiyus · 2026年11月8日公開 · 日本語版'
            soup.select_one('meta[name="description"]')['content']=dek
            soup.select_one('link[rel="canonical"]')['href']='https://hayashiyus.github.io/blog/weight-space-geometry/ja/'
            alternate=soup.select_one('link[rel="alternate"]');alternate['hreflang']='en';alternate['href']='https://hayashiyus.github.io/blog/weight-space-geometry/en/'
            for key,value in [('title',title),('description',dek),('url','https://hayashiyus.github.io/blog/weight-space-geometry/ja/')]:
                soup.select_one(f'meta[property="og:{key}"]')['content']=value
            nav=soup.select_one('.masthead nav')
            for old in list(nav.select('a[href="../ja/"]')):old.decompose()
            link=soup.new_tag('a',href='../en/');link.string='English';nav.insert(0,link)
            note=soup.new_tag('div',attrs={'class':'translation-note'})
            note.append(BeautifulSoup('<strong>確認済みの日本語推敲版</strong><p>英語原文の数式・数値・主張とその条件を保ち、日本語として読みやすい文章に整えています。著者による確認を経て、この推敲内容を英語版へ反映しました。図や動画に描き込まれた英語は原図のままです。<a href="repro/research.ja.md" download>推敲用の日本語原稿</a> · <a href="repro/translation-guide.md">編集と英語への反映手順</a></p>','html.parser'))
            soup.select_one('.cover-copy').append(note)
            headings=soup.select('.article > h2, .article > h3');toc=soup.select('.toc li a')
            assert len(headings)==len(en_headings)==len(toc),'Section count no longer aligns.'
            for ja,en,a in zip(headings,en_headings,toc):
                ja['id']=en['id'];a['href']='#'+en['id']
                if ja.name=='h2':
                    back=soup.new_tag('a',href='../en/#'+en['id'],attrs={'class':'parallel-link'});back.string='英語原文 ↗';ja.append(back)
            details=soup.new_tag('details',attrs={'class':'cover-gloss'});summary=soup.new_tag('summary');summary.string='表紙アニメーションの注釈を日本語で読む';details.append(summary)
            dl=soup.new_tag('dl')
            for english,japanese in COVER_GLOSS:
                dt=soup.new_tag('dt');dt.string=english;dd=soup.new_tag('dd');dd.string=japanese;dl.extend([dt,dd])
            details.append(dl);soup.select_one('#figure-cover').append(details)
            for a in soup.select('.site-footer a'):
                if a.get('href') in ('../index.html','../ja/'):a['href']='../en/';a.string='英語原文'
        path.write_text(str(soup))
    (OUT/'site.css').write_text((ROOT/'site.css').read_text()+'\n'+(ROOT/'site.ja.css').read_text())
    js=(ROOT/'site.js').read_text()
    for a,b in JS_UI.items():js=js.replace("'"+a+"'","'"+b+"'")
    (OUT/'site.js').write_text(js)
    for src,name in [(draft,'research.ja.md'),(ROOT/'translations/research.en.source.md','research.en.source.md'),(ROOT/'translations/README.md','translation-guide.md'),(ROOT/'translations/research.ja.initial.md','research.ja.initial.md'),(ROOT/'translations/alignment.json','translation-alignment.json')]:
        if not src.exists():continue
        shutil.copy2(src,OUT/'repro'/name)
    # Localized CSS/JS get their own cache key, independent of the English page.
    version=hashlib.sha256((OUT/'site.css').read_bytes()+(OUT/'site.js').read_bytes()).hexdigest()[:12]
    for path in [OUT/'index.html',*sorted((OUT/'figures').glob('*.html'))]:
        path.write_text(re.sub(r'(site\.(?:css|js)\?v=)[a-f0-9]+',lambda m:m[1]+version,path.read_text()))
    if args.publish_local:shutil.copytree(OUT,PUBLISH,dirs_exist_ok=True)
    print(f'Japanese article: {PUBLISH if args.publish_local else OUT}')

if __name__=='__main__':main()
