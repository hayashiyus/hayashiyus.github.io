#!/usr/bin/env python3
"""Audit fixed technical content across the initial EN/JA article pair.

This checks preservation, not semantic correctness or empirical truth. The
human/assistant editorial review is separate. Later intentional scientific
changes must be reconciled with the English source before this check can pass.
"""
from pathlib import Path
from collections import Counter
import hashlib,json,re

ROOT=Path(__file__).resolve().parent

def digest(text):return hashlib.sha256(text.encode()).hexdigest()
def protected(text):
    # The prepublication audit replaces the obsolete draft link with the
    # current Japanese article. Keep the frozen sources untouched.
    text=text.replace('](../index.html)','](../ja/)')
    return {
      'display_math':re.findall(r'(?<!\\)\\\[.*?(?<!\\)\\\]',text,re.S),
      'inline_math':re.findall(r'(?<!\\)\\\(.*?(?<!\\)\\\)',text,re.S),
      'code_blocks':re.findall(r'~~~.*?~~~',text,re.S),
      'figure_order':re.findall(r'\{\{FIG:[^}]+\}\}',text),
      'interactive_order':re.findall(r'\{\{INTERACTIVE:[^}]+\}\}',text),
      'links':re.findall(r'\]\(([^\s)]+)\)',text),
      'footnote_references':re.findall(r'\[\^[^\]]+\]',text),
      'decimal_percentage_fraction_values':re.findall(r'[-+−]?\d+\.\d+%?|\d+%|\d+/\d+',text),
    }

def main():
    english=(ROOT/'translations/research.en.source.md').read_text()
    japanese=(ROOT/'research.ja.md').read_text()
    a,b=protected(english),protected(japanese);checks={}
    for key in a:
        # Inline formula placement may change within a Japanese sentence;
        # math itself and multiplicity must remain identical.
        passed=a[key]==b[key] if key in ('figure_order','interactive_order','code_blocks','display_math') else Counter(a[key])==Counter(b[key])
        checks[key]={'passed':passed,'source_count':len(a[key]),'translation_count':len(b[key])}
        if not passed:
            checks[key]['missing']=list((Counter(a[key])-Counter(b[key])).elements())
            checks[key]['extra']=list((Counter(b[key])-Counter(a[key])).elements())
    eh=re.findall(r'^(#{2,3}) (.+)$',english,re.M)[1:]
    jh=re.findall(r'^(#{2,3}) (.+)$',japanese,re.M)[1:]
    checks['heading_structure']={'passed':[a for a,_ in eh]==[a for a,_ in jh]}
    result={'status':'PASS' if all(x['passed'] for x in checks.values()) else 'FAIL',
      'scope':'Preservation of mathematical/source structure; not an independent scientific or literature audit.',
      'english_source':'research.en.source.md','english_sha256':digest(english),
      'japanese_editable_source':'../research.ja.md','japanese_current_sha256':digest(japanese),
      'japanese_initial_sha256':digest((ROOT/'translations/research.ja.initial.md').read_text()),
      'checks':checks,'headings':[{'english':e[1],'japanese':j[1]} for e,j in zip(eh,jh)]}
    path=ROOT/'translations/alignment.json';path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if result['status']!='PASS':raise SystemExit(1)

if __name__=='__main__':main()
