#!/usr/bin/env python3
"""Bounded, reproducible WSP geometry runner (E0/E1/E3).

The runner deliberately measures fixed-prefix next-token distributions.  It does
not sample, train, or infer semantic preservation.  Public edit assets are
passed with --edit-npz and --manifest; no network access is attempted.
"""
from __future__ import annotations

import argparse, hashlib, json, os, platform, sys, tempfile, time
from pathlib import Path
from typing import Any, Iterable

import numpy as np


MODEL_REVISION = "2fc06364715b967f1860aea9cf38778875588b17"
TARGET_LAYERS = (15, 19)


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def atomic_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            for row in rows:
                f.write(json.dumps(row, ensure_ascii=False, default=_json_default) + "\n")
                f.flush()
                os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def _json_default(x: Any) -> Any:
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, (np.floating, np.integer)):
        return x.item()
    raise TypeError(type(x).__name__)


def read_manifest(path: str | Path) -> dict[str, Any]:
    with open(path, encoding="utf-8") as f:
        obj = json.load(f)
    if not isinstance(obj, dict):
        raise ValueError("manifest must be a JSON object")
    return obj


def _entries(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    for k in ("edits", "entries", "updates", "tensors"):
        if isinstance(manifest.get(k), list):
            return [x for x in manifest[k] if isinstance(x, dict)]
    return []


def load_deltas(npz_path: str | Path, manifest: dict[str, Any]) -> dict[str, Any]:
    """Load edit tensors without assuming one particular exp8 manifest spelling."""
    z = np.load(npz_path, allow_pickle=False)
    arrays = {k: np.asarray(z[k]) for k in z.files}
    out: dict[str, Any] = {}
    for ent in _entries(manifest):
        name = ent.get("name") or ent.get("tensor") or ent.get("parameter") or ent.get("key")
        key = ent.get("npz_key") or ent.get("array") or ent.get("delta_key")
        if name and key and key in arrays:
            out[str(name)] = arrays[str(key)]
        elif name and str(name) in arrays:
            out[str(name)] = arrays[str(name)]
    if not out:
        # The public exp8 sparse format stores BF16 bit values and flat indices.
        entries = _entries(manifest)
        for i, ent in enumerate(entries):
            name = ent.get("name") or ent.get("tensor")
            if name and f"t{i}_idx" in arrays and f"t{i}_val" in arrays:
                out[str(name)] = {"idx": arrays[f"t{i}_idx"], "val": arrays[f"t{i}_val"],
                                  "shape": tuple(ent.get("shape", (1024, 3584)))}
    if not out:
        # Common public edit.npz layouts: key is the full parameter name, or a
        # single delta array accompanied by names in the manifest.
        names = [e.get("name") or e.get("tensor") for e in _entries(manifest)]
        names = [str(x) for x in names if x]
        if len(arrays) == len(names) and names:
            out = dict(zip(names, arrays.values()))
        elif len(arrays) == 1 and names:
            out[names[0]] = next(iter(arrays.values()))
        elif len(arrays) == 1 and not names:
            raise ValueError("single edit array has no target name in manifest")
        else:
            out = arrays.copy()
    if not out:
        raise ValueError(f"no edit tensors found in {npz_path}")
    return out


def materialize_deltas(model: Any, specs: dict[str, Any], manifest: dict[str, Any] | None = None) -> dict[str, np.ndarray]:
    """Turn sparse BF16 replacement bits into float32 D = W_edited - W_base."""
    import torch
    out: dict[str, np.ndarray] = {}
    manifest_by_name = {str(e.get("name")): e for e in _entries(manifest or {}) if e.get("name")}
    for name, spec in specs.items():
        if isinstance(spec, dict) and "idx" in spec:
            mod = find_module(model, str(name)[:-7] if str(name).endswith(".weight") else str(name))
            base = mod.weight.detach().to(torch.float32).cpu().contiguous()
            base_bits = mod.weight.detach().cpu().contiguous().view(torch.uint16).numpy()
            ent = manifest_by_name.get(str(name), {})
            got_base = hashlib.sha256(np.ascontiguousarray(base_bits).tobytes()).hexdigest()
            if ent.get("base_sha256") and got_base != ent["base_sha256"]:
                raise ValueError(f"base BF16 hash mismatch for {name}: {got_base} != {ent['base_sha256']}")
            flat = base.reshape(-1).clone()
            vals = torch.as_tensor(spec["val"].astype(np.uint16), dtype=torch.uint16)
            # uint16 bit patterns -> BF16 float32 without relying on host endian.
            edited = (vals.to(torch.int32) << 16).view(torch.float32)
            flat[torch.as_tensor(spec["idx"], dtype=torch.long)] = edited
            edited_bits = base_bits.reshape(-1).copy()
            edited_bits[np.asarray(spec["idx"], dtype=np.int64)] = np.asarray(spec["val"], dtype=np.uint16)
            got_edited = hashlib.sha256(np.ascontiguousarray(edited_bits.reshape(base_bits.shape)).tobytes()).hexdigest()
            if ent.get("edited_sha256") and got_edited != ent["edited_sha256"]:
                raise ValueError(f"edited BF16 hash mismatch for {name}: {got_edited} != {ent['edited_sha256']}")
            out[str(name)] = (flat.reshape(base.shape) - base).numpy()
        else:
            out[str(name)] = np.asarray(spec)
    return out


def verify_weight_edit_rounding(model: Any, deltas: dict[str, np.ndarray], manifest: dict[str, Any]) -> None:
    """Check the actual module replacement, not only the reconstructed bits."""
    import torch
    with WeightEdits(model, deltas, scale=1.0):
        for ent in _entries(manifest):
            name = ent.get("name")
            if not name or not ent.get("edited_sha256"):
                continue
            mod = find_module(model, str(name)[:-7] if str(name).endswith(".weight") else str(name))
            bits = mod.weight.detach().cpu().contiguous().view(torch.uint16).numpy()
            got = hashlib.sha256(np.ascontiguousarray(bits).tobytes()).hexdigest()
            if got != ent["edited_sha256"]:
                raise ValueError(f"module replacement hash mismatch for {name}: {got} != {ent['edited_sha256']}")


class WeightEdits:
    def __init__(self, model: Any, deltas: dict[str, np.ndarray], scale: float = 1.0):
        import torch
        self.saved = []
        for name, arr in deltas.items():
            mod = find_module(model, name[:-7] if name.endswith(".weight") else name)
            old = mod.weight.data.clone()
            # Perform the edit in FP32, then round once to the module dtype. A
            # BF16 add would otherwise round D before adding it to W.
            edited = (old.float() + scale * torch.as_tensor(arr, device=old.device, dtype=torch.float32)).to(old.dtype)
            mod.weight.data.copy_(edited)
            self.saved.append((mod, old))
    def close(self):
        for mod, old in self.saved: mod.weight.data.copy_(old)
        self.saved.clear()
    def __enter__(self): return self
    def __exit__(self, *_): self.close()


def normalize_name(name: str) -> str:
    n = name.replace("module.", "", 1)
    if n.startswith("language_model."):
        n = "model." + n
    return n


def find_module(model: Any, name: str) -> Any:
    """Resolve both model.language_model.* and language_model.* public names."""
    candidates = [name, normalize_name(name)]
    if ".language_model." in name:
        candidates.append(name.split(".language_model.", 1)[1])
    for cand in dict.fromkeys(candidates):
        try:
            return model.get_submodule(cand)
        except (AttributeError, KeyError):
            pass
    obj = model
    for part in candidates[0].split("."):
        if not hasattr(obj, part):
            break
        obj = getattr(obj, part)
    else:
        return obj
    raise AttributeError(f"model module not found: {name}; tried {candidates}")


def module_weight_name(name: str) -> str:
    return name if name.endswith(".weight") else name + ".weight"


class EditHooks:
    """Apply D @ current input at down_proj outputs, preserving layer order."""
    def __init__(self, model: Any, deltas: dict[str, np.ndarray], scale: float = 1.0,
                 torch_dtype: Any = None, arithmetic_dtype: Any = None):
        import torch
        self.handles = []
        self.records: dict[str, dict[str, float]] = {}
        for raw_name, arr in deltas.items():
            name = str(raw_name)
            if ".down_proj" not in name:
                continue
            mod = find_module(model, name[:-7] if name.endswith(".weight") else name)
            d = torch.as_tensor(arr, device=mod.weight.device, dtype=torch.float32)
            if tuple(d.shape) != tuple(mod.weight.shape):
                raise ValueError(f"delta shape {tuple(d.shape)} != weight {tuple(mod.weight.shape)} for {name}")
            hook_dtype = arithmetic_dtype or mod.weight.dtype
            d = (scale * d).to(dtype=hook_dtype)
            key = module_weight_name(name)
            def hook(module, inputs, output, d=d, key=key):
                x = inputs[0]
                # Linear output is (..., out_features); D @ x is x @ D.T.
                dx = torch.matmul(x.to(d.dtype), d.t()).to(output.dtype)
                self.records[key] = {"input_l2": float(torch.linalg.vector_norm(x.float()).detach().cpu()),
                                     "delta_output_l2": float(torch.linalg.vector_norm(dx.float()).detach().cpu())}
                return output + dx
            self.handles.append(mod.register_forward_hook(hook))
        if not self.handles:
            raise ValueError("no .down_proj edit targets found")
    def close(self) -> None:
        for h in self.handles:
            h.remove()
        self.handles.clear()
    def __enter__(self): return self
    def __exit__(self, *_): self.close()


def load_text_model(model_id: str, revision: str, device: str):
    import torch
    from transformers import AutoTokenizer
    try:
        from transformers import AutoModelForImageTextToText
        cls = AutoModelForImageTextToText
    except ImportError:
        from transformers import AutoModelForCausalLM as cls
    kwargs = dict(revision=revision, torch_dtype=torch.bfloat16, local_files_only=True)
    try:
        model = cls.from_pretrained(model_id, **kwargs)
    except (AttributeError, ValueError):
        from transformers import AutoModelForCausalLM
        model = AutoModelForCausalLM.from_pretrained(model_id, **kwargs)
    tok = AutoTokenizer.from_pretrained(model_id, revision=revision, local_files_only=True)
    model.to(device).eval()
    return model, tok


def prefixes_from_file(path: str | None, fallback: list[str]) -> list[str]:
    if not path:
        raise ValueError("real prefix input is required (--texts and --math-prefixes)")
    p = Path(path)
    if p.suffix.lower() == ".json":
        obj = json.loads(p.read_text(encoding="utf-8"))
        if isinstance(obj, dict): obj = obj.get("texts", obj.get("prefixes", []))
        return [str(x) for x in obj]
    return [x.strip() for x in p.read_text(encoding="utf-8").splitlines() if x.strip()]


def logits_for(model: Any, tok: Any, text: str, device: str) -> tuple[Any, int]:
    import torch
    batch = tok(text, return_tensors="pt", add_special_tokens=True)
    batch = {k: v.to(device) for k, v in batch.items() if k in ("input_ids", "attention_mask")}
    with torch.inference_mode():
        try:
            out = model(**batch, use_cache=False, logits_to_keep=1)
        except TypeError:
            out = model(**batch, use_cache=False)
    return out.logits[:, -1, :].float().detach(), int(batch["input_ids"].shape[-1])


def dist_metrics(base: Any, other: Any) -> dict[str, float]:
    import torch
    p = torch.softmax(base.double(), -1)
    logp = torch.log_softmax(base.double(), -1)
    logq = torch.log_softmax(other.double(), -1)
    diff = other - base
    kl = torch.sum(p * (logp - logq), -1)
    return {"l2": float(torch.linalg.vector_norm(diff).cpu()), "maxdiff": float(diff.abs().max().cpu()),
            "kl_p_to_q": float(kl.cpu())}


def env_record(args: argparse.Namespace, npz_path: Path, manifest_path: Path) -> dict[str, Any]:
    rec = {"runner": "wsp_geometry", "python": platform.python_version(), "platform": platform.platform(),
           "model_revision": args.revision, "edit_npz_sha256": sha256_file(npz_path),
           "manifest_sha256": sha256_file(manifest_path), "edit_npz": str(npz_path), "manifest": str(manifest_path)}
    try:
        import torch, transformers
        rec.update({"torch": torch.__version__, "transformers": transformers.__version__,
                    "cuda": torch.version.cuda, "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None})
    except Exception as e: rec["version_error"] = repr(e)
    return rec


def run(args: argparse.Namespace) -> Path:
    import torch
    npz_path, manifest_path = Path(args.edit_npz), Path(args.manifest)
    manifest = read_manifest(manifest_path)
    delta_specs = load_deltas(npz_path, manifest)
    model, tok = load_text_model(args.model, args.revision, args.device)
    deltas = materialize_deltas(model, delta_specs, manifest)
    verify_weight_edit_rounding(model, deltas, manifest)
    if args.stage == "e1fp32":
        model.float()
    texts = prefixes_from_file(args.texts, [])
    math = prefixes_from_file(args.math_prefixes, [])
    outpath = Path(args.output)
    started = time.time()
    rows: list[dict[str, Any]] = [{"event": "metadata", **env_record(args, npz_path, manifest_path), "targets": sorted(deltas)}]
    fisher_cache: dict[str, dict[str, float]] = {}
    def measure(group: str, items: list[str], dose: float = 1.0, fisher: bool = False):
        for i, text in enumerate(items):
            if torch.cuda.is_available(): torch.cuda.reset_peak_memory_stats()
            base, ntok = logits_for(model, tok, text, args.device)
            baseline_repeat, ntok2 = logits_for(model, tok, text, args.device)
            with WeightEdits(model, deltas, scale=dose):
                stored, _ = logits_for(model, tok, text, args.device)
            with EditHooks(model, deltas, scale=dose) as hooks:
                edited, _ = logits_for(model, tok, text, args.device)
            with EditHooks(model, deltas, scale=dose, arithmetic_dtype=torch.float32):
                fp32_hook, _ = logits_for(model, tok, text, args.device)
            row = {"event": "measurement", "stage": args.stage, "group": group, "index": i, "dose": dose,
                   "tokens": ntok * 5, "forward_calls": 5, "model_dtype": str(next(model.parameters()).dtype),
                   "text_sha256": hashlib.sha256(text.encode()).hexdigest(),
                   "metrics": dist_metrics(base, edited), "stored_weight_metrics": dist_metrics(base, stored),
                   "hook_vs_stored": dist_metrics(stored, edited), "fp32_arithmetic_isolation": dist_metrics(edited, fp32_hook),
                   "baseline_repeat": dist_metrics(base, baseline_repeat),
                   "hook_records": hooks.records,
                   "elapsed_s": time.time() - started}
            if fisher:
                key = hashlib.sha256(text.encode()).hexdigest()
                if key not in fisher_cache:
                    row["tokens"] += ntok * 6
                    row["forward_calls"] += 6
                    p = torch.softmax(base.double(), -1)
                    vals = {}
                    for eps in (0.001, 0.003, 0.01):
                        with EditHooks(model, deltas, scale=eps): lp, _ = logits_for(model, tok, text, args.device)
                        with EditHooks(model, deltas, scale=-eps): lm, _ = logits_for(model, tok, text, args.device)
                        dlogp = (torch.log_softmax(lp.double(), -1) - torch.log_softmax(lm.double(), -1)) / (2 * eps)
                        vals[str(eps)] = float(torch.sum(p * dlogp.square()).cpu())
                    fisher_cache[key] = vals
                f = fisher_cache[key]["0.001"]
                row["fisher"] = f
                row["fisher_by_eps"] = fisher_cache[key]
                row["fisher_anchor"] = "dose_0"
                row["fisher_quadratic"] = 0.5 * dose * dose * f
            if torch.cuda.is_available(): row["gpu_peak_bytes"] = torch.cuda.max_memory_allocated()
            rows.append(row)
            atomic_jsonl(outpath, rows)
            print(json.dumps({"progress": len(rows) - 1, "group": group, "index": i, "dose": dose}), flush=True)
    if args.stage in ("all", "e0", "e1", "e1fp32"):
        measure("contrast8", texts)
    if args.stage in ("all", "e1", "e1fp32"):
        # E1's hook path is the exact stored D @ a intervention, including prior hooks.
        measure("independent_math", math)
    if args.stage in ("all", "e3"):
        model.float()
        for d in [0.001, 0.003, 0.01, 0.03, 0.1, 0.3, 1.0]:
            measure("heldout_math_dose", math, dose=d, fisher=True)
    atomic_jsonl(outpath, rows)
    return outpath


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", choices=["all", "e0", "e1", "e1fp32", "e3"], default="all")
    ap.add_argument("--model", required=True)
    ap.add_argument("--revision", default=MODEL_REVISION)
    ap.add_argument("--edit-npz", required=True)
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--texts")
    ap.add_argument("--math-prefixes")
    ap.add_argument("--output", required=True)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--fisher-eps", type=float, default=1e-3)
    args = ap.parse_args()
    try:
        run(args)
    except Exception as e:
        err = {"event": "error", "error": repr(e), "elapsed_s": 0.0}
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        with open(args.output, "a", encoding="utf-8") as f: f.write(json.dumps(err) + "\n")
        raise


if __name__ == "__main__": main()
