import json
import tempfile
from pathlib import Path

import numpy as np

from wsp_runner import atomic_jsonl, load_deltas, read_manifest


def test_public_sparse_edit_is_discovered():
    root = Path(__file__).parents[1] / "data" / "wsp_public"
    manifest = read_manifest(root / "runs/p50c/edit/manifest.json")
    d = load_deltas(root / "runs/p50c/edit/edit.npz", manifest)
    assert set(d) == {x["name"] for x in manifest["tensors"]}
    assert all("idx" in x and "val" in x for x in d.values())


def test_atomic_jsonl_roundtrip():
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "x.jsonl"
        atomic_jsonl(p, [{"event": "ok", "value": np.int64(3)}])
        assert json.loads(p.read_text()) == {"event": "ok", "value": 3}
