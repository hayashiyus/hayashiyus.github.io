"""Resumable MATH-500 generation evaluation for the WSP edit.

This module deliberately keeps model loading in ``run`` (so aggregation and
CPU tests do not import vLLM).  One compressed chunk is the unit of resume;
completed chunks are never rewritten.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import importlib.metadata as md
import json
import os
import random
import sys
import time
from pathlib import Path

SAMPLING = {
    "temperature": 0.6, "top_p": 0.95, "top_k": 20,
    "presence_penalty": 1.5, "max_tokens": 32768, "seed": 0,
}
PROMPT_SUFFIX = "Please reason step by step, and put your final answer within \\boxed{}."


def _load_rows(path: Path):
    obj = json.loads(path.read_text()) if path.suffix != ".jsonl" else [json.loads(x) for x in path.read_text().splitlines()]
    rows = obj.get("rows", obj) if isinstance(obj, dict) else obj
    if not isinstance(rows, list):
        raise ValueError("dataset must be a list (or {rows: [...]})")
    # MATH-500's frozen public file calls the key unique_id; normalize only at
    # the boundary so output IDs are stable and unambiguous.
    for r in rows:
        if "id" not in r and "unique_id" in r:
            r["id"] = r["unique_id"]
    required = {"id", "problem", "answer"}
    if any(not required.issubset(r) for r in rows):
        raise ValueError("each dataset row requires id/unique_id, problem, answer")
    ids = [str(r["id"]) for r in rows]
    if len(ids) != len(set(ids)):
        raise ValueError("dataset ids must be unique")
    return rows


def _sha256(path: Path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _versions():
    out = {}
    for name in ("vllm", "transformers", "torch", "math-verify", "flashinfer-python", "flashinfer-cubin"):
        try:
            out[name] = md.version(name)
        except md.PackageNotFoundError:
            out[name] = None
    return out


def _mathqa(scorer_dir=None):
    src = Path(scorer_dir) if scorer_dir else Path(__file__).parents[1] / "data/wsp_public/code"
    sys.path.insert(0, str(src))
    # The public scorer imports the training harness' loop detector at module
    # import time.  Keep the scorer source (including math-verify 0.9.0) exact,
    # while supplying the tiny optional import needed by this standalone job.
    import types
    if "mcqa" not in sys.modules:
        shim = types.ModuleType("mcqa")
        shim.loop_signals = lambda text: (_ for _ in ()).throw(NotImplementedError("loop detector is not used by generation scoring"))
        sys.modules["mcqa"] = shim
    import mathqa  # type: ignore
    return mathqa


def _prompt(tok, problem, thinking=True):
    user = problem + "\n" + PROMPT_SUFFIX
    return tok.apply_chat_template([{"role": "user", "content": user}], tokenize=False,
                                   add_generation_prompt=True, enable_thinking=thinking)


def _chunk_file(out: Path, i: int):
    return out / (f"responses-{i:06d}.jsonl.gz")


def _gpu_ms(torch, start, end):
    if start is None:
        return None
    end.record()
    end.synchronize()
    return float(start.elapsed_time(end))


def _generate_chunk(llm, prompts, sampling, torch):
    from vllm import SamplingParams
    before = after = None
    if torch is not None and torch.cuda.is_available():
        torch.cuda.synchronize()
        before, after = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
        before.record()
    started = time.perf_counter()
    outs = llm.generate(prompts, SamplingParams(n=sampling["n"], temperature=sampling["temperature"],
        top_p=sampling["top_p"], top_k=sampling["top_k"], presence_penalty=sampling["presence_penalty"],
        max_tokens=sampling["max_tokens"], seed=sampling["seed"]))
    elapsed = time.perf_counter() - started
    gpu_ms = _gpu_ms(torch, before, after)
    return outs, elapsed, gpu_ms


def run(args):
    process_started = time.monotonic()
    rows = _load_rows(Path(args.data))
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    mathqa = _mathqa(args.scorer_dir)
    data_sha = _sha256(Path(args.data))
    sampling = dict(SAMPLING, n=args.samples)
    manifest = {"schema": 1, "arm": args.arm, "model": str(Path(args.model).resolve()),
                "data": str(Path(args.data).resolve()), "data_sha256": data_sha,
                "n_problems": len(rows), "samples": args.samples, "chunk_size": args.chunk_size,
                "sampling": sampling, "thinking": True, "versions": _versions(),
                "gpu_index": args.gpu_index, "gpu_memory_utilization": args.gpu_memory_utilization,
                "execution": {"max_num_seqs": args.max_num_seqs, "max_model_len": args.max_model_len,
                  "enforce_eager": args.enforce_eager, "attention_backend": "TRITON_ATTN",
                  "gdn_prefill_backend": "triton", "flashinfer_sampler": False}}
    mp = out / "run.json"
    if mp.exists() and json.loads(mp.read_text()) != manifest:
        raise RuntimeError("existing output has a different run manifest; choose a new --out")
    mp.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")

    from vllm import LLM
    from vllm.config import KernelConfig
    from vllm.v1.attention.backends.registry import AttentionBackendEnum
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    llm_kw = dict(model=args.model, dtype="bfloat16", gpu_memory_utilization=args.gpu_memory_utilization,
                  # vLLM's max_model_len includes the prompt; leave room for
                  # the MATH instruction plus the full 32,768-token completion.
                  max_model_len=args.max_model_len, seed=0, max_num_seqs=args.max_num_seqs,
                  enable_chunked_prefill=True, enforce_eager=args.enforce_eager,
                  trust_remote_code=False, limit_mm_per_prompt={"image": 0, "video": 0},
                  max_num_batched_tokens=4096, attention_backend=AttentionBackendEnum.TRITON_ATTN,
                  gdn_prefill_backend="triton",
                  kernel_config=KernelConfig(enable_flashinfer_autotune=False, enable_cutedsl_warmup=False))
    llm = LLM(**llm_kw)
    deadline = time.monotonic() + args.max_seconds if args.max_seconds else None
    for start in range(0, len(rows), args.chunk_size):
        ci = start // args.chunk_size
        fp = _chunk_file(out, ci)
        if fp.exists():
            continue
        if deadline is not None and time.monotonic() >= deadline:
            print("time budget reached; resume with the same command", flush=True)
            break
        part = rows[start:start + args.chunk_size]
        prompts = [_prompt(tok, r["problem"], True) for r in part]
        outs, elapsed, gpu_ms = _generate_chunk(llm, prompts, sampling, None)
        records = []
        if len(outs) != len(part):
            raise RuntimeError(f"vLLM returned {len(outs)} outputs for {len(part)} prompts")
        for row, req in zip(part, outs):
            if len(req.outputs) != args.samples:
                raise RuntimeError(f"problem {row['id']} returned {len(req.outputs)} samples")
            for j, s in enumerate(req.outputs):
                if s.finish_reason not in ("stop", "length"):
                    raise RuntimeError(f"Incomplete generation: {row['id']}, finish={s.finish_reason}")
                text = s.text
                grade = mathqa.score({"gold": str(row["answer"])}, text, finish=s.finish_reason)
                records.append({"id": str(row["id"]), "sample": j, "text": text,
                    "token_count": len(s.token_ids), "finish_reason": s.finish_reason,
                    "elapsed_s": elapsed, "gpu_time_ms": None,
                    "pred": grade["pred"], "boxed": grade["boxed"], "correct": grade["correct"],
                    "accuracy_equiv": grade["equiv"], "truncated": s.finish_reason == "length"})
        tmp = fp.with_suffix(fp.suffix + ".tmp")
        with gzip.open(tmp, "wt", encoding="utf-8") as f:
            for rec in records:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        os.replace(tmp, fp)
        (out / f"chunk-{ci:06d}.json").write_text(json.dumps({
            "chunk": ci, "generation_wall_s": elapsed, "problems": len(part),
            "samples": len(records), "output_tokens": sum(x["token_count"] for x in records),
            "input_tokens": sum(len(x.prompt_token_ids) for x in outs),
            "process_elapsed_s": time.monotonic() - process_started,
        }, indent=2))
        print(f"completed chunk={ci} problems={len(part)} elapsed_s={elapsed:.2f}", flush=True)
    aggregate(out, rows, args.samples)
    (out / "session_wall.json").write_text(json.dumps({"wall_seconds": time.monotonic() - process_started,
        "interpretation": "elapsed wall time of a single GPU-owning job; not exclusive GPU compute time"}))


def _read_records(out):
    for fp in sorted(out.glob("responses-*.jsonl.gz")):
        with gzip.open(fp, "rt", encoding="utf-8") as f:
            yield from (json.loads(line) for line in f if line.strip())


def aggregate(out: Path, rows, samples):
    records = list(_read_records(out))
    by = {str(r["id"]): [] for r in rows}
    for r in records:
        if r["id"] in by:
            by[r["id"]].append(r)
    vals = [sum(x["correct"] for x in rs) / samples for rs in by.values() if len(rs) == samples]
    missing = [k for k, rs in by.items() if len(rs) != samples]
    boots = []
    if vals:
        rng = random.Random(20261105)
        for _ in range(2000):
            boots.append(sum(vals[rng.randrange(len(vals))] for _ in vals) / len(vals))
        boots.sort()
    summary = {"n_records": len(records), "n_complete_problems": len(vals), "missing_problem_ids": missing,
               "samples_per_problem": samples, "accuracy_over_samples": (sum(r["correct"] for r in records) / len(records) if records else None),
               "cluster_mean_accuracy": (sum(vals) / len(vals) if vals else None),
               "cluster_bootstrap_95ci": ([boots[50], boots[1949]] if boots else None),
               "truncated": sum(r["truncated"] for r in records), "no_boxed": sum(not r["boxed"] for r in records),
               "token_count_sum": sum(r["token_count"] for r in records),
               "generation_wall_s": sum(json.loads(p.read_text())["generation_wall_s"] for p in out.glob("chunk-*.json")),
               "gpu_compute_time": None}
    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--model")
    p.add_argument("--data", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--arm", choices=("base", "edited"), required=True)
    p.add_argument("--samples", type=int, default=4)
    p.add_argument("--chunk-size", type=int, default=16)
    p.add_argument("--gpu-index", type=int, default=0)
    p.add_argument("--gpu-memory-utilization", type=float, default=0.20)
    p.add_argument("--max-num-seqs", type=int, default=16)
    p.add_argument("--max-model-len", type=int, default=40960)
    p.add_argument("--enforce-eager", action="store_true")
    p.add_argument("--scorer-dir", help="directory containing the public mathqa.py")
    p.add_argument("--aggregate-only", action="store_true")
    p.add_argument("--max-seconds", type=float, default=None)
    a = p.parse_args(argv)
    if not 1 <= a.samples <= 64 or a.chunk_size < 1:
        p.error("samples must be 1..64 and chunk-size positive")
    if a.aggregate_only:
        rows = _load_rows(Path(a.data))
        print(json.dumps(aggregate(Path(a.out), rows, a.samples), indent=2))
    else:
        if not a.model:
            p.error("--model is required unless --aggregate-only is used")
        run(a)


if __name__ == "__main__":
    main()
