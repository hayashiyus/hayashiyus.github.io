"""Build a vLLM model view from an edited full checkpoint without duplicating metadata."""
import argparse
import os
import shutil
from pathlib import Path


def export(source: Path, edited: Path, out: Path):
    out.mkdir(parents=True, exist_ok=True)
    for src in source.iterdir():
        dst = out / src.name
        if src.name.startswith("model") and src.suffix in (".safetensors", ".json"):
            continue
        if dst.exists() or dst.is_symlink():
            continue
        os.symlink(src.resolve(), dst)
    weights = [p for p in edited.iterdir() if p.name.startswith("model") and p.suffix == ".safetensors"]
    if not weights:
        raise FileNotFoundError("edited checkpoint has no model*.safetensors")
    for src in weights:
        dst = out / src.name
        if not dst.exists():
            shutil.copy2(src, dst)
    print(f"exported {len(weights)} weight file(s) to {out}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("edited", type=Path)
    ap.add_argument("out", type=Path)
    a = ap.parse_args()
    export(a.source, a.edited, a.out)
