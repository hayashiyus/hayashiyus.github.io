import gzip
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from runner import aggregate


def test_cluster_aggregation_does_not_treat_samples_as_independent(tmp_path):
    rows = [{"id": "a", "problem": "p", "answer": "1"}, {"id": "b", "problem": "q", "answer": "2"}]
    with gzip.open(tmp_path / "responses-000000.jsonl.gz", "wt") as f:
        for sid, ok in (("a", 1), ("b", 0)):
            for sample in range(4):
                f.write(json.dumps({"id": sid, "sample": sample, "correct": ok,
                                    "boxed": True, "truncated": False,
                                    "token_count": 1, "gpu_time_ms": 2}) + "\n")
    got = aggregate(tmp_path, rows, 4)
    assert got["accuracy_over_samples"] == 0.5
    assert got["cluster_mean_accuracy"] == 0.5
    assert got["n_complete_problems"] == 2


def test_aggregation_reports_incomplete_resume_chunk(tmp_path):
    with gzip.open(tmp_path / "responses-000000.jsonl.gz", "wt") as f:
        f.write(json.dumps({"id": "a", "sample": 0, "correct": 1, "boxed": True,
                            "truncated": False, "token_count": 1, "gpu_time_ms": None}) + "\n")
    got = aggregate(tmp_path, [{"id": "a", "problem": "p", "answer": "1"}], 2)
    assert got["n_complete_problems"] == 0
    assert got["missing_problem_ids"] == ["a"]
