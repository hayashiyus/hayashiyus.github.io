from e2_controls import make_cases
class Tok:
 def __call__(self,text,add_special_tokens=False): return {"input_ids":list(range(300))}
 def apply_chat_template(self,messages,**kw):
  assert "problem" in messages[0]["content"]
  return [999]
def test_continuations_and_repeat_targets():
 cs=make_cases({"problem":"problem", "solution":"solution"},Tok())
 assert cs[0]["prefix"][0]==999
 assert cs[0]["target"]==list(range(128,144))
 assert cs[1]["target"]==list(range(112,128))
 assert cs[1]["prefix"][-96:]==list(range(112,128))*6
