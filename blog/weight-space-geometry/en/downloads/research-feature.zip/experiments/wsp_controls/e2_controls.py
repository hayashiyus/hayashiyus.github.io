#!/usr/bin/env python3
"""Synthetic teacher-forced continuation controls; NOT a free-running necessity test."""
from __future__ import annotations
import argparse, hashlib, json, sys, time
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'wsp_geometry'))
from wsp_runner import MODEL_REVISION,find_module,load_deltas,materialize_deltas,read_manifest,load_text_model,verify_weight_edit_rounding
SEED=20261105
GRID=(.25,.5,1.,2.,4.)

def make_cases(row,tok,prefix_tokens=128,target_tokens=16):
    ids=tok(str(row['solution']),add_special_tokens=False)['input_ids']
    if len(ids)<=target_tokens:return []
    n=min(prefix_tokens,len(ids)-target_tokens)
    instruction=row['problem']+'\nPlease reason step by step, and put your final answer within \\boxed{}.'
    chat=tok.apply_chat_template([{'role':'user','content':instruction}],tokenize=True,add_generation_prompt=True,enable_thinking=True)
    if hasattr(chat,'keys'):chat=chat['input_ids']
    block=(ids[:n]*16)[-16:]
    return [{'kind':'productive','prefix':chat+ids[:n],'target':ids[n:n+16]},
            {'kind':'repetitive','prefix':chat+ids[:n]+block*6,'target':block}]

class Control:
    def __init__(self,model,deltas,method,gain=1.,vectors=None,donor=None,capture=False):
        import torch
        self.handles=[];self.norms={};self.captured={}
        for j,(key,arr) in enumerate(deltas.items()):
            mod=find_module(model,key[:-7]); d=torch.as_tensor(arr,device=mod.weight.device,dtype=torch.float32)
            rng=np.random.default_rng(SEED+j);z=rng.normal(size=d.shape[0]);z/=np.linalg.norm(z)
            unit=torch.tensor(z,device=d.device,dtype=d.dtype).view(1,1,-1)
            def hook(module,inputs,output,d=d,key=key,unit=unit):
                dx=inputs[0].float()@d.T
                if method=='exact':add=dx
                elif method=='constant':add=vectors[key].to(dx.device).view(1,1,-1).expand_as(dx)
                elif method=='shuffle':
                    seq=donor[key];ii=torch.linspace(0,seq.shape[1]-1,dx.shape[1]).round().long()
                    add=seq[:,ii,:].to(dx.device)
                elif method=='random':add=torch.linalg.vector_norm(dx,dim=-1,keepdim=True)*unit
                else:raise ValueError(method)
                add=add*gain
                self.norms[key]=float(torch.linalg.vector_norm(add).cpu())
                if capture:self.captured[key]=add.detach().cpu()
                return output+add.to(output.dtype)
            self.handles.append(mod.register_forward_hook(hook))
    def __enter__(self):return self
    def __exit__(self,*_):
        for h in self.handles:h.remove()

def score(model,case,device):
    import torch
    ids=case['prefix']+case['target'][:-1];t=torch.tensor([ids],device=device)
    with torch.inference_mode():out=model(input_ids=t,attention_mask=torch.ones_like(t),use_cache=False,logits_to_keep=16)
    logits=out.logits[:,-16:,:].float();target=torch.tensor(case['target'],device=device).view(1,16,1)
    lp=torch.log_softmax(logits,-1).gather(-1,target).mean().item()
    first=torch.log_softmax(logits[0,0,:].double(),-1).cpu().numpy()
    return lp,first,len(ids)

def main(a):
    import torch
    started=time.monotonic();torch.manual_seed(SEED)
    model,tok=load_text_model(a.model,MODEL_REVISION,a.device)
    man=read_manifest(a.manifest);deltas=materialize_deltas(model,load_deltas(a.edit_npz,man),man)
    verify_weight_edit_rounding(model,deltas,man);model.float()
    source=json.loads(Path(a.data).read_text());cases=[]
    for i,r in enumerate(source[:48]):
        for c in make_cases(r,tok):cases.append(dict(c,id=r.get('unique_id',r.get('id')),split='cal' if i<16 else 'eval',index=i))
    bases={};exact={};seqs={};processed=0;calls=0
    def run(c,method=None,gain=1.,vectors=None,donor=None,capture=False):
        nonlocal processed,calls
        if method:
            with Control(model,deltas,method,gain,vectors,donor,capture) as ctl:
                value,lp,nt=score(model,c,a.device)
            extra=(ctl.norms,ctl.captured)
        else:value,lp,nt=score(model,c,a.device);extra=({}, {})
        processed+=nt;calls+=1
        return value,lp,extra
    for c in cases:
        key=(c['index'],c['kind']);bases[key]=run(c)[:2]
        val,lp,ex=run(c,'exact',capture=True);exact[key]=(val,lp);seqs[key]=ex[1]
    cal=[c for c in cases if c['split']=='cal' and c['kind']=='repetitive']
    vectors={k:sum(seqs[(c['index'],c['kind'])][k].sum((0,1)) for c in cal)/sum(seqs[(c['index'],c['kind'])][k].shape[1] for c in cal) for k in deltas}
    donor_keys={}
    for split in ['cal','eval']:
        for kind in ['productive','repetitive']:
            cs=[c for c in cases if c['split']==split and c['kind']==kind]
            for j,c in enumerate(cs):donor_keys[(c['index'],kind)]=(cs[(j+1)%len(cs)]['index'],kind)
    target=float(np.mean([exact[(c['index'],c['kind'])][0]-bases[(c['index'],c['kind'])][0] for c in cal]))
    calibration={};gains={'exact':1.}
    for method in ['constant','shuffle','random']:
        curve={}
        for g in GRID:
            changes=[]
            for c in cal:
                k=(c['index'],c['kind']);v,_,_=run(c,method,g,vectors,seqs[donor_keys[k]])
                changes.append(v-bases[k][0])
            curve[str(g)]=float(np.mean(changes))
        gain=min(GRID,key=lambda g:abs(curve[str(g)]-target));gains[method]=gain
        residual=curve[str(gain)]-target
        calibration[method]={'gain':gain,'curve':curve,'target':target,'residual':residual,'match_failure':abs(residual)>max(.01,.1*abs(target))}
        print('calibration',method,calibration[method],flush=True)
    out=[]
    for c in [c for c in cases if c['split']=='eval']:
        k=(c['index'],c['kind'])
        for method in ['exact','constant','shuffle','random']:
            value,lp,ex=run(c,method,gains[method],vectors,seqs[donor_keys[k]])
            bval,blp=bases[k];kl=float(np.sum(np.exp(blp)*(blp-lp)))
            out.append({'id':c['id'],'index':c['index'],'condition':c['kind'],'method':method,'gain':gains[method],
                'baseline_logp':bval,'target_logp_delta_mean':value-bval,'first_target_raw_kl':kl,'intervention_l2':ex[0],
                'donor_index':donor_keys[k][0] if method=='shuffle' else None})
        payload={'scope':'synthetic teacher-forced continuation; repetitive states are constructed, not model generated',
            'seed':SEED,'dtype':'float32','calibration_repetitive_cases':len(cal),'evaluation_indices':[x['index'] for x in cases if x['split']=='eval' and x['kind']=='productive'],
            'calibration':calibration,'rows':out,'forward_calls':calls,'processed_tokens':processed,'wall_seconds':time.monotonic()-started,
            'gpu_peak_bytes':torch.cuda.max_memory_allocated()}
        path=Path(a.output);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(payload,indent=2));tmp.replace(path)
    print('complete',len(out),'wall_s',time.monotonic()-started,flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ['model','edit-npz','manifest','data','output']:p.add_argument('--'+name,required=True)
    p.add_argument('--device',default='cuda');main(p.parse_args())
