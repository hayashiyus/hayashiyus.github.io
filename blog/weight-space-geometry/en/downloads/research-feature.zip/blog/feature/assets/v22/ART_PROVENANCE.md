# Static art and animated compositing

Two static image edits were generated with the built-in image_gen tool on 7 November 2026. No Weave generation was used.

1. `straight-reference.png`: edit target `../v14/sluice-reference.png`. Prompt: preserve canvas, both Kabuki actors, gate, all upstream bends and sumi landscape; straighten ONLY the last lower-right reach into parallel whitewood banks, gently descending from (975,660) toward (1400,745), with the existing ordinary waterfall at its end; remove the last boat; preserve the delicate pale watercolor and restore natural adjacent plants without stretching; add no ramps, branches, text or objects.
2. `straight-clean-plate.png`: edit target `straight-reference.png`. Prompt: preserve the painting and straight final reach exactly; remove the right actor, his entire pole, and all paper boats; reconstruct water, ink plants, rocks and white paper without blur or ghost outlines; retain the left actor and gate.

The original actor meshes and separate boat sprite are reintroduced by `render.py`. The local visible spillway geometry is rendered from the numerical bed. `gate_paint.py` provides optics only; a corrected mask no longer overwrites the dry wood beside the gate. `waterfall_paint.py` animates the painted main fall rather than overlaying a second outlet. Neither optical pass is a resolved 3D fluid simulation.

The main-outlet revision uses the same static plate, with no new image/video generation. `MainFall` transports its watercolor pigment through one curved atlas from the reach over the lip to the falling sheet; a coupled optical clock drives the receiving pool. The source plate is fully replaced inside the water, while wood and rocks remain outside the moving mask.
