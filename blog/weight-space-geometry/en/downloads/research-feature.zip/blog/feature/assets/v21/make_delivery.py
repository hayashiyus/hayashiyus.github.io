"""Export directly from the final encoded movie; preserve source frames."""
from pathlib import Path
import subprocess,json
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parent

def ff(*args):
 subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error',*map(str,args)],check=True)

def main():
 movie=R/'motion-review.mp4'
 for t in [0,2,4,5,6,7,8,9,11,12,14,16,18,20]:
  ff('-ss',t,'-i',movie,'-frames:v',1,'-q:v',2,R/f'frame-{t:02}.jpg')
 Image.open(R/'frame-09.jpg').save(R/'poster.jpg',quality=94)
 Image.open(R/'frame-07.jpg').crop((930,570,1500,900)).resize((1140,660),Image.Resampling.LANCZOS).save(R/'detail-water.jpg',quality=95)
 ff('-i',movie,'-vf','fps=12,scale=768:-1:flags=lanczos,split[s0][s1];[s0]palettegen=max_colors=192[p];[s1][p]paletteuse=dither=bayer:bayer_scale=3','-loop',0,R/'motion-review.gif')
 for name,start,duration,crop in [('water',0,10,'650:410:850:595'),('left',0,10,'510:470:0:90'),('right',11,8,'630:650:900:275')]:
  ff('-ss',start,'-i',movie,'-t',duration,'-vf',f'crop={crop},scale=1140:-2:flags=lanczos','-an','-c:v','libx264','-crf',18,'-pix_fmt','yuv420p','-movflags','+faststart',R/f'detail-{name}.mp4')
  ff('-ss',duration*.65,'-i',R/f'detail-{name}.mp4','-frames:v',1,'-q:v',2,R/f'detail-{name}.jpg')
 times=[0,2,4,5,6,7,8,9,12,14,16,18]
 sheet=Image.new('RGB',(1536,4*370),(253,252,249));d=ImageDraw.Draw(sheet)
 font=ImageFont.truetype('/System/Library/Fonts/Helvetica.ttc',20)
 for k,t in enumerate(times):
  im=Image.open(R/f'frame-{t:02}.jpg').resize((512,341),Image.Resampling.LANCZOS)
  x=(k%3)*512;y=(k//3)*370;sheet.paste(im,(x,y));d.text((x+15,y+343),f'{t:02d}s',font=font,fill=(50,70,90))
 sheet.save(R/'storyboard.jpg',quality=94)
 Image.open(R/'frame-09.jpg').crop((850,595,1500,1005)).resize((1140,719),Image.Resampling.LANCZOS).save(R/'detail-water.jpg',quality=95)
 probe=subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(movie)],text=True)
 (R/'media-probe.json').write_text(probe)
 print('Exported final frames, 12fps GIF, water/left/right clips and storyboard.')

if __name__=='__main__':main()
