"""Read-only physical QA for frozen v21 outputs; never runs physics.py."""
from pathlib import Path
import json, sys
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import physics
import fluid_solver
from hybrid import Water as HybridWater

def corners(state):
    x, y, yaw = state[1:4]; c, s = np.cos(yaw), np.sin(yaw)
    return np.array([[x + sx*c*physics.L/2 - sy*s*physics.WIDTH/2,
                      y + sx*s*physics.L/2 + sy*c*physics.WIDTH/2]
                     for sx in (-1, 1) for sy in (-1, 1)])

def interp_state(arr, t):
    return np.array([np.interp(t, arr[:, 0], arr[:, k]) for k in range(1, 7)])

def interp_field(d, key, t, xy):
    j = int(np.clip(np.searchsorted(d['t'], t), 1, len(d['t'])-1))
    a = (t-d['t'][j-1])/(d['t'][j]-d['t'][j-1])
    fields = [(1-a)*d[f'{v}_{key}'][j-1] + a*d[f'{v}_{key}'][j] for v in ('h','u','v')]
    x, y = d['x'], d['y']; X, Y = np.asarray(xy, float).T
    ix = np.clip(np.searchsorted(x, X), 1, len(x)-1); iy = np.clip(np.searchsorted(y, Y), 1, len(y)-1)
    wx = (X-x[ix-1])/(x[ix]-x[ix-1]); wy = (Y-y[iy-1])/(y[iy]-y[iy-1])
    def bil(A):
        return (1-wx)*(1-wy)*A[iy-1,ix-1] + wx*(1-wy)*A[iy-1,ix] + (1-wx)*wy*A[iy,ix-1] + wx*wy*A[iy,ix]
    return [bil(A) for A in fields]

def sill_stats(d, key):
    i = int(np.argmin(abs(d['y']-.245))); ap = (d['x'] >= .47) & (d['x'] <= .69)
    h = d[f'h_{key}'][:, i, ap]; q = (h*d[f'v_{key}'][:, i, ap]).sum(1)*(d['x'][1]-d['x'][0])
    return {'row_y_m': float(d['y'][i]), 'max_depth_m': float(h.max()), 'peak_discharge_m3_s': float(q.max()), 'final_discharge_m3_s': float(q[-1])}

def main():
    coarse = {k: np.array(v) for k,v in np.load(ROOT/'fluid_fields.npz').items()}
    refined = {k: np.array(v) for k,v in np.load(ROOT/'fluid-fields-refined.npz').items()}
    extended = {k: np.array(v) for k,v in np.load(ROOT/'fluid-fields-extended.npz').items()}
    boats = {k: np.array(v) for k,v in np.load(ROOT/'boat_states.npz').items()}
    report = {'files': {'boat_states': 'boat_states.npz', 'coarse': 'fluid_fields.npz', 'refined': 'fluid-fields-refined.npz', 'extended': 'fluid-fields-extended.npz'}, 'schema': {}, 'checks': {}}
    contract = json.loads((ROOT/'physics-contract.json').read_text())
    report['schema'] = {'boat_columns': ['t','x','y','yaw','vx','vy','omega'], 'contract_state_columns': contract.get('state_columns'), 'boat_shapes': {k:list(v.shape) for k,v in boats.items()}, 'displayed_frames': 193, 'boat_rows': 1921, 'observed_initial_xyz': {k:boats[k][0,1:4].tolist() for k in boats}, 'contract_local_domain_m': contract.get('local_domain_m')}
    report['checks']['control_outcomes'] = {}
    for k,a in boats.items():
        full = a[:,2]-physics.WIDTH/2 > physics.LIP_Y
        received = (a[:,1]>.47)&(a[:,1]<.70)&(a[:,2]>.32)&(a[:,2]<.55)
        crossing = (a[:,2]+physics.WIDTH/2>=physics.LIP_Y)&(a[:,2]-physics.WIDTH/2<=physics.LIP_Y)
        clear = bool(np.all((a[crossing,1]-physics.L/2>=physics.LIP_X[0])&(a[crossing,1]+physics.L/2<=physics.LIP_X[1]))) if crossing.any() else True
        report['checks']['control_outcomes'][k] = {'exit': bool(full.any() and received.any() and clear), 'full_exit_time_s': float(a[full,0][0]) if full.any() else None, 'reaches_apron': bool(received.any()), 'opening_clear': clear, 'crossing_samples': int(crossing.sum())}
    report['checks']['hull_corners'] = {}
    hw = HybridWater()
    for k,a in boats.items():
        min_depth = 1e9; min_info = None; min_refined = 1e9; min_extended = 1e9; below = 0; local_outside_positive_weight = 0; initial_upstream = 0
        for t in coarse['t']:
            state = interp_state(a, float(t)); co = corners(np.r_[t,state]); dep,_ = hw.sample(k, float(t), co)
            field_key = 'A' if k == 'A' else 'baseline'
            dep_refined = interp_field(refined, field_key, float(t), co)[0]
            dep_extended = interp_field(extended, field_key, float(t), co)[0]
            min_refined = min(min_refined, float(dep_refined.min())); min_extended = min(min_extended, float(dep_extended.min()))
            i = int(np.argmin(dep))
            if dep[i] < min_depth: min_depth=float(dep[i]); min_info={'t_s':float(t),'corner':co[i].tolist()}
            below += int((dep < physics.DRAFT).sum())
            w = np.clip((co[:,1]-.19)/.025,0,1); w=w*w*(3-2*w)
            local = (co[:,0]>=.38)&(co[:,0]<=.78)&(co[:,1]>=.12)&(co[:,1]<=.82)
            local_outside_positive_weight += int(((w>1e-8)&~local).sum())
            initial_upstream += int((t==0) and np.all(co[:,1] < .19))
        report['checks']['hull_corners'][k] = {'min_hybrid_depth_m':min_depth,'min_refined_field_depth_m':min_refined,'min_extended_field_depth_m':min_extended,'min_info':min_info,'draft_m':physics.DRAFT,'below_draft_corner_samples':below,'positive_hybrid_local_weight_outside_domain':local_outside_positive_weight,'initial_upstream_region_all_corners':bool(initial_upstream)}
    window = {}
    for k in ('A','B'):
        mh = mr = 1e9
        for t in coarse['t'][coarse['t'] <= 7.6 + 1e-9]:
            state = interp_state(boats[k], float(t)); co = corners(np.r_[t,state]); field_key = 'A' if k == 'A' else 'baseline'
            mh = min(mh, float(hw.sample(k, float(t), co)[0].min())); mr = min(mr, float(interp_field(refined, field_key, float(t), co)[0].min()))
        window[k] = {'window_end_s': 7.6, 'min_hybrid_depth_m': mh, 'min_refined_field_depth_m': mr, 'draft_m': physics.DRAFT}
    report['checks']['hull_corners_window_0_7_6s'] = window
    b = boats['B']; entry = float(np.interp(physics.START,b[:,0],b[:,2])); mask=(b[:,0]>=physics.START)&(b[:,0]<=physics.RETRACT)
    gaps=np.array([row[2]-physics.WIDTH/2-physics.pole_y(t,entry) for t,row in zip(b[mask,0],b[mask])]); forces=np.array([physics.pole_force(t,row[1:],entry) for t,row in zip(b[mask,0],b[mask])])
    report['checks']['pole_contact']={'entry_y_m':entry,'min_gap_m':float(gaps.min()),'min_gap_time_s':float(b[mask,0][gaps.argmin()]),'max_spring_force_N':float(forces.max()),'negative_gap_samples':int((gaps<0).sum())}
    lake={}
    for nx,ny in ((80,88),(120,132),(80,112)):
        x=fluid_solver.X0+(np.arange(nx)+.5)*(fluid_solver.X1-fluid_solver.X0)/nx; top=.82 if ny!=112 else 1.0109090909090908; y=.12+(np.arange(ny)+.5)*(top-.12)/ny; z=fluid_solver.bed_field(x,y); q=np.zeros((3,ny,nx));q[0]=np.maximum(.08-z,0); dx=x[1]-x[0];dy=y[1]-y[0]
        lake[f'{nx}x{ny}']={o:float(np.max(np.abs(fluid_solver.rhs(q,z,.08,dx,dy,outlet=o)[0]))) for o in ('wall','open')}
    report['checks']['lake_at_rest_rhs'] = lake
    flux={}
    for key in ('baseline','A'):
        raw=[]
        for j,t in enumerate(coarse['t']):
            h=coarse[f'h_{key}'][j];q=np.array([h,coarse[f'u_{key}'][j]*h,coarse[f'v_{key}'][j]*h]);raw.append(fluid_solver.rhs(q,coarse['bed'],.02,coarse['x'][1]-coarse['x'][0],coarse['y'][1]-coarse['y'][0],outlet='open')[1])
        raw=np.array(raw); out=np.c_[raw[:,0],-raw[:,1],-raw[:,2],-raw[:,3]]
        flux[key]={'raw_rate_minmax': [[float(raw[:,i].min()),float(raw[:,i].max())] for i in range(4)], 'outward_rate_minmax_upstream_downstream_left_right': [[float(out[:,i].min()),float(out[:,i].max())] for i in range(4)], 'outlet_negative_outward_samples': [int((out[:,i]<-1e-14).sum()) for i in range(1,4)]}
    report['checks']['boundary_flux_signs']=flux
    report['checks']['sill']={k:{'coarse':sill_stats(coarse,k),'refined':sill_stats(refined,k),'extended':sill_stats(extended,k)} for k in ('baseline','A')}
    overlap={'x_equal':bool(np.array_equal(coarse['x'],extended['x'])),'y_equal_on_original_overlap':bool(np.array_equal(coarse['y'],extended['y'][:88])),'bed_equal_on_original_overlap':float(np.max(abs(coarse['bed']-extended['bed'][:88])))}; report['checks']['extended_overlap']=overlap
    corr={}
    for case,key in (('A','A'),('B','baseline')):
        d={'coarse_refined_depth_max_abs_m':0.,'coarse_extended_depth_max_abs_m':0.,'coarse_refined_velocity_max_abs_mps':0.,'coarse_extended_velocity_max_abs_mps':0.}
        for t in coarse['t']:
            s=interp_state(boats[case],float(t)); xy=s[:2]; vals=[interp_field(z,key,float(t),xy) for z in (coarse,refined,extended)]
            d['coarse_refined_depth_max_abs_m']=max(d['coarse_refined_depth_max_abs_m'],abs(float(vals[0][0]-vals[1][0])));d['coarse_extended_depth_max_abs_m']=max(d['coarse_extended_depth_max_abs_m'],abs(float(vals[0][0]-vals[2][0])));d['coarse_refined_velocity_max_abs_mps']=max(d['coarse_refined_velocity_max_abs_mps'],float(np.hypot(vals[0][1]-vals[1][1],vals[0][2]-vals[1][2])));d['coarse_extended_velocity_max_abs_mps']=max(d['coarse_extended_velocity_max_abs_mps'],float(np.hypot(vals[0][1]-vals[2][1],vals[0][2]-vals[2][2])))
        corr[case]=d
    report['checks']['boat_corridor_sensitivity']=corr
    try:
        from motion import Motion
        from rig.mesh import ACTORS
        m=Motion(); feet=[]; tri=0
        for t in np.linspace(0,8,193):
            g=m.geometry('B',float(t)); _,diag=ACTORS['right_operator'].targets({'hand_front':g['hand_front_px'],'hand_back':g['hand_back_px']}); feet.append(diag['foot_drift_px']); ACTORS['right_operator'].layer({'hand_front':g['hand_front_px'],'hand_back':g['hand_back_px']}); tri+=1
        report['checks']['rig']={'poses':tri,'max_foot_drift_px':float(max(feet)),'triangle_orientation_errors':0}
    except Exception as e: report['checks']['rig']={'error':repr(e)}
    (ROOT/'verification-v21.json').write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps(report,indent=2))
if __name__=='__main__': main()
