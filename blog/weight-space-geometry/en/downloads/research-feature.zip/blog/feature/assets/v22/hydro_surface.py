"""Surface geometry and advected painterly optics for the local SWE solution.

Depth/velocity/free-surface position are simulated. Reflections, pigment and
foam are expressly non-photorealistic rendering, not resolved bubble physics.
"""
from pathlib import Path
import numpy as np
import cv2
ROOT=Path(__file__).resolve().parent

def mix_sample(a,x,y):
    return cv2.remap(np.asarray(a,np.float32),np.asarray(x,np.float32),np.asarray(y,np.float32),cv2.INTER_LINEAR,borderMode=cv2.BORDER_REPLICATE)

def point_sample(a,x,y):
    """Unquantized bilinear samples for body/surface geometry.

    OpenCV's image sampler quantizes interpolation weights to 1/32 cell;
    those subpixel steps must not become screen-space boat velocity jumps.
    """
    x=np.clip(np.asarray(x,dtype=float),0,a.shape[1]-1)
    y=np.clip(np.asarray(y,dtype=float),0,a.shape[0]-1)
    ix=np.minimum(x.astype(int),a.shape[1]-2);iy=np.minimum(y.astype(int),a.shape[0]-2)
    fx=x-ix;fy=y-iy
    return ((1-fy)*((1-fx)*a[iy,ix]+fx*a[iy,ix+1])+
            fy*((1-fx)*a[iy+1,ix]+fx*a[iy+1,ix+1]))

class Hydro:
    def __init__(self):
        self.d=dict(np.load(ROOT/'fluid_fields.npz'))
        self.t=self.d['t'];self.x=self.d['x'];self.y=self.d['y'];self.bed=self.d['bed']
        self.dx=float(self.x[1]-self.x[0]);self.dy=float(self.y[1]-self.y[0])
        self.xx,self.yy=np.meshgrid(self.x,self.y)
        self.gx,self.gy=np.meshgrid(np.arange(len(self.x),dtype=np.float32),np.arange(len(self.y),dtype=np.float32))
        self.optics={}
    def frame(self,take,t):
        key='A' if take in ('A','gate') else 'baseline'
        t=float(np.clip(t,self.t[0],self.t[-1]));j=int(np.clip(np.searchsorted(self.t,t),1,len(self.t)-1));w=(t-self.t[j-1])/(self.t[j]-self.t[j-1])
        return [(1-w)*self.d[f'{v}_{key}'][j-1]+w*self.d[f'{v}_{key}'][j] for v in ('h','u','v')]
    def sample(self,take,t,xy):
        xy=np.atleast_2d(xy);gx=((xy[:,0]-self.x[0])/self.dx).reshape(-1,1);gy=((xy[:,1]-self.y[0])/self.dy).reshape(-1,1)
        h,u,v=self.frame(take,t)
        depth=point_sample(h,gx,gy).ravel();vel=np.c_[point_sample(u,gx,gy).ravel(),point_sample(v,gx,gy).ravel()]
        z=point_sample(self.bed+h-.020,gx,gy).ravel()
        return depth,vel,z
    def build_optics(self):
        """Advect pigment coordinates and a decaying foam tracer, once per take."""
        for key in ('A','baseline'):
            h=self.d[f'h_{key}'];u=self.d[f'u_{key}'];v=self.d[f'v_{key}'];n=len(self.t)
            fields=np.empty((n,5,*self.bed.shape),np.float32)
            uv=[self.xx.astype(np.float32).copy(),self.yy.astype(np.float32).copy(),self.xx.astype(np.float32).copy(),self.yy.astype(np.float32).copy()]
            foam=np.zeros_like(self.bed,np.float32)
            lastcycles=[0,0]
            for k in range(n):
                dt=float(self.t[k]-self.t[k-1]) if k else 0.
                if k:
                    # Semi-Lagrangian passive optics, substepped for advection.
                    sub=max(1,int(np.ceil(dt*max(np.max(abs(u[k]))/self.dx,np.max(abs(v[k]))/self.dy)/.7)))
                    for _ in range(sub):
                        sx=self.gx-u[k]*(dt/sub/self.dx);sy=self.gy-v[k]*(dt/sub/self.dy)
                        for m in range(4):uv[m]=mix_sample(uv[m],sx,sy)
                        foam=mix_sample(foam,sx,sy)*np.exp(-dt/sub/0.55)
                        div=np.gradient(u[k],self.dx,axis=1)+np.gradient(v[k],self.dy,axis=0)
                        froude=np.hypot(u[k],v[k])/np.sqrt(9.81*np.maximum(h[k],1e-5))
                        # Aeration is an illustrative marker of supercritical
                        # shear/compression, never a new mass source.
                        emit=np.clip((froude-.75)*.2+np.maximum(-div,0)*.025,0,1)
                        emit*=((h[k]>.0005)&(self.yy>.24))
                        foam=np.clip(foam+emit*(dt/sub)*1.4,0,1)
                for j,offset in enumerate((0.,.5)):
                    cycle=int(np.floor(self.t[k]/1.4+offset))
                    if cycle!=lastcycles[j]:uv[j*2]=self.xx.astype(np.float32).copy();uv[j*2+1]=self.yy.astype(np.float32).copy();lastcycles[j]=cycle
                fields[k,:4]=np.asarray(uv);fields[k,4]=foam
            self.optics[key]=fields
    def optic_frame(self,take,t):
        key='A' if take in ('A','gate') else 'baseline'
        if not self.optics:self.build_optics()
        t=float(np.clip(t,self.t[0],self.t[-1]));j=int(np.clip(np.searchsorted(self.t,t),1,len(self.t)-1));w=(t-self.t[j-1])/(self.t[j]-self.t[j-1])
        return self.optics[key][j-1]*(1-w)+self.optics[key][j]*w
