# Living watercolor cover

The approved v11 painting remains the source of the actors, costumes, scenery,
paper hulls and control hand. A boat-free water plate was prepared with a
reference-image edit. Only the canal and exposed lower-pole region are used
from that plate. Figma's prompt-only image generation did not preserve the
reference composition and its candidate was discarded.

The 18-second animation is authored as editable layers and native keyframes in
[Figma](https://www.figma.com/design/ot7ouesgGj6UOvQ93PPHUE?node-id=116-11).
`../../cover_motion_figma.js` reconstructs the composition from the approved
Figma cover. It is an async Plugin API script, not a Node command. Existing file
IDs and uploaded image hashes are explicit; to recreate in another file, upload
the approved original and this clean plate, then replace those references.

Four hulls travel at equal arc-length spacing until the local pole intervention.
One periodic phase controls the global current, hull speed and gate opening.
The pole's contact window adds a lateral displacement and temporary heading
change. This is choreographed explanatory motion, **not a fluid simulation or a
measurement of a neural network**. The actor faces, scene and camera stay fixed.

The gate and pole motions were inspected with contact sheets. A duplicated
spindle from the initial sliding-gate trial was replaced by a turning gate and
fixed foreground spindle. The right annotation was moved to the actor's grip
to keep the contact between pole and boat unobstructed.

Exports:

- `cover.mp4`: 1600 × 1280, 24 fps, 18-second seamless loop, no audio.
- `cover.gif`: 1120 × 896, 16 fps, infinite loop.
- `cover.png`: first frame, used for reduced motion and pause.
- `motion.json`: timing, provenance and rendering parameters.

Figma's MP4 export includes the terminal frame at t=18. Encoding trims it to
exactly 18 seconds so the repeat does not hold a duplicate frame:

```sh
ffmpeg -i cover-master.mp4 -t 18 -an -c:v libx264 -preset slow -crf 20 \
  -pix_fmt yuv420p -movflags +faststart cover.mp4
ffmpeg -i cover-master.mp4 -t 18 -filter_complex \
  '[0:v]fps=16,scale=1120:-1:flags=lanczos,split[a][b];[a]palettegen=stats_mode=full[p];[b][p]paletteuse=dither=bayer:bayer_scale=3:diff_mode=rectangle' \
  -loop 0 cover.gif
```

The blog starts the muted inline MP4 automatically, with GIF fallback if video
playback fails. A pause control remains available. Reduced-motion preferences
show the still frame until the reader explicitly requests motion.

Clean-plate prompt: remove the four paper boats and their water-contact shadows,
and the exposed pole below the right actor's lower hand; reconstruct watercolor
water/background only in those regions; preserve composition, actors, costume,
face, hands, pale timber, ink-brush plants and translucent strata. The saved
plate is `water-clean-plate.png`; the approved original is
`../../art/kabuki-whitewood-v11.png`.
