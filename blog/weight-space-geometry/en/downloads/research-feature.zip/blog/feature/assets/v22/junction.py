"""One actual main channel (+x) and one SIDE spillway (+y), SI units.
Both outlets share a finite-volume mass/momentum solve. No case-specific boat field.
"""
from pathlib import Path
import json,time
import numpy as np
import fv_core as core
ROOT=Path(__file__).resolve().parent
G=9.81;X0,X1=.10,1.05;Y0,Y1=-.04,.48
MOUTH=(.42,.74);BANK_Y=.235;CREST=.021
QBASE=.00043;QEXTRA=.00240;OPENING_TIME=.8;GATE_TRANSIT=.4
s=core.smooth

def bed_field(x,y):
 X,Y=np.meshgrid(x,y)
 channel=-.002*(X-X0)/(X1-X0)
 up=.07*(1-s((Y+.005)/.018))
 lip=s((Y-.185)/.05)
 aperture=s((X-(MOUTH[0]-.014))/.014)*(1-s((X-MOUTH[1])/.014))
 apron=CREST-.055*s((Y-.245)/.235)
 # Land outside the visible side cut remains high; channel bed and cut share mesh.
 lower=(1-aperture)*.065+aperture*apron
 z=channel*(1-lip)+lower*lip+up
 # Normal downstream waterfall throat: 0.12 m wide, same channel, not an added branch.
 taper=s((X-.82)/.14)
 shoulders=(1-s((Y-.012)/.012)+s((Y-.185)/.012))*.055*taper
 z+=shoulders*(1-lip)
 z+=.004*s((X-.70)/.23)*(1-lip)
 return z

def rhs(q,z,command,dx,dy,outlet='open'):
 ny,nx=z.shape
 ext=np.pad(q,((0,0),(1,1),(1,1)),mode='edge');ze=np.pad(z,1,mode='edge')
 # One physical inlet on LEFT, qn specified; extrapolated depth.
 inlet=(Y0+(np.arange(ny)+.5)*dy>=.015)&(Y0+(np.arange(ny)+.5)*dy<=.185)
 Q=QBASE+QEXTRA*command
 h=np.where(inlet,np.maximum(q[0,:,0],.002),q[0,:,0]);ext[0,1:-1,0]=h
 ext[1,1:-1,0]=np.where(inlet,Q/(inlet.sum()*dy),-q[1,:,0])
 ext[2,1:-1,0]=q[2,:,0]
 # Upper bank is solid. Other boundaries drain only outwards.
 ext[2,0,1:-1]=-q[2,0]
 l,r,hl,hr=core.reconstruct(ext[:,1:-1,:-1],ext[:,1:-1,1:],ze[1:-1,:-1],ze[1:-1,1:]);fx=core.hll(l,r,0)
 b,t,hb,ht=core.reconstruct(ext[:,:-1,1:-1],ext[:,1:,1:-1],ze[:-1,1:-1],ze[1:,1:-1]);fy=core.hll(b,t,1)
 # Prescribed inlet volume flux; momentum uses corresponding inlet velocity.
 qn=np.where(inlet,Q/(inlet.sum()*dy),0.);uin=np.divide(qn,h,out=np.zeros_like(qn),where=h>core.DRY)
 fx[0,:,0]=qn;fx[1,:,0]=qn*uin+.5*G*h*h;fx[2,:,0]=qn*core.velocity(q[:,:,0])[1]
 h=q[0,:,-1];u,v=core.velocity(q[:,:,-1]);un=np.maximum(u,0)
 fx[0,:,-1]=h*un;fx[1,:,-1]=h*un*un+.5*G*h*h;fx[2,:,-1]=h*un*v
 h=q[0,-1];u,v=core.velocity(q[:,-1]);vn=np.maximum(v,np.sqrt(G*h))  # critical control only for subcritical outflow; supercritical flow transmits
 fy[0,-1]=h*vn;fy[1,-1]=h*vn*u;fy[2,-1]=h*vn*vn+.5*G*h*h
 # All top-bank mass is reflected. Pressure flux remains physical.
 fy[0,0]=0;fy[1,0]=0;fy[2,0]=.5*G*q[0,0]**2
 dq=-(fx[:,:,1:]-fx[:,:,:-1])/dx-(fy[:,1:,:]-fy[:,:-1,:])/dy
 dq[1]+=.5*G*(hl[:,1:]**2-hr[:,:-1]**2)/dx
 dq[2]+=.5*G*(hb[1:]**2-ht[:-1]**2)/dy
 rates=np.array([np.sum(fx[0,:,0])*dy,-np.sum(fx[0,:,-1])*dy,0.,-np.sum(fy[0,-1])*dx])
 return dq,rates

def solve(nx=144,ny=96,warmup=18.,duration=12.,save=True):
 clock=time.time();dx=(X1-X0)/nx;dy=(Y1-Y0)/ny
 x=X0+(np.arange(nx)+.5)*dx;y=Y0+(np.arange(ny)+.5)*dy;z=bed_field(x,y)
 q=np.zeros((3,ny,nx));q[0]=np.maximum(.020-z,0)*(y[:,None]<BANK_Y)
 q[1]=q[0]*.09*(y[:,None]<.185)
 core.rhs=rhs
 q,_,warm,_=core.integrate(q,z,x,y,-warmup,0,lambda t:0.)
 times=np.arange(round(duration*12)+1)/12
 data={'t':times,'x':x,'y':y,'bed':z.astype(np.float32)}
 metrics={'domain_m':[X0,X1,Y0,Y1],'grid':[nx,ny],'warmup_s':warmup,'inlet':'left +x','main_outlet':'right +x','side_outlet':'bottom +y','Qbase_m3s':QBASE,'Qextra_m3s':QEXTRA,'gate_transit_s':GATE_TRANSIT,'warmup':warm,'cases':{}}
 for k,cmd in [('baseline',lambda t:0.),('A',lambda t:float(s((t-GATE_TRANSIT)/OPENING_TIME)))]:
  initial=q.copy()
  if k=='A':
   # The downstream inlet sees the gate response after upstream transit.
   # Start from exactly the saved baseline initial condition used by replays.
   hh=data['h_baseline'][0].astype(np.float64)
   initial=np.stack((hh,hh*data['u_baseline'][0],hh*data['v_baseline'][0]))
  final,frames,m,ledger=core.integrate(initial,z,x,y,0,duration,cmd,times)
  vel=np.divide(frames[:,1:],frames[:,0,None],out=np.zeros_like(frames[:,1:]),where=frames[:,0,None]>core.DRY)
  for a,arr in [('h',frames[:,0]),('u',vel[:,0]),('v',vel[:,1])]:data[f'{a}_{k}']=arr.astype(np.float32)
  data['ledger_'+k]=ledger
  j=np.argmin(abs(y-BANK_Y));i=np.argmin(abs(x-.93));mouth=(x>=MOUTH[0])&(x<=MOUTH[1])
  m['side_sill_Q_m3s']=(frames[:,2,j,mouth].sum(1)*dx).tolist()
  m['main_Q_m3s']=(frames[:,1,:,i].sum(1)*dy).tolist()
  m['max_speed_mps']=float(np.hypot(vel[:,0],vel[:,1]).max());m['max_depth_m']=float(frames[:,0].max())
  metrics['cases'][k]=m
 metrics['runtime_s']=time.time()-clock
 if save:
  np.savez_compressed(ROOT/'fluid_fields.npz',**data);(ROOT/'fluid-metrics.json').write_text(json.dumps(metrics,indent=2))
  print(json.dumps({k:{a:b for a,b in v.items() if not isinstance(b,list)}for k,v in metrics['cases'].items()},indent=2),flush=True)
 return data,metrics
if __name__=='__main__':solve()
