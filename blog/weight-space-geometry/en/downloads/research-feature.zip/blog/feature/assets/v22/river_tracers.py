"""Passive upstream tracers and their continuous hand-off to local boat SWE.

The upstream part is a route-coordinate illustration.  Once a tracer reaches
``RiverFlow.entry_s`` it is initialized from the same six-state boat model used
by :mod:`boats`; this module does not retime or prescribe the resulting local
trajectory.
"""
from __future__ import annotations

import numpy as np

from boats import L, WIDTH, rhs as boat_rhs
from motion import project


DT = 1.0 / 120.0
DURATION = 12.0
START_S = (100.0, 360.0, 620.0)


def _case(take: str) -> str:
    """Map the rendered B take to the baseline passive-flow trajectory."""
    return "A" if take in ("A", "gate") else "baseline"


class RiverTracers:
    """Three cached tracer trajectories for the requested river flow.

    ``frame(take, t)`` returns dictionaries with pixel position, yaw, local
    physical coordinates, and visibility.  B deliberately reuses the
    baseline upstream trajectories, while its local hand-off uses baseline
    water fields as well.
    """

    def __init__(self, flow, motion, duration: float = DURATION, dt: float = DT):
        self.flow = flow
        self.motion = motion
        self.dt = float(dt)
        self.duration = float(duration)
        self.times = np.arange(round(self.duration / self.dt) + 1, dtype=float) * self.dt
        self._traces = {}
        for take in ("baseline", "A", "B"):
            if take == "B":
                self._traces[take] = self._traces["baseline"]
            else:
                self._traces[take] = [self._integrate_one(take, s0) for s0 in START_S]
        self.diagnostics = self._diagnose()

    def _fields(self, take):
        """Find the resolved SWE arrays without imposing a RiverFlow layout."""
        source = _case(take)
        candidates = [getattr(self.flow, "data", None), getattr(self.flow, "d", None)]
        hydro = getattr(getattr(self.motion, "water", None), "hydro", None)
        candidates += [getattr(hydro, "d", None)]
        data = next((d for d in candidates if d is not None and f"h_{source}" in d), None)
        if data is None:
            raise AttributeError("RiverFlow/motion does not expose resolved SWE fields")
        x, y = np.asarray(data["x"], float), np.asarray(data["y"], float)
        return (np.asarray(data[f"h_{source}"]), np.asarray(data[f"u_{source}"]),
                np.asarray(data[f"v_{source}"]), float(x[0]), float(y[0]),
                float(x[1] - x[0]), float(y[1] - y[0]))

    def _speed(self, take, t, s):
        return float(self.flow.speed(_case(take), float(t), float(s)))

    def _step_s(self, take, t, s, h):
        f = lambda tt, ss: self._speed(take, tt, ss)
        k1 = f(t, s)
        k2 = f(t + h / 2.0, s + h * k1 / 2.0)
        k3 = f(t + h / 2.0, s + h * k2 / 2.0)
        k4 = f(t + h, s + h * k3)
        return s + h * (k1 + 2.0 * k2 + 2.0 * k3 + k4) / 6.0

    def _local_step(self, take, state, t, h, fields):
        args = (*fields, float(self.flow.entry_xy[1]), False)
        # boat_rhs's final ``entry_y`` is irrelevant for tracers because pole
        # contact is disabled, but keeping the existing signature makes the
        # local dynamics exactly the repository's rigid-body solver.
        def f(tt, ss):
            return boat_rhs(float(tt), ss, *args[:-1], args[-1])
        k1 = f(t, state)
        k2 = f(t + h / 2.0, state + h * k1 / 2.0)
        k3 = f(t + h / 2.0, state + h * k2 / 2.0)
        k4 = f(t + h, state + h * k3)
        return state + h * (k1 + 2.0 * k2 + 2.0 * k3 + k4) / 6.0

    def _integrate_one(self, take, s0):
        n = len(self.times)
        s_values = np.zeros(n, float)
        local_states = np.full((n, 6), np.nan, float)
        s = float(s0)
        entry_s = float(self.flow.entry_s)
        crossed = s >= entry_s
        state = np.zeros(6, float)
        entry_time = 0.0 if crossed else None
        entry_state = None
        if crossed:
            state[:2] = np.asarray(self.flow.entry_xy, float)
            state[3:5] = np.asarray(self.flow.entry_velocity(_case(take), 0.0), float)
            local_states[0] = state
            entry_state = state.copy()
        s_values[0] = s
        fields = self._fields(take)
        frozen = False
        for i, t in enumerate(self.times[:-1]):
            h = self.times[i + 1] - t
            if frozen:
                s_values[i + 1] = s
                local_states[i + 1] = state
                continue
            if not crossed:
                s_next = self._step_s(take, t, s, h)
                if s < entry_s <= s_next:
                    # Locate the event in this RK4 step; use the event state
                    # itself, so neither position nor velocity is discontinuous.
                    lo, hi = 0.0, h
                    for _ in range(32):
                        mid = (lo + hi) / 2.0
                        if self._step_s(take, t, s, mid) < entry_s:
                            lo = mid
                        else:
                            hi = mid
                    event_h = hi
                    s_event = self._step_s(take, t, s, event_h)
                    event_t = t + event_h
                    entry_time = event_t
                    state = np.zeros(6, float)
                    state[:2] = np.asarray(self.flow.entry_xy, float)
                    state[3:5] = np.asarray(self.flow.entry_velocity(_case(take), event_t), float)
                    entry_state = state.copy()
                    crossed = True
                    state = self._local_step(take, state, event_t, h - event_h, fields)
                    s = s_event
                else:
                    s = s_next
            else:
                state = self._local_step(take, state, t, h, fields)
            s_values[i + 1] = s
            if crossed:
                local_states[i + 1] = state
                if (state[0] - L / 2.0 > 1.05 or
                        abs(state[1]) - WIDTH / 2.0 > .48):
                    frozen = True
        return {"s": s_values, "local": local_states,
                "entry_time": entry_time, "entry_xy": np.asarray(self.flow.entry_xy, float),
                "entry_velocity": np.asarray(self.flow.entry_velocity(_case(take), entry_time or 0.), float),
                "entry_state": entry_state}

    def frame(self, take, t):
        """Return interpolated visible tracer records at physical time ``t``."""
        key = "baseline" if take not in ("A", "B", "baseline") else take
        t = float(np.clip(t, self.times[0], self.times[-1]))
        rows = []
        for trace in self._traces[key]:
            et = trace["entry_time"]
            if et is None or t < et:
                j = max(0, min(len(self.times) - 2, int(np.searchsorted(self.times, t)) - 1))
                # Re-evaluate the RK4 route step for sub-frame times. Linear
                # interpolation is wrong in the interval containing entry:
                # its endpoint has already been clamped to entry_s.
                s = self._step_s(key, self.times[j], trace["s"][j], t - self.times[j])
                rows.append((False, s, None))
            else:
                j = max(0, min(len(self.times) - 2, int(np.searchsorted(self.times, t)) - 1))
                w = (t - self.times[j]) / self.dt
                # The first local sample is at the entry-containing endpoint;
                # interpolate from the exact event state to that endpoint.
                if np.isnan(trace["local"][j]).any():
                    frac = (t - et) / max(self.times[j + 1] - et, 1e-12)
                    state = trace["entry_state"] * (1.0 - frac) + trace["local"][j + 1] * frac
                else:
                    state = trace["local"][j] * (1.0 - w) + trace["local"][j + 1] * w
                rows.append((True, trace["s"][j], state))
        result = []
        for local, s, state in rows:
            if not local:
                result.append({"pos_px": np.asarray(self.flow.position(_case(key), t, s), float),
                               "yaw": 0.0, "local": False, "active": True,
                               "xy": None, "s": float(s)})
                continue
            xy = np.asarray(state[:2], float)
            z = float(self.motion.water.surface_z(_case(take), t, xy[None])[0])
            active = bool(xy[0] - L / 2.0 <= 1.05 and abs(xy[1]) - WIDTH / 2.0 <= .48)
            result.append({"pos_px": np.asarray(project(xy, z), float),
                           "yaw": float(state[2]), "local": True,
                           "active": active, "xy": xy.copy(), "s": float(s)})
        return result

    def _diagnose(self):
        observation = {"baseline": 9.9417, "A": 2.4958, "B": 6.1167}
        checks = {}
        for take, traces in ((k, self._traces[k]) for k in ("baseline", "A", "B")):
            end = observation[take]
            j = min(len(self.times) - 1, int(round(end / self.dt)))
            became_inactive = []
            for trace in traces:
                local = trace["local"][:j + 1]
                active = np.nan_to_num(local[:, 0] - L / 2.0 <= 1.05) & np.nan_to_num(abs(local[:, 1]) - WIDTH / 2.0 <= .48)
                became_inactive.append(np.any(active[:-1] & ~active[1:]))
            checks[take] = {
                "entries": int(sum(trace["entry_time"] is not None for trace in traces)),
                "active_at_end": int(sum(trace["entry_time"] is None or np.all(np.isnan(trace["local"][-1])) or (trace["local"][-1, 0] - L / 2.0 <= 1.05 and abs(trace["local"][-1, 1]) - WIDTH / 2.0 <= .48) for trace in traces)),
                "inactive_before_observation": int(sum(became_inactive)),
            }
            entry_position_errors = []
            entry_velocity_errors = []
            yaw_jumps = []
            fps_velocity_jumps = []
            for index, trace in enumerate(traces):
                if trace["entry_time"] is None:
                    continue
                et = float(trace["entry_time"])
                case = _case(take)
                z = float(self.motion.water.surface_z(case, et, self.flow.entry_xy[None])[0])
                p0 = np.asarray(self.frame(take, et)[index]["pos_px"], float)
                expected_p0 = np.asarray(project(self.flow.entry_xy, z), float)
                entry_position_errors.append(float(np.linalg.norm(p0 - expected_p0)))
                # Use the actual rendered position on both sides. The upstream
                # side includes route advection and surface-z motion; the local
                # side uses the integrated six-state boat and current surface.
                eps = 1e-5
                pm = np.asarray(self.frame(take, et - eps)[index]["pos_px"], float)
                pp = np.asarray(self.frame(take, et + eps)[index]["pos_px"], float)
                local_px_s = (pp - p0) / eps
                upstream_px_s = (p0 - pm) / eps
                entry_velocity_errors.append(float(np.linalg.norm(local_px_s - upstream_px_s)))
                yaw_jumps.append(abs(float(self.frame(take, et + eps)[index]["yaw"])))
                fps = 1.0 / 24.0
                p_before = np.asarray(self.frame(take, max(0.0, et - fps))[index]["pos_px"], float)
                p_after = np.asarray(self.frame(take, min(self.duration, et + fps))[index]["pos_px"], float)
                v_before = (p0 - p_before) / fps
                v_after = (p_after - p0) / fps
                fps_velocity_jumps.append(float(np.linalg.norm(v_after - v_before)))
            if entry_position_errors:
                checks[take]["entry_position_px_error_max"] = max(entry_position_errors)
                checks[take]["entry_velocity_px_s_jump_max"] = max(entry_velocity_errors)
                checks[take]["entry_yaw_jump_rad_max"] = max(yaw_jumps)
                checks[take]["entry_24fps_velocity_jump_px_s_max"] = max(fps_velocity_jumps)
        return checks


__all__ = ["RiverTracers", "DT", "DURATION", "START_S"]
