"""Export directly from the final encoded movie; preserve source frames."""
from pathlib import Path
import subprocess,json,shutil
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parent

def ff(*args):
 subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error',*map(str,args)],check=True)

def main():
 movie=R/'motion-review.mp4'
 times=[0,4,8,10,11,12,13,17,19,20,21,23]
 for t in times:
  ff('-ss',t,'-i',movie,'-frames:v',1,'-q:v',2,R/f'frame-{t:02}.jpg')
 Image.open(R/'frame-12.jpg').save(R/'poster.jpg',quality=94)
 # Write a new inode, then replace: review/download media may be hardlinked.
 gif=R/'motion-review.tmp.gif'
 ff('-i',movie,'-vf','fps=10,scale=768:-1:flags=lanczos,split[s0][s1];[s0]palettegen=max_colors=192[p];[s1][p]paletteuse=dither=bayer:bayer_scale=3','-loop',0,gif)
 gif.replace(R/'motion-review.gif')
 clips=[('left',10.5,3.5,'350:230:210:250','1050:690'),
        ('right',14.5,7,'440:510:1090:290','660:764'),
        ('water',11,3,'565:330:950:600','1130:660'),
        ('outlet',0,5,'306:280:1230:665','918:840'),
        ('join',11,3,'530:260:720:490','1060:520')]
 for name,start,duration,crop,scale in clips:
  target=R/f'detail-{name}.mp4';temp=R/f'detail-{name}.tmp.mp4'
  ff('-ss',start,'-i',movie,'-t',duration,'-vf',f'crop={crop},scale={scale}:flags=lanczos','-an','-c:v','libx264','-crf',18,'-pix_fmt','yuv420p','-movflags','+faststart',temp)
  temp.replace(target)
  ff('-ss',duration*.5,'-i',target,'-frames:v',1,'-q:v',2,R/f'detail-{name}.jpg')
 sheet=Image.new('RGB',(1536,4*370),(253,252,249));d=ImageDraw.Draw(sheet)
 font=ImageFont.truetype('/System/Library/Fonts/Helvetica.ttc',20)
 for k,t in enumerate(times):
  im=Image.open(R/f'frame-{t:02}.jpg').resize((512,341),Image.Resampling.LANCZOS)
  x=(k%3)*512;y=(k//3)*370;sheet.paste(im,(x,y));d.text((x+15,y+343),f'{t:02d}s',font=font,fill=(50,70,90))
 sheet.save(R/'encoded-contact-sheet.jpg',quality=94)
 probe=subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(movie)],text=True)
 (R/'media-qa.json').write_text(probe)
 # Versioned article URLs prevent a cached opaque-wall movie from being used.
 for source,target in [('motion-review.mp4','motion-review-callouts.mp4'),
                       ('motion-review.gif','motion-review-callouts.gif'),
                       ('poster.jpg','poster-callouts.jpg')]:
  temp=R/(target+'.tmp');shutil.copy2(R/source,temp);temp.replace(R/target)
 print('Exported 24-second film, 10fps GIF, encoded frames and detail clips.')

if __name__=='__main__':main()
