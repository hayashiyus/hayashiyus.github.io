"""Compatibility interface: all local flow is the SAME solved SWE field.
No analytic velocity blending or case-dependent trajectory correction.
"""
import numpy as np
from hydro_surface import Hydro
class Water:
 def __init__(self):self.hydro=Hydro();self.data=self.hydro.d
 def sample(self,take,t,xy):
  h,uv,z=self.hydro.sample(take,t,xy);return h,uv
 def surface_z(self,take,t,xy):return self.hydro.sample(take,t,xy)[2]
 def levels(self,take,t):
  # Only used to shade the illustrative upstream S-river; not a dynamics input.
  xy=np.c_[[.13,.25,.4,.6],np.full(4,.1)]
  return self.surface_z(take,t,xy)+.020
