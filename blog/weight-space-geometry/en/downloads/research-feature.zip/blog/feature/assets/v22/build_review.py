# -*- coding: utf-8 -*-
"""Build the standalone v22 motion review page.

This script only packages already-produced media and JSON evidence. It does
not run the solver, render media, or publish automatically when imported.
"""
from __future__ import annotations

from pathlib import Path
import html
import json
import os
import shutil

ROOT = Path(__file__).resolve().parent
PUBLISH = ROOT.parents[2] / "publish/blog/weight-space-geometry/en/motion-v22"
DOWNLOAD = Path(os.environ.get("WSP_MOTION_V22_OUT", str(ROOT / "dist")))


def esc(value):
    return html.escape(str(value), quote=True)


def read_json(name):
    path = ROOT / name
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def verification_state(record):
    if not record:
        return "pending — verification-v22.json is not present"
    for key in ("status", "overall_status", "result"):
        value = record.get(key)
        if isinstance(value, str) and value.lower() in {"pass", "passed", "verified"}:
            return "passed — recorded in verification-v22.json"
    if record.get("passed") is True and record.get("failed", 0) in (0, None):
        return "passed — recorded in verification-v22.json"
    return "pending — inspect verification-v22.json before changing claims"


def subsystem_state(record, needle):
    """Find an explicit physics/rig status without assuming a schema."""
    needle = needle.lower()
    found = []

    def walk(value, context=""):
        if isinstance(value, dict):
            for key, child in value.items():
                ctx = f"{context}.{key}".lower()
                if needle in ctx and isinstance(child, (str, bool)):
                    found.append(child)
                walk(child, ctx)
        elif isinstance(value, list):
            for child in value:
                walk(child, context)

    walk(record)
    normalized = {str(x).lower() for x in found}
    if normalized & {"pass", "passed", "verified", "true"}:
        return "passed"
    return "pending"


def fmt(value, digits=4):
    if value is None:
        return "—"
    try:
        return f"{float(value):.{digits}f}"
    except (TypeError, ValueError):
        return esc(value)


def metric_rows(metrics):
    rows = []
    cases = metrics.get("cases", {})
    for name in ("baseline", "A", "B"):
        case = cases.get(name, {})
        if not case:
            continue
        expected = {"baseline": "MAIN CHANNEL", "A": "SIDE EXIT", "B": "SIDE EXIT"}[name]
        rows.append(
            "<tr>"
            f"<th>{esc(name)}</th>"
            f"<td>{esc(expected)}<small>design target</small></td>"
            f"<td>{esc(case.get('terminal', '—'))}</td>"
            f"<td>{fmt(case.get('terminal_t'), 3)}</td>"
            f"<td>{fmt(case.get('minimum_hull_depth_m'), 6)}</td>"
            f"<td>{'yes' if case.get('depth_pass') is True else 'no' if case.get('depth_pass') is False else '—'}</td>"
            f"<td>{esc(str(case.get('end_xy', '—')))}</td>"
            "</tr>"
        )
    return "".join(rows) or '<tr><td colspan="7">No case metrics recorded yet.</td></tr>'


def media_markup(name, label, kind="image"):
    path = ROOT / name
    if not path.exists():
        return f'<p class="missing">{esc(label)}: not supplied yet.</p>'
    if kind == "video":
        poster = ' poster="poster.jpg"' if (ROOT / "poster.jpg").exists() else ""
        return f'<figure><video controls muted playsinline preload="metadata"{poster}><source src="{esc(name)}" type="video/mp4"></video><figcaption>{esc(label)}</figcaption></figure>'
    return f'<figure><img src="{esc(name)}" alt="{esc(label)}"><figcaption>{esc(label)}</figcaption></figure>'


def build_html(metrics, verification, rig_verification=None):
    status = verification_state(verification)
    physics_status = "passed (scoped 2D checks)" if status.startswith("passed") else subsystem_state(verification, "physics")
    rig_raw = (rig_verification or {}).get("status")
    rig_status = "failed — shoulder reach blocker" if str(rig_raw).upper() == "FAIL" else ("passed" if str(rig_raw).upper() == "PASS" else subsystem_state(verification, "rig"))
    cases = metrics.get("cases", {})
    return f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Weight-space geometry · v22 motion review</title><link rel="icon" href="data:,"><style>
:root{{color-scheme:light}}*{{box-sizing:border-box}}body{{margin:0;background:#fdfcf9;color:#29354a;font:17px/1.75 Georgia,"Times New Roman",serif}}main{{max-width:1200px;margin:auto;padding:34px 28px 84px}}header{{max-width:980px;margin:0 auto 28px}}.eyebrow,.meta,.missing,small{{font:12px/1.6 system-ui,sans-serif;letter-spacing:.08em;color:#718096}}h1{{font-size:clamp(28px,4vw,52px);font-weight:400;line-height:1.12;margin:12px 0}}h2{{font-size:28px;font-weight:400;margin:36px 0 10px}}p{{max-width:980px}}video,img{{width:100%;display:block;background:#fff}}figure{{margin:0}}figcaption{{font:14px/1.6 system-ui,sans-serif;color:#586575;padding:10px 0}}nav{{display:flex;gap:10px;flex-wrap:wrap;margin:14px 0 30px}}button,a.button{{font:14px system-ui;border:1px solid #d5d9df;border-radius:5px;background:#fffdf8;padding:9px 15px;color:#30435c;text-decoration:none;cursor:pointer}}button:focus-visible,a:focus-visible{{outline:3px solid #72a9c8}}details{{border-top:1px solid #dededb;padding:18px 0}}summary{{cursor:pointer;font-size:20px}}table{{border-collapse:collapse;width:100%;font:14px/1.6 system-ui,sans-serif;margin:14px 0}}th,td{{text-align:left;padding:9px;border-bottom:1px solid #e3e2dd;vertical-align:top}}td small{{display:block;letter-spacing:0;color:#9a7336}}.status{{display:inline-block;padding:4px 9px;border-radius:4px;background:#fff4dc;color:#8b652d;font:13px system-ui,sans-serif}}.grid{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}}.stills{{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px}}pre{{white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.6 monospace;background:#f4f3ef;padding:14px}}a{{color:#3b799f}}footer{{margin-top:42px;color:#697380;font:13px/1.7 system-ui,sans-serif}}@media(max-width:700px){{main{{padding:20px 14px 54px}}.grid,.stills{{grid-template-columns:1fr}}table{{font-size:12px}}th,td{{padding:7px 4px}}}}
</style></head><body><main>
<header><div class="eyebrow">WEIGHT-SPACE GEOMETRY / LOCAL RIVER STUDY / V22</div>
<h1>One stage. Three conditions. One recorded exit boundary.</h1>
<p>The review keeps one physical clock and separates the baseline, gate, and pole conditions. It can show a common exit boundary without claiming the same path or a proof of duality.</p>
<p class="meta">24 seconds · baseline 0–10.5 s · dissolve 10.5–11 s · gate 11–14 s · dissolve 14–14.5 s · pole 14.5–21.5 s · comparison 21.5–23.5 s · loop dissolve 23.5–24 s · physical clock = display clock</p>
<p><span class="status">{esc(status)}</span> <span class="status">physics: {esc(physics_status)}</span> <span class="status">rig: {esc(rig_status)}</span></p></header>
{media_markup('motion-review.mp4','24-second motion review','video')}
<nav><button id="toggle" type="button">Pause</button><button id="restart" type="button">Restart</button>{'<button id="gif-toggle" type="button" aria-pressed="false">Show GIF</button>' if (ROOT/'motion-review.gif').exists() else ''}<a class="button" href="motion-review.mp4" download>Save MP4</a>{'<a class="button" href="motion-review.gif" download>Save GIF</a>' if (ROOT/'motion-review.gif').exists() else ''}</nav>
{'<figure id="gif-figure" hidden><img id="gif-view" src="motion-review.gif" alt="Animated GIF review"><figcaption>GIF preview (toggle pauses MP4; toggle back restores the poster)</figcaption></figure>' if (ROOT/'motion-review.gif').exists() else ''}
<h2>Recorded cases</h2><p>Design target: baseline → MAIN CHANNEL; gate and pole → SIDE EXIT. The labels below are not promoted to verified outcomes unless the supplied verification record passes.</p>
<div style="overflow-x:auto"><table><thead><tr><th>case</th><th>target</th><th>recorded terminal</th><th>terminal time</th><th>minimum hull depth (m)</th><th>depth pass</th><th>end state</th></tr></thead><tbody>{metric_rows(metrics)}</tbody></table></div>
<div class="stills">{media_markup('poster.jpg','Poster / recorded frame')}{media_markup('stage-board.svg','Editable causal stage board')}{media_markup('straight-clean-plate.png','Straight clean plate, applied only to the local reach')}</div>
<h2>Local evidence</h2><div class="grid">{media_markup('detail-left.mp4','Left detail: gate motion','video')}{media_markup('detail-right.mp4','Right detail: pole contact','video')}{media_markup('detail-water.mp4','Water detail: transparent side ramp','video')}{media_markup('detail-join.mp4','Final bend: continuous boat and water speed','video')}{media_markup('detail-outlet.mp4','Main outlet: one flow from the reach over the lip to the pool','video')}</div>
<details open><summary>Boundary and claim limits</summary><p>The revised stage has a real +x inlet/main/right outlet and a +y side apron. The ordinary main-channel fall is animated watercolor optics, not 3D CFD. The gate-water pass is also optical: no claim is made that its streaks resolve gate-scale hydrodynamics.</p><p>The current final junction configuration is 144×96 with Qbase 0.00043; the pole projection uses fixed reach RIG_VERTICAL=0.60. Scoped current 2D checks pass; spatial convergence remains NOT TESTED. Do not infer a same trajectory, same force, same timing, or a theorem of duality from a shared exit boundary.</p></details>
<details><summary>Model record</summary><pre>{esc(json.dumps(metrics, indent=2, ensure_ascii=False))}</pre></details>
<details><summary>Reproduction and package files</summary><p><a href="README.md">README</a> · <a href="PRODUCTION_SCRIPT.md">production script</a> · <a href="stage-board.svg">stage board</a> · <a href="dynamics-metrics.json">dynamics metrics</a> · <a href="verification-v22.json">verification-v22.json</a></p></details>
<footer>v22 local review artifact · no publication run performed by this build specification · no Weave generation</footer>
</main><script>
const film=document.querySelector('video'),toggle=document.querySelector('#toggle'),restart=document.querySelector('#restart'),gifToggle=document.querySelector('#gif-toggle'),gifFigure=document.querySelector('#gif-figure');
function label(){{if(toggle)toggle.textContent=film&&film.paused?'Play':'Pause'}}
if(film){{film.addEventListener('play',label);film.addEventListener('pause',label);film.addEventListener('ended',()=>{{film.pause();label()}})}}
if(toggle)toggle.onclick=()=>{{if(!film)return;if(film.paused)film.play().catch(()=>{{}});else film.pause();label()}};
if(restart)restart.onclick=()=>{{if(!film)return;film.pause();film.currentTime=0;label()}};label();
if(gifToggle)gifToggle.onclick=()=>{{if(!film||!gifFigure)return;const show=gifFigure.hidden;if(show){{film.pause();film.style.display='none';gifFigure.hidden=false;gifToggle.textContent='Restore poster';gifToggle.setAttribute('aria-pressed','true')}}else{{gifFigure.hidden=true;film.style.display='block';film.pause();film.currentTime=0;film.load();gifToggle.textContent='Show GIF';gifToggle.setAttribute('aria-pressed','false');label()}}}};
</script></body></html>'''


def copy_or_link(src, dest):
    if not src.exists():
        return False
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        if dest.is_file() and dest.samefile(src):
            return True
        dest.unlink()
    try:
        os.link(src, dest)
    except OSError:
        shutil.copy2(src, dest)
    return True


def main():
    metrics = read_json("dynamics-metrics.json")
    verification = read_json("verification-v22.json")
    rig_verification = read_json("rig-verification-v22.json")
    (ROOT / "index.html").write_text(build_html(metrics, verification, rig_verification), encoding="utf-8")
    assets = ["index.html", "motion-review.mp4", "motion-review.gif", "poster.jpg",
              "stage-board.svg", "straight-clean-plate.png", "dynamics-metrics.json",
              "verification-v22.json", "rig-verification-v22.json", "browser-qa.json", "media-qa.json",
              "physics-contract.json", "transparent-walls-qa.json", "main-fall-qa.json", "river-continuity-qa.json", "rigid-pole-qa.json", "body-push-qa.json", "callouts-qa.json", "ART_PROVENANCE.md", "PRODUCTION_SCRIPT.md", "README.md"]
    for kind in ("left", "right", "water", "outlet", "join"):
        assets.extend([f"detail-{kind}.mp4", f"detail-{kind}.jpg"])
    for target in (PUBLISH, DOWNLOAD):
        target.mkdir(parents=True, exist_ok=True)
        for name in assets:
            copy_or_link(ROOT / name, target / name)
    print(PUBLISH)
    print(DOWNLOAD)


if __name__ == "__main__":
    main()
