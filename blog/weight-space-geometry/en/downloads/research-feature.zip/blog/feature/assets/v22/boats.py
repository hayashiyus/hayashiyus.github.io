"""Rigid boat driven only by resolved shallow-water velocities and unilateral pole contact."""
from pathlib import Path
import json
import numpy as np
from numba import njit
ROOT=Path(__file__).resolve().parent
L=.055; WIDTH=.026; MASS=.0006; DRAFT=.0008; DRAG=.012
INERTIA=MASS*(L*L+WIDTH*WIDTH)/12
START=4.4; END=5.8; RETRACT=5.6; STROKE=.095; STIFFNESS=.6
@njit
def smooth(x):
 x=max(0.,min(1.,x));return x*x*(3-2*x)
@njit
def interp(a,ti,x,y,x0,y0,dx,dy):
 nt,ny,nx=a.shape;tf=max(0.,min(nt-1.000001,ti));k=int(tf);ft=tf-k
 xx=max(0.,min(nx-1.000001,(x-x0)/dx));yy=max(0.,min(ny-1.000001,(y-y0)/dy));i=int(xx);j=int(yy);fx=xx-i;fy=yy-j
 v=0.
 for dk in range(2):
  for dj in range(2):
   for di in range(2):v+=a[k+dk,j+dj,i+di]*(ft if dk else 1-ft)*(fy if dj else 1-fy)*(fx if di else 1-fx)
 return v
@njit
def field(h,u,v,t,xy,x0,y0,dx,dy):
 return np.array([interp(h,t*12,xy[0],xy[1],x0,y0,dx,dy),interp(u,t*12,xy[0],xy[1],x0,y0,dx,dy),interp(v,t*12,xy[0],xy[1],x0,y0,dx,dy)])
@njit
def pole_y(t,entry_y):return entry_y-WIDTH/2+STROKE*smooth((t-START)/(END-START))
@njit
def rhs(t,st,h,u,v,x0,y0,dx,dy,entry_y,pole):
 theta=st[2];c=np.cos(theta);s=np.sin(theta);f=np.zeros(2);torque=0.
 for x in [-L*.32,L*.32]:
  for y in [-WIDTH*.32,WIDTH*.32]:
   r=np.array([c*x-s*y,s*x+c*y]);q=field(h,u,v,t,st[:2]+r,x0,y0,dx,dy)
   local=st[3:5]+st[5]*np.array([-r[1],r[0]])
   df=DRAG/4*(q[1:]-local);f+=df;torque+=r[0]*df[1]-r[1]*df[0]
 # Contact at near-side midpoint. Pole tracks x; positive-y normal only.
 if pole and START<=t<=RETRACT:
  ry=-WIDTH/2*c;rx=WIDTH/2*s
  gap=st[1]+ry-pole_y(t,entry_y)
  pf=STIFFNESS*max(-gap,0.)/max(c,.2)
  nf=np.array([-s,c])*pf
  f+=nf;torque+=rx*nf[1]-ry*nf[0]
 return np.array([st[3],st[4],st[5],f[0]/MASS,f[1]/MASS,torque/INERTIA])
@njit
def integrate(h,u,v,x0,y0,dx,dy,initial,pole=False,dt=1/240,duration=12.):
 n=round(duration/dt);rows=np.zeros((n+1,7));st=initial.copy();entry=initial[1]
 rows[0,1:]=st
 for i in range(n):
  t=i*dt
  if t<=START and t+dt>START:entry=st[1]
  a=rhs(t,st,h,u,v,x0,y0,dx,dy,entry,pole)
  b=rhs(t+dt/2,st+dt*a/2,h,u,v,x0,y0,dx,dy,entry,pole)
  c=rhs(t+dt/2,st+dt*b/2,h,u,v,x0,y0,dx,dy,entry,pole)
  d=rhs(t+dt,st+dt*c,h,u,v,x0,y0,dx,dy,entry,pole)
  st+=dt*(a+2*b+2*c+d)/6
  rows[i+1,0]=t+dt;rows[i+1,1:]=st
  if st[0]>.985 or st[1]>.36:return rows[:i+2]
 return rows

def simulate(data,k,initial,dt=1/240):
 typ='A' if k=='A' else 'baseline'
 return integrate(data['h_'+typ],data['u_'+typ],data['v_'+typ],data['x'][0],data['y'][0],data['x'][1]-data['x'][0],data['y'][1]-data['y'][0],initial,k=='B',dt,float(data['t'][-1]))

def inspect(data,k,b):
 typ='A' if k=='A' else 'baseline';mi=1.;worst=None
 # Evaluate 5x3 points of rectangular conservative hull, not center alone.
 for row in b[::3]:
  t,x,y,th,*_=row;c=np.cos(th);s=np.sin(th)
  for a in np.linspace(-L/2,L/2,5):
   for d in np.linspace(-WIDTH/2,WIDTH/2,3):
    xy=np.array([x+c*a-s*d,y+s*a+c*d]);h=field(data['h_'+typ],data['u_'+typ],data['v_'+typ],t,xy,data['x'][0],data['y'][0],data['x'][1]-data['x'][0],data['y'][1]-data['y'][0])[0]
    if h<mi:mi=h;worst=[t,*xy]
 return {'terminal':'main' if b[-1,1]>.985 else 'side' if b[-1,2]>.36 else 'none','terminal_t':float(b[-1,0]),'minimum_hull_depth_m':float(mi),'depth_pass':bool(mi>=DRAFT),'worst_t_xy':worst,'end_xy':b[-1,1:3].tolist()}
if __name__=='__main__':
 d=dict(np.load(ROOT/'fluid_fields.npz'));report={};states={}
 for y in [.125,.135,.145,.155,.165]:
  initial=np.array([.32,y,0.,.09,0.,0.])
  report[str(y)]={}
  for k in ['baseline','A','B']:
   b=simulate(d,k,initial);report[str(y)][k]=inspect(d,k,b)
  print(y,report[str(y)],flush=True)
 (ROOT/'boat-pilot.json').write_text(json.dumps(report,indent=2))
