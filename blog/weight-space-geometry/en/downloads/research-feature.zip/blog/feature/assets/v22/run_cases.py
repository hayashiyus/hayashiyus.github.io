from pathlib import Path
import json,hashlib
import numpy as np
import boats
ROOT=Path(__file__).resolve().parent
INITIAL=np.array([.15,.16,0.,.09,0.,0.])
def run():
 d=dict(np.load(ROOT/'fluid_fields.npz'));out={};bs={}
 for k in ['baseline','A','B']:
  b=boats.simulate(d,k,INITIAL);bs[k]=b;out[k]=boats.inspect(d,k,b)
 np.savez_compressed(ROOT/'boat_states.npz',**bs)
 record={'initial_state':INITIAL.tolist(),'state_columns':['t','x','y','yaw','vx','vy','omega'],'cases':out,'model':'Actual 2D shallow-water velocities, four-point linear drag, planar rigid body; unilateral pole contact along rotated hull normal. No wall/contact impacts are simulated; hull-depth violations invalidate a run.','source_sha256':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest()for n in ['boats.py','junction.py','fv_core.py','fluid_fields.npz']}}
 (ROOT/'dynamics-metrics.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
if __name__=='__main__':run()
