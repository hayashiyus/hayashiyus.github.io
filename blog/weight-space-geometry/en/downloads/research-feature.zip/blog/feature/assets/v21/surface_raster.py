"""Forward rasterization of the computed height field, including occlusion."""
import numpy as np
from numba import njit

@njit(cache=True)
def raster(xy,zorder,rgba,width,height):
    out=np.zeros((height,width,4),np.float32)
    zz=np.full((height,width),-1e30)
    ny,nx=xy.shape[:2]
    for j in range(ny-1):
      for i in range(nx-1):
       for k in range(2):
        if k==0:
         ja,ia,jb,ib,jc,ic=j,i,j,i+1,j+1,i+1
        else:
         ja,ia,jb,ib,jc,ic=j,i,j+1,i+1,j+1,i
        a=xy[ja,ia];b=xy[jb,ib];c=xy[jc,ic]
        if max(rgba[ja,ia,3],rgba[jb,ib,3],rgba[jc,ic,3])<.001:continue
        den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
        if abs(den)<1e-8:continue
        xmin=max(0,int(np.floor(min(a[0],b[0],c[0]))));xmax=min(width-1,int(np.ceil(max(a[0],b[0],c[0]))))
        ymin=max(0,int(np.floor(min(a[1],b[1],c[1]))));ymax=min(height-1,int(np.ceil(max(a[1],b[1],c[1]))))
        for y in range(ymin,ymax+1):
         for x in range(xmin,xmax+1):
          wa=((b[1]-c[1])*(x+.5-c[0])+(c[0]-b[0])*(y+.5-c[1]))/den
          wb=((c[1]-a[1])*(x+.5-c[0])+(a[0]-c[0])*(y+.5-c[1]))/den
          wc=1-wa-wb
          if min(wa,wb,wc)<-1e-6:continue
          depth=wa*zorder[ja,ia]+wb*zorder[jb,ib]+wc*zorder[jc,ic]
          if depth>zz[y,x]:
           zz[y,x]=depth
           for v in range(4):out[y,x,v]=wa*rgba[ja,ia,v]+wb*rgba[jb,ib,v]+wc*rgba[jc,ic,v]
    return out
