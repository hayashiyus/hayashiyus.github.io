# Visual mathematics atlas, v24

Eight non-cover figures were redesigned around observable geometric operations. The accepted v23 execution plate and the v22 cover assets are retained byte for byte.

- Reconstruction and controls: static measured charts from `blog/data/measurements.json`, with source and measurement scopes separated. Control insets use independent logarithmic ranges and only actual bracketing endpoints.
- Fisher: an exact equal-Euclidean-length rotating vector in `F=diag(1,3)` alongside the unmodified E3 median curves and per-prefix observations. Highlighting steps between tested doses; it does not estimate intermediate measurements.
- Duality: one-dimensional permitted weight directions with `J=(1,0)^T`, `G=J^T F J=2`. A linear objective whose differential is `Fv` makes the weight natural gradient and the activation-space Fisher projection agree exactly. Shrinking contours show closest reachability, not an optimization trace.
- Efficiency: an exact equal-effect constraint and Fisher ellipses. Both effect bars remain constant; candidate cost decreases from the Euclidean solution to the constrained metric minimum. The modest numerical reduction is shown on a common untruncated scale.
- Reachability: the same eight-input model as v20; requested, currently realizable and residual vectors share one chart and one displacement display scale. The 65.6% residual is explicitly the computed best-attainable value.
- Coordinates: exact three-class softmax. The active segment moves at constant velocity in probability coordinates; log-odds follow the matching curve. This is Amari coordinate duality, distinct from weight/activation projection.
- Impossibility: one scalar moves two outputs with opposite signs; the equal-positive target stays off the reachable line. The bias caveat remains.

All equations use the article's vendored KaTeX 0.16.11 fonts and layout. Geometry is editable SVG. Videos and GIFs are deterministic renders of the same frame functions: 12 s, 24 fps MP4; 12 fps GIF with centisecond durations. Short paper dissolves explicitly separate loop endpoints. No Weave generation or new empirical experiment was used.

## Rebuild

From the project root:

```sh
python3 blog/feature/render_figure_math.py --only fisher reachability duality efficiency coordinates impossibility reconstruction controls
python3 blog/feature/verify_translation.py
python3 blog/feature/verify_english_revision.py
python3 blog/feature/package_feature.py
python3 blog/feature/build.py
python3 blog/feature/build_ja.py --publish-local
```

`atlas_v24_common.py` owns styling and media encoding. `geometry_v24.py`, `constraints_v24.py` and `measurements_v24.py` own numerical constructions and checks. `translations/atlas-redesign.json` records exact old/new captions, assets and three local bilingual prose changes. Frozen approved texts are not overwritten.

Figma retains native vector geometry and editable prose in a separate review page. Its available Libre Baskerville font substitutes for Georgia in prose only; embedded KaTeX labels are identical. Figma is the editable review board; Python is the motion source, not a native Figma timeline.
