"""Two scales: upstream storage model; resolved local overflow near the bank.

The overlap blends velocities over 25 mm. The boat is always integrated from
forces; no output positions or timing are copied from the previous film.
"""
import numpy as np
from physics import Water as ReachWater,smooth
from hydro_surface import Hydro
class Water:
    def __init__(self):
        self.reach=ReachWater();self.data=self.reach.data;self.hydro=Hydro()
    def levels(self,take,t):return self.reach.levels(take,t)
    def sample(self,take,t,xy):
        xy=np.atleast_2d(xy);dep,uv=self.reach.sample(take,t,xy)
        hd,hv,z=self.hydro.sample(take,t,xy)
        w=smooth((xy[:,1]-.19)/.025)
        if take=='A_no_outward':w*=0
        return dep*(1-w)+hd*w,uv*(1-w[:,None])+hv*w[:,None]
    def surface_z(self,take,t,xy):
        xy=np.atleast_2d(xy);_,_,z=self.hydro.sample(take,t,xy)
        zz=self.reach.levels(take,t)[3]-.020
        w=smooth((xy[:,1]-.14)/.04)
        return zz*(1-w)+z*w

def main():
    from pathlib import Path
    from physics import boat_solve,START,RETRACT,pole_force,L,WIDTH,LIP_Y,LIP_X
    import json
    p=Path(__file__).resolve().parent;water=Water();boats={k:boat_solve(water,k,1/240) for k in ('baseline','A','B','A_no_outward','B_no_pole')}
    report={'model':'Upstream volume model joined to local 2D SWE; boat integrated with drag and unilateral pole contact','velocity_overlap_y_m':[.19,.215],'cases':{}}
    for k,b in boats.items():
        full=b[:,2]-WIDTH/2>LIP_Y;crossing=(b[:,2]+WIDTH/2>=LIP_Y)&(b[:,2]-WIDTH/2<=LIP_Y)
        clear=bool(np.all((b[crossing,1]-L/2>=LIP_X[0])&(b[crossing,1]+L/2<=LIP_X[1])))
        received=(b[:,1]>.47)&(b[:,1]<.70)&(b[:,2]>.32)&(b[:,2]<.55)
        report['cases'][k]={'exit':bool(full.any() and received.any() and clear),'full_exit_time_s':float(b[full,0][0]) if full.any() else None,'reaches_shared_apron':bool(received.any()),'opening_width_clearance':clear,'end_xy_m':b[-1,1:3].tolist()}
    np.savez_compressed(p/'boat_states.npz',**boats);(p/'dynamics-metrics.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':main()
