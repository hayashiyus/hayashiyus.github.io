"""Shared route-time extension upstream of the resolved local SWE reach.

The illustrative upstream S-river carries the inlet response with a 0.4 s
travel delay. The same speed field advects water pigment and passive boats.
It is not a full-river shallow-water solve. No local boat states are retimed.
"""
from pathlib import Path
import numpy as np
from scipy.interpolate import CubicSpline
from motion import M, project, ZPX, smooth
from hydro_surface import mix_sample
from junction import GATE_TRANSIT

class RiverFlow:
 def __init__(self,motion):
  self.motion=motion;self.data=motion.water.hydro.d;hy=motion.water.hydro
  # Hand off 3 cm inside the solved reach, beyond the inlet ghost-cell
  # projection boundary. This removes the boundary clamp's screen-speed kink.
  self.entry_xy=np.array([.13,.16]);self.times=self.data['t']
  self.entry_z0=float(motion.water.surface_z('baseline',0,self.entry_xy[None])[0])
  endpoint=project(self.entry_xy,self.entry_z0)
  # Last bend follows the new straight plate and joins the actual model inlet.
  points=np.array([(338,374),(435,383),(505,414),(535,476),(585,498),
                   (679,487),(748,502),(780,543),(815,572),(875,587),
                   (910,614),(935,642),endpoint],float)
  chord=np.r_[0,np.cumsum(np.linalg.norm(np.diff(points,axis=0),axis=1))]
  endtan=self.entry_pixel_velocity('baseline',0);endtan/=np.linalg.norm(endtan)
  starttan=points[1]-points[0];starttan/=np.linalg.norm(starttan)
  cs=CubicSpline(chord,points,bc_type=((1,starttan),(1,endtan)))
  u=np.linspace(0,chord[-1],1000);up=cs(u)
  ar=np.r_[0,np.cumsum(np.linalg.norm(np.diff(up,axis=0),axis=1))]
  self.entry_s=float(ar[-1]);self.entry_tangent=endtan
  xs=np.linspace(self.entry_xy[0],.85,380);xy=np.c_[xs,np.full(len(xs),.16)]
  zz=motion.water.surface_z('baseline',0,xy);local=project(xy,zz)
  local_s=self.entry_s+np.r_[0,np.cumsum(np.linalg.norm(np.diff(local,axis=0),axis=1))]
  self.s=np.r_[ar,local_s[1:]];self.route=np.vstack((up,local[1:]))
  deriv=np.gradient(self.route,self.s,axis=0)
  self.tangent=deriv/np.maximum(np.linalg.norm(deriv,axis=1,keepdims=True),1e-9)
  self.nup=len(ar);self.tables={};self.depths={}
  # Handoff records use identical interior sampling to the local boat model.
  boundary={};depth={}
  for case in ('baseline','A'):
   vals=[hy.sample(case,float(t),self.entry_xy[None]) for t in self.times]
   boundary[case]=np.array([np.linalg.norm(self.entry_pixel_velocity(case,float(t))) for t in self.times])
   depth[case]=np.array([v[0][0] for v in vals])
  delays=GATE_TRANSIT*ar/self.entry_s
  gx=((xy[:,0]-hy.x[0])/hy.dx).reshape(-1,1)
  gy=((xy[:,1]-hy.y[0])/hy.dy).reshape(-1,1)
  for case in ('baseline','A'):
   speeds=[];heights=[]
   for ti,t in enumerate(self.times):
    base=np.full(len(ar),boundary['baseline'][ti]);hd=np.full(len(ar),depth['baseline'][ti])
    if case=='A':
     source_t=t+GATE_TRANSIT-delays
     effect=np.interp(source_t,self.times,boundary['A'])-np.interp(source_t,self.times,boundary['baseline'])
     dh=np.interp(source_t,self.times,depth['A'])-np.interp(source_t,self.times,depth['baseline'])
     arrived=t>=delays
     base+=effect*arrived;hd+=dh*arrived
    h,u,v=hy.frame(case,float(t))
    uv=np.c_[mix_sample(u,gx,gy).ravel(),mix_sample(v,gx,gy).ravel()]
    projected=uv@M.T
    zy,zx=np.gradient(h+hy.bed-.020,hy.dy,hy.dx)
    material_z=mix_sample(zx,gx,gy).ravel()*uv[:,0]+mix_sample(zy,gx,gy).ravel()*uv[:,1]
    projected+=material_z[:,None]*ZPX
    # At the handoff use the norm, matching the upstream curve's tangent.
    local_speed=np.linalg.norm(projected,axis=1)
    speeds.append(np.r_[np.maximum(base,1.),local_speed[1:]])
    heights.append(np.r_[hd,mix_sample(h,gx,gy).ravel()[1:]])
   self.tables[case]=np.asarray(speeds);self.depths[case]=np.asarray(heights)

 @staticmethod
 def case(take):return 'A' if take in ('A','gate') else 'baseline'
 def _row(self,table,t):
  t=np.clip(float(t),self.times[0],self.times[-1]);j=np.clip(np.searchsorted(self.times,t)-1,0,len(self.times)-2)
  w=(t-self.times[j])/(self.times[j+1]-self.times[j]);return table[j]*(1-w)+table[j+1]*w
 def speed(self,take,t,s):return np.interp(s,self.s,self._row(self.tables[self.case(take)],t))
 def depth(self,take,t,s):return np.interp(s,self.s,self._row(self.depths[self.case(take)],t))
 def path(self,s):return np.stack([np.interp(s,self.s,self.route[:,k])for k in range(2)],axis=-1)
 def normal(self,s):
  v=np.stack([np.interp(s,self.s,self.tangent[:,k])for k in range(2)],axis=-1)
  v/=np.maximum(np.linalg.norm(v,axis=-1,keepdims=True),1e-9)
  return np.stack((-v[...,1],v[...,0]),axis=-1)
 def entry_velocity(self,take,t):return self.motion.water.hydro.sample(self.case(take),float(t),self.entry_xy[None])[1][0]
 def entry_pixel_velocity(self,take,t):
  uv=self.entry_velocity(take,t);e=1e-4
  pts=self.entry_xy+np.array([[e,0],[-e,0],[0,e],[0,-e]])
  z=self.motion.water.surface_z(self.case(take),t,pts)
  grad=np.array([(z[0]-z[1])/(2*e),(z[2]-z[3])/(2*e)])
  return M@uv+ZPX*float(grad@uv)
 def position(self,take,t,s):
  p=self.path(s);L=140.;r=smooth((np.asarray(s)-(self.entry_s-L))/L)
  # Hermite endpoint correction keeps the endpoint position and tangent equal
  # to the inlet state, including the rising free surface.
  raw=np.clip((np.asarray(s)-(self.entry_s-L))/L,0,1)
  z=float(self.motion.water.surface_z(self.case(take),t,self.entry_xy[None])[0])
  shift=(z-self.entry_z0)*ZPX
  uv=self.entry_pixel_velocity(take,t);tan=uv/max(np.linalg.norm(uv),1e-9)
  return p+r[...,None]*shift+(raw**3-raw**2)[...,None]*L*(tan-self.entry_tangent)
 def backtrace(self,take,t,age):
  # A shared curved flow map, not x - current_velocity * age. Integrate on the
  # small route grid, then interpolate to painted pixels.
  s=self.s.copy();n=12;dt=age/n
  for k in range(n):
   tt=t-k*dt;v=self.speed(take,max(0,tt),s)
   mid=s-.5*dt*v;s-=dt*self.speed(take,max(0,tt-.5*dt),mid)
  return np.maximum(s,0)
