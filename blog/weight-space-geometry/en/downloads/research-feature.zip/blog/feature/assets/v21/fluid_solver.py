"""Local 2D SWE: hydrostatic reconstruction, HLL, SSPRK2 and bed friction.

The v18 upstream reach stage drives one external boundary. All mass enters
or leaves through recorded boundary fluxes. Baseline/A share an equilibrated
initial state. Micro-ripples, foam and reflections are not simulated here.
Reference: Audusse et al. (2004), doi:10.1137/S1064827503431090.
"""
from pathlib import Path
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parent
G=9.81;X0,X1,Y0,Y1=.38,.78,.12,.82;DRY=1e-8;CFL=.30

def smooth(a):
 a=np.clip(a,0,1);return a*a*(3-2*a)

def bed_field(x,y):
 X,Y=np.meshgrid(x,y)
 # Low sill followed by a monotone open terrace.  There is no receiving
 # basin, raster mask, or sub-surface mound in this bed.
 z=.017*smooth((Y-.185)/.06)-.075*smooth((Y-.255)/.565)
 # High shoulders exist only at the visible sill, leaving the downstream
 # apron and both lateral edges open.
 shoulders=(1-smooth((X-.452)/.018)+smooth((X-.69)/.018))*.045
 z+=shoulders*np.exp(-((Y-.245)/.023)**6)
 return z

def velocity(q):
 return np.divide(q[1:],q[0][None],out=np.zeros_like(q[1:]),where=q[0][None]>DRY)

def hll(l,r,axis):
 hl,hr=l[0],r[0];vl=velocity(l);vr=velocity(r)
 fl=l*vl[axis];fr=r*vr[axis]
 fl[axis+1]+=.5*G*hl*hl;fr[axis+1]+=.5*G*hr*hr
 cl=np.sqrt(G*hl);cr=np.sqrt(G*hr)
 sl=np.minimum(vl[axis]-cl,vr[axis]-cr);sr=np.maximum(vl[axis]+cl,vr[axis]+cr)
 den=np.maximum(sr-sl,1e-12)
 flux=(sr[None]*fl-sl[None]*fr+(sl*sr)[None]*(r-l))/den[None]
 return np.where((sl>=0)[None],fl,np.where((sr<=0)[None],fr,flux))

def reconstruct(a,b,za,zb):
 top=np.maximum(za,zb);ha=np.maximum(a[0]+za-top,0);hb=np.maximum(b[0]+zb-top,0)
 va=velocity(a);vb=velocity(b)
 return np.concatenate((ha[None],va*ha)),np.concatenate((hb[None],vb*hb)),ha,hb

def rhs(q,z,stage,dx,dy,outlet='open'):
 ny,nx=z.shape
 ext=np.pad(q,((0,0),(1,1),(1,1)),mode='edge');ze=np.pad(z,1,mode='edge')
 # Open lateral edges: no artificial reflecting walls below the sill.
 hs=np.maximum(stage-z[0],0)
 vv=velocity(q[:,0,:]);ext[0,0,1:-1]=hs;ext[1:,0,1:-1]=vv*hs
 left,right=ext[:,1:-1,:-1],ext[:,1:-1,1:]
 l,r,hl,hr=reconstruct(left,right,ze[1:-1,:-1],ze[1:-1,1:]);fx=hll(l,r,0)
 low,high=ext[:,:-1,1:-1],ext[:,1:,1:-1]
 b,t,hb,ht=reconstruct(low,high,ze[:-1,1:-1],ze[1:,1:-1]);fy=hll(b,t,1)
 # First-order outward-only zero-gradient boundaries. Mass and advective
 # momentum use the SAME normal velocity; no hidden weir or invented inflow.
 # This is not an exact nonreflecting boundary for subcritical flow.
 hd=q[0,-1];vd=velocity(q[:,-1,:]);vn=np.maximum(vd[1],0)
 if outlet=='wall':vn*=0
 fy[0,-1]=hd*vn;fy[1,-1]=hd*vn*vd[0]
 fy[2,-1]=hd*vn*vn+.5*G*hd*hd
 for col,face,sign in ((0,0,-1),(-1,-1,1)):
  hh=q[0,:,col];vv=velocity(q[:,:,col]);nn=np.maximum(sign*vv[0],0)*sign
  if outlet=='wall':nn*=0
  fx[0,:,face]=hh*nn;fx[1,:,face]=hh*nn*nn+.5*G*hh*hh
  fx[2,:,face]=hh*nn*vv[1]
 dq=-(fx[:,:,1:]-fx[:,:,:-1])/dx-(fy[:,1:,:]-fy[:,:-1,:])/dy
 # Face-specific hydrostatic pressure correction. For a lake at rest this
 # cancels the flux gradient exactly, including the nonflat bed.
 dq[1]+=.5*G*(hl[:,1:]**2-hr[:,:-1]**2)/dx
 dq[2]+=.5*G*(hb[1:]**2-ht[:-1]**2)/dy
 rates=np.array([np.sum(fy[0,0])*dx,-np.sum(fy[0,-1])*dx,np.sum(fx[0,:,0])*dy,-np.sum(fx[0,:,-1])*dy])
 return dq,rates

def integrate(q,z,x,y,t0,t1,stage_fn,save_times=None):
 dx=x[1]-x[0];dy=y[1]-y[0];t=t0;ledger=np.zeros(4);initial=float(q[0].sum()*dx*dy)
 records=[];states=[];budgets=[];resids=[];steps=0;maxcfl=0.;minh=float(q[0].min());clips=0.
 times=np.asarray(save_times) if save_times is not None else np.array([t1]);oi=0
 while oi<len(times):
  if t>=times[oi]-1e-10:
   states.append(q.copy());records.append(float(times[oi]));budgets.append(ledger.copy());resids.append(float(q[0].sum()*dx*dy-initial-ledger.sum()));oi+=1;continue
  vel=velocity(q);c=np.sqrt(G*q[0]);rate=np.max(abs(vel[0])+c)/dx+np.max(abs(vel[1])+c)/dy
  dt=min(CFL/max(rate,1e-12),float(times[oi]-t));k1,b1=rhs(q,z,stage_fn(t),dx,dy)
  for retry in range(12):
   q1=q+dt*k1
   if q1[0].min() < -1e-12:dt*=.5;continue
   q1[0]=np.maximum(q1[0],0)
   k2,b2=rhs(q1,z,stage_fn(t+dt),dx,dy);qn=.5*(q+q1+dt*k2)
   if qn[0].min() < -1e-12:dt*=.5;continue
   break
  else:raise FloatingPointError('positivity step could not be accepted')
  correction=np.maximum(-qn[0],0).sum()*dx*dy;clips+=float(correction);qn[0]=np.maximum(qn[0],0)
  # Semi-implicit Manning friction removes momentum, never mass.
  vn=velocity(qn);speed=np.hypot(vn[0],vn[1]);fric=G*.018**2*speed/np.maximum(qn[0],1e-5)**(4/3)
  qn[1:]/=(1+dt*fric)[None];qn[1:,qn[0]<DRY]=0
  if not np.isfinite(qn).all():raise FloatingPointError('nonfinite state')
  q=qn;ledger+=dt*.5*(b1+b2);t+=dt;steps+=1;maxcfl=max(maxcfl,dt*rate);minh=min(minh,float(q[0].min()))
 return q,np.array(states),{'steps':steps,'max_multidimensional_cfl':maxcfl,'min_depth_m':minh,'boundary_volume_m3':ledger.tolist(),'max_mass_residual_m3':max(map(abs,resids)),'positivity_roundoff_correction_m3':clips},np.array(budgets)

def solve(nx=80,ny=88,warmup=5.,save=True):
 start=time.time();dx=(X1-X0)/nx;dy=(Y1-Y0)/ny;x=X0+(np.arange(nx)+.5)*dx;y=Y0+(np.arange(ny)+.5)*dy;z=bed_field(x,y)
 q=np.zeros((3,ny,nx));q[0]=np.maximum(.020-z,0)*(y[:,None]<.245)
 # Test an arbitrary elevated still lake, without a boundary stage mismatch.
 lake=np.zeros_like(q);lake[0]=np.maximum(.08-z,0);lr,_=rhs(lake,z,.08,dx,dy,outlet='wall')
 lake_error=float(np.max(np.abs(lr)))
 q,_,warm,_=integrate(q,z,x,y,-warmup,0.,lambda t:.020)
 src=np.load(ROOT/'water.npz');times=np.arange(193)/24
 data={'t':times,'x':x,'y':y,'bed':z.astype(np.float32)};metrics={'model':'2D HLL hydrostatic-reconstruction SWE, SSPRK2, Manning friction','grid':[nx,ny],'domain_m':[X0,X1,Y0,Y1],'warmup_seconds':warmup,'warmup':warm,'lake_at_rest_max_rhs':lake_error,'cases':{}}
 for name in ['baseline','A']:
  head=src['baseline' if name=='baseline' else 'A'][:,3]
  stage=lambda t:float(np.interp(t,src['t'],head))
  final,frames,m,ledger=integrate(q.copy(),z,x,y,0,8,stage,times)
  vel=np.divide(frames[:,1:],frames[:,0,None],out=np.zeros_like(frames[:,1:]),where=frames[:,0,None]>DRY)
  data['h_'+name]=frames[:,0].astype(np.float32);data['u_'+name]=vel[:,0].astype(np.float32);data['v_'+name]=vel[:,1].astype(np.float32);data['ledger_'+name]=ledger
  wet=(frames[:,0]>.0004)&(y[None,:,None]>.27)
  m['wet_apron_area_m2_initial']=float(wet[0].sum()*dx*dy);m['wet_apron_area_m2_final']=float(wet[-1].sum()*dx*dy)
  m['max_depth_m']=float(frames[:,0].max());m['max_speed_mps']=float(np.hypot(vel[:,0],vel[:,1]).max());metrics['cases'][name]=m
 metrics['identical_initial_fields']=bool(np.array_equal(data['h_A'][0],data['h_baseline'][0]));metrics['runtime_s']=time.time()-start
 metrics['outlet']='Open downstream and lateral boundaries; outflow is a one-way boundary flux, not a receiving basin.'
 metrics['initial_condition']='Five-second baseline preparation; shared initial state, not claimed to be steady.'
 metrics['limitations']='Depth averaged hydrostatic local model; not 3D breaking waves/air entrainment. Optical foam and ripples are illustrative.'
 if save:
  np.savez_compressed(ROOT/'fluid_fields.npz',**data);(ROOT/'fluid-metrics.json').write_text(json.dumps(metrics,indent=2));print(json.dumps(metrics,indent=2),flush=True)
 return data,metrics

if __name__=='__main__':solve()
