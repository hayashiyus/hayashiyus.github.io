# -*- coding: utf-8 -*-
"""Build the v21 same-outcome motion review without mutating v17 or the article."""
from pathlib import Path
import html
import json
import os
import shutil

ROOT = Path(__file__).resolve().parent
PUBLISH = ROOT.parents[2] / "publish/blog/weight-space-geometry/en/motion-v21"
DOWNLOAD = Path(os.environ.get("WSP_MOTION_V21_OUT", str(ROOT / "dist")))


def esc(value):
    return html.escape(str(value), quote=True)


def link_if_exists(path, label):
    if not path.exists():
        return ""
    return f'<a href="{esc(path.name)}">{esc(label)}</a>'


def metric_rows(metrics):
    rows = []
    cases = metrics.get("cases", {})
    for name in ("baseline", "A", "B", "A_no_outward", "B_no_pole"):
        case = cases.get(name)
        if not case:
            continue
        rows.append(
            "<tr>"
            f"<th>{esc(name)}</th>"
            f"<td>{'yes' if case.get('exit') else 'no'}</td>"
            f"<td>{'yes' if case.get('reaches_shared_apron') else 'no'}</td>"
            f"<td>{esc(format(case['full_exit_time_s'],'.3f') if case.get('full_exit_time_s') is not None else '—')}</td>"
            f"<td>{esc(format(case['min_water_over_lip_m']*1000,'.2f') if case.get('min_water_over_lip_m') is not None else '—')}</td>"
            f"<td>{'yes' if case.get('opening_width_clearance') else 'no'}</td>"
            "</tr>"
        )
    residual = metrics.get("volume_balance_max_error_m3", {})
    for name, value in residual.items():
        rows.append(
            "<tr>"
            f"<th>volume balance · {esc(name)}</th><td colspan=4>{esc(f'{value:.3e} m³')}</td><td>recorded</td>"
            "</tr>"
        )
    return "".join(rows)


def clip_markup(kind, caption, poster):
    src = ROOT / f"detail-{kind}.mp4"
    if not src.exists():
        return ""
    poster_attr = f' poster="{esc(poster.name)}"' if poster.exists() else ""
    return (
        f'<figure><video controls muted loop playsinline preload="none"{poster_attr}>'
        f'<source src="{esc(src.name)}" type="video/mp4"></video>'
        f"<figcaption>{esc(caption)}</figcaption></figure>"
    )


def build_html(metrics):
    poster = next((ROOT / n for n in ("poster.jpg", "frame-20.jpg", "frame-18.jpg", "frame-00.jpg") if (ROOT / n).exists()), None)
    poster_attr = f' poster="{esc(poster.name)}"' if poster else ""
    poster_image = f'<img class="poster" src="{esc(poster.name)}" alt="v21 main-river review poster">' if poster else ""
    mp4 = ROOT / "motion-review.mp4"
    gif = ROOT / "motion-review.gif"
    film = (
        f'<video id="film" autoplay muted loop playsinline preload="auto"{poster_attr}>'
        f'<source src="motion-v21.mp4" type="video/mp4"></video>'
        if mp4.exists() else poster_image
    )
    gif_markup = '<img id="gif" alt="v21 same-outcome motion review">' if gif.exists() else ""
    stills = []
    for filename, label in (("frame-09.jpg", "A / 流れで岸を越える"), ("frame-18.jpg", "B / 棒で岸を越える")):
        path = ROOT / filename
        if path.exists():
            stills.append(f'<figure><img class="still" src="{esc(filename)}" alt="{esc(label)}"><figcaption>{esc(label)}</figcaption></figure>')
    clips = "".join([
        clip_markup("left", "左：水門の鉛直変位と主水路の応答。", ROOT / "detail-left.jpg"),
        clip_markup("right", "右：有限長の棒による一方向の船体接触。", ROOT / "detail-right.jpg"),
        clip_markup("water", "水：水位上昇、低い岸での加速、岸外の濡れる範囲の変化。", ROOT / "detail-water.jpg"),
    ])
    links = []
    for filename, label in (
        ("PRODUCTION_SCRIPT.md", "制作台本"),
        ("stage-plan.svg", "ステージ計画"),
        ("dynamics-metrics.json", "船の動力学"),
        ("fluid-metrics.json", "水量収支と静水保持"),
        ("fluid-refinement.json", "格子細密化比較"),
        ("style-only-verification.json", "物理データの同一性"),
        ("media-qa.json", "映像・表示検査"),
        ("verification-v21.json", "v21検証記録"),
        ("delivery.json", "配布記録"),
        ("README.md", "再現手順"),
        ("storyboard.jpg", "12コマ絵コンテ"),
        ("rig-verification-v21.json", "役者と棒の幾何検査"),
    ):
        item = link_if_exists(ROOT / filename, label)
        if item:
            links.append(item)
    return f'''<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>One garden · one river · v21 review</title><link rel="icon" href="data:,"><style>
:root{{color-scheme:light}}*{{box-sizing:border-box}}body{{margin:0;background:#fdfcf9;color:#29354a;font:17px/1.8 Georgia,"Hiragino Mincho ProN",serif}}main{{max-width:1180px;margin:auto;padding:32px 28px 80px}}header{{max-width:960px;margin:0 auto 28px}}small,.meta{{font:12px/1.7 system-ui;letter-spacing:.08em;color:#75808c}}h1{{font-size:clamp(24px,3.2vw,42px);font-weight:400;margin:12px 0}}p{{max-width:960px}}video,.poster,.still{{width:100%;display:block;background:#fff}}figure{{margin:0}}figcaption{{font:14px/1.7 system-ui;color:#586575;padding:12px 0}}nav{{display:flex;gap:10px;flex-wrap:wrap;margin:12px 0 30px}}button,a.button{{font:14px system-ui;border:1px solid #d5d9df;border-radius:5px;background:#fffdf8;padding:10px 16px;color:#30435c;text-decoration:none;cursor:pointer}}button:focus-visible,a:focus-visible{{outline:3px solid #72a9c8}}details{{border-top:1px solid #dededb;padding:18px 0;max-width:1000px}}summary{{cursor:pointer;font-size:20px}}table{{border-collapse:collapse;width:100%;font:14px/1.7 system-ui;margin:16px 0}}td,th{{text-align:left;padding:9px;border-bottom:1px solid #e3e2dd}}pre{{white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.6 monospace}}a{{color:#3b799f}}#gif{{display:none;width:100%}}.clips,.stills{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px}}.clips figure:last-child{{grid-column:1/-1}}.review{{color:#8d6938}}.table-scroll{{overflow-x:auto;max-width:100%}}.pending{{color:#996f2d;font-family:system-ui;font-size:14px}}footer{{margin-top:35px;font:13px/1.7 system-ui;color:#697380}}@media(prefers-reduced-motion:reduce){{html{{scroll-behavior:auto}}}}@media(max-width:520px){{main{{padding:18px 14px 40px}}table{{font-size:12px}}td,th{{padding:7px 4px}}.clips,.stills{{grid-template-columns:1fr}}}}
</style></head><body><main><header><small>WEIGHT-SPACE GEOMETRY / MAIN-RIVER STUDY / V21</small><h1>A visible sill. An open slope.</h1><p class="review">一つのS字水路に、見える低い越流堰と、白木の開放斜面を設けました。通常時から堰を浅い水が越えています。開門はその流れを強め、棒は船へ直接力を加えます。二つとも同じ堰を越える結果になりますが、軌跡全体の一致は主張しません。</p><p class="pending">22 SECONDS · VISIBLE LOW SILL · OPEN SLOPE</p></header>
<figure>{film}{gif_markup}<figcaption>補助水路なし。元絵の主水路を使い、手前の白木の岸の一部を低くしました。右端の元の滝へ進むこととは異なるコースアウトです。</figcaption></figure>
<nav><button id="toggle" type="button">一時停止</button><button id="restart" type="button">最初から</button>{'<button id="gif-toggle" type="button">GIFへ切り替え</button>' if gif.exists() else ''}<a class="button" href="motion-v21.mp4" download>MP4を保存</a></nav>
{f'<section class="stills">{"".join(stills)}</section>' if stills else ''}
{f'<details><summary>局所映像を確認する</summary><div class="clips">{clips}</div></details>' if clips else ''}
<details open><summary>同じ結果として何を確認するか</summary><div class="table-scroll"><table><thead><tr><th>case</th><th>exit</th><th>open slope</th><th>exit time (s, take)</th><th>head over lip (mm)</th><th>opening clear</th></tr></thead><tbody>{metric_rows(metrics)}</tbody></table></div><p>A は水門開度による主水路のパルス、B は有限長の棒による一方向の船体接触です。A/B の exact path、速度、力の一致は主張しません。計算は8秒間保存し、映像では両テイクとも同じ0–7.6秒の物理区間を8秒で表示します。アブレーションは、この縮約モデルにおける因果の必要条件を点検する比較です。</p></details>
<details open><summary>なぜ、ここから溢れるのか</summary><p>通常の壁より低い切り下げ部を設け、その形を数値地形と原画への描画で共有しています。外側の隠れた高い縁と受け盆は撤去しました。水は開放斜面の先へ流出します。<a href="stage-plan.svg">断面図を開く</a></p><img class="still" src="stage-plan.png" alt="低い堰の横断面と、閉じた受け盆を持たない開放斜面の縦断面"></details>
<details><summary>モデルの範囲</summary><p><strong>Local 2D shallow-water equations + HLL flux + hydrostatic reconstruction + SSPRK2 + Manning friction.</strong> 越流部の水深・平均流速・濡れる境界を計算しています。上流は4区間の貯留モデルで、水位を局所計算へ渡します。飛沫や気泡を解く3次元CFDではなく、細波・反射・泡の見え方は計算結果に従う描画表現です。</p><p>二つの場面は5秒間の準備計算後の同じ水面から始まります。これは定常状態という意味ではありません。溢れた水は下り斜面から外へ流出します。表示外へ流れる短い落水は、出口の水深と流速を使った描画上の延長であり、3次元の気液計算ではありません。水量収支、静水保持、格子の細密化、出口位置、船の喫水と開口通過を別々に検査しました。完全な8秒区間は細密格子でBの喫水条件をわずかに下回るため、映像の比較区間には採用していません。棒の接触はばねモデルであり、約1.68mmの接触変形を許しています。</p></details>
<details><summary>台本・証跡</summary><p>{' · '.join(links) or '証跡ファイルは生成後に追加されます。'}</p><p>受入れには baseline remains、A/B exit、causal ablations、volume balance、unilateral contact、grip/feet、実モーション QA が必要です。計算検証と映像の確認結果は下記の証跡に分けて記録します。</p></details>
<footer>v21 motion review · local explanatory artifact · no Weave generation · no public publishing</footer></main><script>
const film=document.querySelector('#film'),gif=document.querySelector('#gif'),toggle=document.querySelector('#toggle'),gifToggle=document.querySelector('#gif-toggle');const reduced=matchMedia('(prefers-reduced-motion: reduce)');let gifMode=false,wantPlay=!reduced.matches;function label(){{if(toggle)toggle.textContent=film&&film.paused?'再生':'一時停止'}}if(film){{if(reduced.matches){{film.autoplay=false;film.pause()}}film.onplay=label;film.onpause=label}}if(toggle)toggle.onclick=()=>{{if(gifMode){{gif.removeAttribute('src');gif.style.display='none';film.style.display='block';gifMode=false;gifToggle.textContent='GIFへ切り替え';wantPlay=false;film.pause()}}else if(film.paused){{wantPlay=true;film.play()}}else{{wantPlay=false;film.pause()}}label()}};document.querySelector('#restart').onclick=()=>{{if(!film)return;gifMode=false;if(gif){{gif.removeAttribute('src');gif.style.display='none'}}film.style.display='block';if(gifToggle)gifToggle.textContent='GIFへ切り替え';film.currentTime=0;wantPlay=!reduced.matches;if(wantPlay)film.play();label()}};if(gifToggle)gifToggle.onclick=()=>{{gifMode=!gifMode;if(gifMode){{film.pause();film.style.display='none';gif.src='motion-v21.gif';gif.style.display='block';toggle.textContent='アニメーションを停止'}}else{{gif.removeAttribute('src');gif.style.display='none';film.style.display='block';if(!reduced.matches)film.play();label()}}gifToggle.textContent=gifMode?'MP4へ戻す':'GIFへ切り替え'}};reduced.addEventListener('change',()=>{{if(reduced.matches&&film){{wantPlay=false;film.pause();if(gifMode){{gif.removeAttribute('src');gif.style.display='none';film.style.display='block';gifMode=false;gifToggle.textContent='GIFへ切り替え'}}label()}}}});label();
if(film)fetch('motion-v21.mp4').then(r=>r.blob()).then(b=>{{const t=film.currentTime;film.src=URL.createObjectURL(b);film.onloadedmetadata=()=>{{film.currentTime=t;if(wantPlay&&!reduced.matches&&!gifMode)film.play().catch(()=>{{}});label()}}}}).catch(()=>{{}});
</script></body></html>'''


def copy_or_link(src, dest):
    if not src.exists():
        return False
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        if dest.is_file() and dest.samefile(src):
            return True
        dest.unlink()
    try:
        os.link(src, dest)
    except OSError:
        shutil.copy2(src, dest)
    return True


def main():
    metrics = json.loads((ROOT / "dynamics-metrics.json").read_text())
    PUBLISH.mkdir(parents=True, exist_ok=True)
    DOWNLOAD.mkdir(parents=True, exist_ok=True)
    (ROOT / "index.html").write_text(build_html(metrics), encoding="utf-8")

    assets = {"index.html": "index.html", "motion-review.mp4": "motion-v21.mp4", "motion-review.gif": "motion-v21.gif"}
    for filename in ("poster.jpg", "frame-09.jpg", "frame-18.jpg", "frame-20.jpg", "frame-07.jpg", "frame-12.jpg", "PRODUCTION_SCRIPT.md", "stage-plan.svg", "stage-plan.png", "dynamics-metrics.json", "verification-v21.json", "fluid-metrics.json", "fluid-refinement.json", "physics-contract.json", "style-only-verification.json", "media-qa.json", "delivery.json", "README.md", "storyboard.jpg", "rig-verification-v21.json", "encoded-contact-sheet.jpg", "figma-review.png"):
        assets[filename] = filename
    for kind in ("left", "right", "water"):
        for ext in ("mp4", "jpg"):
            assets[f"detail-{kind}.{ext}"] = f"detail-{kind}.{ext}"
    for source_name, output_name in assets.items():
        src = ROOT / source_name
        if not src.exists():
            continue
        copy_or_link(src, PUBLISH / output_name)
        copy_or_link(src, DOWNLOAD / output_name)
    print(PUBLISH)
    print(DOWNLOAD)


if __name__ == "__main__":
    main()
