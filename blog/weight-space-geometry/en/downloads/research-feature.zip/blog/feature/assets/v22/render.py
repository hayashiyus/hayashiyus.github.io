"""Deterministic watercolor compositor; no generated video or boat retiming.

A prescribed upstream response connects to a local shallow-water model.
The boat is integrated from flow and pole forces; subgrid optics are artistic.
"""
from pathlib import Path
import sys,json,subprocess,math
import cv2,numpy as np
from PIL import Image,ImageDraw,ImageFont
from scipy.interpolate import CubicSpline
from scipy.spatial import cKDTree
from motion import Motion,project,M,ORIGIN,ZPX,smooth
from rig.mesh import SRC,FREE,ACTORS,over
from water_paint import paint_water
from spill import Spill
from waterfall_paint import MainFall
from gate_paint import paint_gate_water
from boats import L, WIDTH
from river_flow import RiverFlow
from river_tracers import RiverTracers
from callouts import draw_callouts
ROOT=Path(__file__).resolve().parent
W,H=1536,1024
TAKE_END=11.2
CLOCK=1.0  # identical physical/display clock for all three takes
DURATION=24
BOAT_SCALE=1.20
PAPER=(253,252,250);BLUE=(61,131,178);GOLD=(180,137,58);INK=(42,54,76)
RIVER=np.array([(325,375),(370,364),(430,369),(487,384),(532,406),(555,438),(585,448),(670,446),(738,452),(781,471),(797,511),(813,532),(875,547),(924,567),(945,603),(974,626),(1070,627),(1172,622),(1242,629),(1313,654),(1362,682),(1393,708),(1407,754),(1435,830),(1388,841),(1368,774),(1351,746),(1290,712),(1221,696),(1136,699),(1040,709),(974,709),(937,692),(917,638),(884,619),(829,613),(786,591),(760,561),(746,524),(710,512),(637,523),(568,520),(528,497),(507,454),(487,424),(442,399),(363,390),(316,384)],float)
ROUTE=np.array([(338,374),(435,383),(505,414),(535,476),(585,498),(679,487),(748,502),(780,543),(815,572),(898,595),(937,635),(974,666),(1090,660),(1190,659),(1268,680),(1350,716),(1381,755)],float)
FONT='/System/Library/Fonts/Supplemental/Georgia.ttf'
SANS='/System/Library/Fonts/Helvetica.ttc'

def polyalpha(points):
    a=np.zeros((H,W),np.uint8);cv2.fillPoly(a,[np.rint(points).astype(np.int32)],255)
    return cv2.GaussianBlur(a,(3,3),.65)

def curve(points,n=700):
    t=np.r_[0,np.cumsum(np.linalg.norm(np.diff(points,axis=0),axis=1))]
    cs=CubicSpline(t,points,bc_type='natural');s=np.linspace(0,t[-1],n)
    return s,cs(s),cs(s,1)

class Renderer:
    def __init__(self):
        self.motion=Motion()
        self.texture=np.asarray(Image.open(ROOT/'straight-clean-plate.png').convert('RGB'))
        self.base=self.texture.copy()
        # One connected painted-water footprint through the final bend. There
        # is no rectangular cut at x=920 and no velocity switch at x=970.
        back=[(325,375),(370,364),(430,369),(487,384),(532,406),(555,438),
              (585,448),(670,446),(738,452),(781,471),(797,511),(813,532),
              (850,558),(875,565),(900,579),(925,596),(950,614),(975,620),
              (1000,626),(1050,637),(1100,650),(1150,660),(1200,672),(1270,689),(1300,698)]
        front=[(1300,741),(1270,730),(1200,714),(1150,705),(1100,695),(1050,684),
               (1000,674),(975,666),(950,658),(925,647),(900,629),(875,615),
               (850,608),(829,613),(786,591),(760,561),(746,524),(710,512),
               (637,523),(568,520),(528,497),(507,454),(487,424),(442,399),(363,390),(316,384)]
        self.source_watermask=polyalpha(np.array(back+front,float))
        yy,xx=np.mgrid[:H,:W]
        inside=cv2.distanceTransform((self.source_watermask>128).astype(np.uint8),cv2.DIST_L2,3)
        rgb=self.texture.astype(float);guard=smooth((rgb[:,:,2]-rgb[:,:,0]+3)/9)
        guard=1-(1-guard)*(1-smooth((inside-1)/4))
        self.source_watermask=(self.source_watermask*guard).astype(np.uint8)
        self.watermask=(self.source_watermask*(1-smooth((xx-1200)/70))).astype(np.uint8)
        # The new clean plate has no right actor, pole, or static boat images.
        # Only the preserved left actor must be removed before the original rig.
        left=ACTORS['left_operator'];erase=cv2.dilate(left.alpha,np.ones((3,3),np.uint8))
        self.base=over(self.base,np.dstack((FREE,erase)))
        # FREE predates the approved sliding gate and contains a fixed wheel.
        # Remove that obsolete hardware in full; the hand/handle and stem each
        # have one moving owner below. Masking out the actor alpha left a ghost
        # wheel beneath the raised hand.
        hardware=np.zeros((H,W),np.uint8)
        cv2.rectangle(hardware,(250,279),(308,330),255,-1)
        cv2.rectangle(hardware,(278,329),(294,347),255,-1)
        self.base=cv2.inpaint(self.base,hardware,4,cv2.INPAINT_TELEA)
        self.river_flow=RiverFlow(self.motion)
        self.s=self.river_flow.s;self.route=self.river_flow.route;self.tangent=self.river_flow.tangent
        self.tracers=RiverTracers(self.river_flow,self.motion)
        self.yy,self.xx=np.where(self.watermask>2)
        pix=np.c_[self.xx,self.yy]
        _,nearest=cKDTree(self.route).query(pix)
        self.arc=self.s[nearest];self.tan=self.tangent[nearest]
        self.normal=np.c_[-self.tan[:,1],self.tan[:,0]]
        self.cross=np.sum((pix-self.route[nearest])*self.normal,axis=1)
        self.wateralpha=self.watermask[self.yy,self.xx,None]/255.
        self.boat=self.boat_texture()
        self.spill=Spill(self.texture)
        self.main_fall=MainFall(self.texture)
        q=self.motion.water.hydro.d;self.fall_clocks={}
        reference=float((q['h_baseline'][0,:,-1]*np.maximum(q['u_baseline'][0,:,-1],0)).sum())
        for key in ('baseline','A'):
            flux=(q['h_'+key][:,:,-1]*np.maximum(q['u_'+key][:,:,-1],0)).sum(axis=1)
            speed=np.clip(flux/max(reference,1e-9),.4,2.5)
            self.fall_clocks[key]=np.r_[0,np.cumsum(np.diff(q['t'])*(speed[:-1]+speed[1:])*.5)]

    def boat_texture(self):
        outline=np.array([(614,478),(641,479),(651,462),(662,479),(690,467),(683,490),(662,501),(637,503),(624,492)])
        a=polyalpha(outline);b=np.dstack((SRC,a))[457:509,608:697]
        return Image.fromarray(b).resize((76,44),Image.Resampling.LANCZOS)

    def water(self,take,t):
        return paint_water(self,take,t)

    def gate(self,im,lift,t=0):
        # Fixed two rails, single vertically translated leaf/short stem. The
        # working copy beneath the leaf reveals water rather than stretched gold.
        out=Image.fromarray(im);d=ImageDraw.Draw(out,'RGBA')
        rails=[(254,352,258,418),(322,334,327,398)]
        opening=polyalpha(np.array([(257,354),(324,335),(324,402),(257,422)]))
        wet=cv2.resize(SRC[381:397,375:433],(68,88),interpolation=cv2.INTER_LINEAR)
        waterplate=np.zeros_like(im);waterplate[335:423,257:325]=wet
        out=Image.fromarray(over(np.asarray(out.convert('RGB')),np.dstack((waterplate,opening))))
        out=Image.fromarray(paint_gate_water(np.asarray(out.convert('RGB')),self.texture,lift,t,lift/18))
        d=ImageDraw.Draw(out,'RGBA')
        for x1,y1,x2,y2 in rails:d.line([(x1,y1-20),(x2,y2)],fill=(145,111,48,255),width=7)
        p=np.array([(260,356),(319,339),(320,392),(260,413)],float)
        a=polyalpha(p);layer=np.dstack((SRC,a))
        layer=cv2.warpAffine(layer,np.array([[1,0,0],[0,1,-lift]],float),(W,H))
        out=Image.fromarray(over(np.asarray(out.convert('RGB')),layer));d=ImageDraw.Draw(out,'RGBA')
        # Leaf top at x=285 is y=348.8. The stem must overlap the leaf,
        # rather than stopping above it and leaving a floating handle.
        d.line([(285,352-lift),(285,306-lift)],fill=(143,109,43,255),width=6)
        d.line([(283,351-lift),(283,307-lift)],fill=(222,190,107,255),width=2)
        # A visible notch/latch holds the opened gate after the lift.
        if lift>17.9:d.line([(320,332-lift),(328,332-lift)],fill=(114,94,57,255),width=3)
        return np.asarray(out.convert('RGB'))

    def hull(self,im,pos,yaw=0,size=42):
        # Scale the previous 42x24 sprite by exactly 1.20 around its waterline
        # anchor. Fractional affine sampling avoids rounding 50.4 down to 50.
        base=np.asarray(self.boat.resize((42,24),Image.Resampling.LANCZOS).convert('RGBA')).astype(np.float32)
        scale=BOAT_SCALE*size/42
        A=cv2.getRotationMatrix2D((0,0),-float(yaw)*180/np.pi,scale)
        A[:,2]=np.asarray(pos)-A[:,:2]@np.array([21.,16.])
        corners=np.c_[[0,42,42,0],[0,0,24,24]]@A[:,:2].T+A[:,2]
        lo=np.floor(corners.min(0)).astype(int)-2;hi=np.ceil(corners.max(0)).astype(int)+2
        lo=np.maximum(lo,[0,0]);hi=np.minimum(hi,[W,H])
        if np.any(hi<=lo):return im
        A[:,2]-=lo;alpha=base[:,:,3:]/255.;base[:,:,:3]*=alpha
        sprite=cv2.warpAffine(base,A,tuple(hi-lo),flags=cv2.INTER_CUBIC,borderMode=cv2.BORDER_CONSTANT)
        aa=np.clip(sprite[:,:,3:]/255,0,1)
        rgb=np.divide(sprite[:,:,:3],aa,out=np.zeros_like(sprite[:,:,:3]),where=aa>1e-5)
        out=Image.fromarray(im);d=ImageDraw.Draw(out,'RGBA');x,y=pos;w=size*BOAT_SCALE
        d.ellipse((x-w*.43,y-w*.07,x+w*.43,y+w*.09),fill=(45,84,105,35))
        out=np.asarray(out).copy();x0,y0=lo;x1,y1=hi
        out[y0:y1,x0:x1]=np.clip(out[y0:y1,x0:x1]*(1-aa)+rgb*aa,0,255).astype(np.uint8)
        return out

    def scene(self,take,t,comparison=False):
        im=self.spill.draw(self.water(take,t),self.motion,take,t)
        # One coherent animated normal waterfall, distinct from the side outlet.
        q=self.motion.water.hydro.d;key='A' if take=='A' else 'baseline'
        clock=float(np.interp(max(0,t),q['t'],self.fall_clocks[key]))
        im=self.main_fall.draw(im,clock)
        g=self.motion.geometry(take,max(0,t))
        if t<0:
            g['state'][:2]+=g['state'][3:5]*t
            g['boat_px']=project(g['state'][:2])
        im=self.gate(im,g['gate_lift_px'],t)
        # Passive boats share the water's route-time field and enter the same
        # local force model continuously. No deletion at an arbitrary arc.
        for tracer in self.tracers.frame(take,t):
            if tracer['active']:im=self.hull(im,tracer['pos_px'],tracer['yaw'])
        state=g['state'];im=self.spill.wake(im,self.motion,take,t);im=self.hull(im,g['boat_px'],state[2],size=42)
        # A single shaft, before the grips. Both hand targets are computed from
        # two fixed distances on this same finite rigid pole.
        actorlayers=[]
        for name,actor in ACTORS.items():
            hands={'hand':np.asarray(actor.j['hand'])-[0,g['gate_lift_px']]} if actor.left else {'hand_front':g['hand_front_px'],'hand_back':g['hand_back_px']}
            rgba,diag=actor.layer(hands,g['right_body_cue'] if not actor.left else None);im=over(im,rgba);actorlayers.append((actor,rgba,diag))
        # The hand and its gripped original handle form one rigid local part;
        # the whole shoulder/elbow mesh still drives the surrounding cloth.
        handpoly=np.array([(257,287),(267,281),(295,279),(309,290),(308,305),(298,312),(280,315),(262,306),(256,299)],float)
        hl=np.dstack((SRC,polyalpha(handpoly)))
        hl=cv2.warpAffine(hl,np.array([[1,0,0],[0,1,-g['gate_lift_px']]],float),(W,H))
        im=over(im,hl)
        out=Image.fromarray(im).convert('RGBA');d=ImageDraw.Draw(out,'RGBA')
        tip,end=g['tip_px'],g['pole_end_px']
        d.line([tuple(tip),tuple(end)],fill=(142,109,46,255),width=4)
        d.line([tuple(tip+[-1,0]),tuple(end+[-1,0])],fill=(226,198,128,240),width=1)
        im=np.asarray(out.convert('RGB'))
        actor,rgba,diag=actorlayers[1]
        fingers=np.zeros((H,W),np.uint8)
        handR=np.asarray(diag['hand_rotation'])
        palms={'front':[(1271,514),(1280,509),(1290,516),(1291,529),(1280,536),(1269,527)],
               'back':[(1321,454),(1332,450),(1341,455),(1340,467),(1330,471),(1320,465)]}
        for side in ('front','back'):
            source=np.asarray(actor.j['hand_'+side]);target=g['hand_'+side+'_px']
            polygon=(np.asarray(palms[side])-source)@handR.T+target
            cv2.fillConvexPoly(fingers,np.rint(polygon).astype(np.int32),255)
        hand_layer=rgba.copy();hand_layer[:,:,3]=(hand_layer[:,:,3].astype(float)*fingers/255).astype(np.uint8)
        im=over(im,hand_layer)
        return im

    def trail(self,im,take,t,alpha=180):
        data=self.motion.boats[take];data=data[data[:,0]<=t]
        if len(data)<2:return im
        pts=[]
        for row in data[::12]:
            z=self.motion.water.surface_z(take,row[0],row[None,1:3])[0]
            pts.append(tuple(project(row[1:3],z)))
        if len(pts)<2:return im
        out=Image.fromarray(im);d=ImageDraw.Draw(out,'RGBA')
        color={'baseline':(111,132,145),'A':BLUE,'B':GOLD}[take]
        d.line(pts,fill=(*color,alpha),width=2)
        return np.asarray(out.convert('RGB'))

    def take(self,key,seconds):
        terminal=float(self.motion.boats[key][-1,0]);t=min(seconds*CLOCK,terminal)
        im=self.scene(key,t)
        im=self.trail(im,key,t)
        done=seconds*CLOCK>=terminal
        g=self.motion.geometry(key,t)
        g['held_for_s']=max(0.,seconds-terminal/CLOCK)
        return draw_callouts(im,key,seconds,g,done)

    def frame(self,t):
        if t<10.5:
            return self.take('baseline',t)
        if t<11:
            w=float(smooth((t-10.5)/.5));a=self.frame(10.499);b=self.scene('A',0)
            return np.uint8(a*(1-w)+b*w)
        if t<14:
            return self.take('A',t-11)
        if t<14.5:
            w=float(smooth((t-14)/.5));a=self.frame(13.999);b=self.scene('B',0)
            return np.uint8(a*(1-w)+b*w)
        if t<21.5:
            return self.take('B',t-14.5)
        if t<23.5:
            im=self.scene('baseline',0)
            for k in ['baseline','A','B']:im=self.trail(im,k,TAKE_END,195)
            return draw_callouts(im,'summary',t-21.5,self.motion.geometry('baseline',0))
        w=float(smooth((t-23.5)/.5));return np.uint8(self.frame(23)*(1-w)+self.frame(0)*w)

_WORKER=None
def worker_init():
    global _WORKER
    cv2.setNumThreads(1)
    _WORKER=Renderer()
def worker_frame(arg):
    i,fps=arg
    return _WORKER.frame(i/fps).tobytes()

def main():
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--movie',action='store_true');p.add_argument('--workers',type=int,default=4);p.add_argument('--fps',type=int,default=24);p.add_argument('--width',type=int,default=1536);p.add_argument('--output',type=Path,default=ROOT/'motion-review.mp4');args=p.parse_args()
    if not args.movie:
        r=Renderer()
        for t in [0,4,8,10,11,12,13,17,19,20,21,23]:Image.fromarray(r.frame(t)).save(ROOT/f'frame-{t:02}.jpg',quality=93)
        return
    h=round(args.width*H/W/2)*2
    proc=subprocess.Popen(['ffmpeg','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(args.fps),'-i','-','-an','-vf',f'scale={args.width}:{h}:flags=lanczos','-c:v','libx264','-preset','medium','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart','-y',str(args.output)],stdin=subprocess.PIPE)
    import multiprocessing as mp
    try:
        with mp.get_context('spawn').Pool(args.workers,initializer=worker_init) as pool:
            for i,frame in enumerate(pool.imap(worker_frame,((i,args.fps) for i in range(DURATION*args.fps)),chunksize=2)):
                proc.stdin.write(frame)
                if i%args.fps==0:print(f'{i/args.fps:.0f}/24 seconds rendered',flush=True)
    finally:proc.stdin.close()
    if proc.wait():raise RuntimeError('ffmpeg failed')

if __name__=='__main__':main()
