"""A reduced, deterministic main-river overflow demonstration (SI units).

Four connected storage reaches, a free-overflow rating, a planar rigid boat.
This is not a spatial shallow-water/3-D CFD solution. Local water velocities
are a declared closure; the renderer never corrects the integrated boat path.
"""
from pathlib import Path
import json
import numpy as np
ROOT=Path(__file__).resolve().parent
L=.08; WIDTH=.045; MASS=.006; DRAFT=.0008
LIP_Y=.245; LIP_X=(.47,.69); CREST=.017
AREAS=np.array([.05,.05,.08,.18]); C=1.5; B=LIP_X[1]-LIP_X[0]
ETA0=.020; MAIN0=.000072
SPILL0=C*B*(ETA0-CREST)**1.5; Q0=MAIN0+SPILL0
EXTRA=.00065; DRAG=.014
INITIAL=np.array([.43,.10,0.,.020,0.,0.])
START=2.7; END=5.4; RETRACT=4.7; STROKE=.155; STIFFNESS=1.0

def smooth(x):
    x=np.clip(x,0,1);return x*x*(3-2*x)

def water_rhs(t,s,gate):
    eta=s[:4]
    qin=Q0+(EXTRA*smooth(t/1.6) if gate else 0.)
    q=Q0+.08*(eta[:3]-ETA0)
    main=MAIN0*(max(eta[3],0)/ETA0)**1.5
    spill=C*B*max(eta[3]-CREST,0)**1.5
    return np.r_[(np.r_[qin,q]-np.r_[q,main+spill])/AREAS,qin,main,spill]

def rk4(fn,t,y,dt):
    a=fn(t,y);b=fn(t+dt/2,y+dt*a/2);c=fn(t+dt/2,y+dt*b/2);d=fn(t+dt,y+dt*c)
    return y+dt*(a+2*b+2*c+d)/6

def water_solve(gate,dt):
    ts=np.arange(round(8/dt)+1)*dt;s=np.r_[np.full(4,ETA0),0.,0.,0.];rows=[s.copy()]
    for t in ts[:-1]:s=rk4(lambda t,s:water_rhs(t,s,gate),t,s,dt);rows.append(s.copy())
    return ts,np.array(rows)

class Water:
    def __init__(self,path=None):
        self.data=dict(np.load(path or ROOT/'water.npz'))
    def levels(self,take,t):
        arr=self.data['A' if take in ('A','gate','A_no_outward') else 'baseline']
        return np.array([np.interp(t,self.data['t'],arr[:,i]) for i in range(4)])
    def sample(self,take,t,xy):
        xy=np.atleast_2d(xy);eta=self.levels(take,t)[3]
        q=C*B*max(eta-CREST,0)**1.5
        # Smooth aperture influence, predominantly downstream outside it.
        x,y=xy[:,0],xy[:,1]
        aperture=smooth((x-(LIP_X[0]-.08))/.08)*smooth(((LIP_X[1]+.08)-x)/.08)
        approach=smooth((y+.02)/.22)
        depth_eff=eta-CREST*smooth((y-.15)/(.245-.15))
        # Q/(width*depth) at the wet sill; approach depth includes the bed rise.
        lateral=q/(B*np.maximum(depth_eff,.001))*aperture*approach
        if take=='A_no_outward':
            base_depth=ETA0-CREST*smooth((y-.15)/(.245-.15))
            lateral=SPILL0/(B*base_depth)*aperture*approach
        outside=smooth((y-LIP_Y)/.12)
        ux=(.02+.20*(eta-ETA0))*(1-.78*outside)
        # A spreading shallow sheet on the open receiving terrace.
        uy=lateral*(1-.6*outside)
        depth=depth_eff
        return depth,np.c_[ux,uy]
    def surface_z(self,take,t,xy):
        xy=np.atleast_2d(xy);eta=self.levels(take,t)[3]
        return eta-ETA0-.055*smooth((xy[:,1]-LIP_Y)/.20)

def pole_y(t,entry_y):
    return entry_y-WIDTH/2+STROKE*smooth((t-START)/(END-START))

def pole_force(t,state,entry_y):
    if t<START or t>RETRACT:return 0.
    gap=state[1]-WIDTH/2-pole_y(t,entry_y)
    return STIFFNESS*max(-gap,0.)

def boat_solve(water,take,dt):
    ts=water.data['t'];s=INITIAL.copy();rows=[s.copy()];entry_y=None
    def rhs(t,s):
        _,u=water.sample(take,t,s[None,:2]);f=DRAG*(u[0]-s[3:5])
        if take=='B' and entry_y is not None:f+=np.array([0.,pole_force(t,s,entry_y)])
        # Symmetric central drag + a side-midpoint normal push: zero yaw torque.
        return np.r_[s[3:5],s[5],f/MASS,-2*s[5]]
    for t in ts[:-1]:
        if entry_y is None and t>=START-1e-9:entry_y=s[1]
        s=rk4(rhs,t,s,dt);rows.append(s.copy())
    return np.c_[ts,np.array(rows)]

def run(dt=1/240,save=True):
    ts,base=water_solve(False,dt);_,a=water_solve(True,dt)
    wd={'t':ts,'baseline':base,'A':a}
    if save:np.savez_compressed(ROOT/'water.npz',**wd)
    w=Water.__new__(Water);w.data=wd
    boats={k:boat_solve(w,k,dt) for k in ('baseline','A','B','A_no_outward','B_no_pole')}
    info={}
    for k,b in boats.items():
        full=(b[:,2]-WIDTH/2>LIP_Y)&(b[:,1]-L/2>=LIP_X[0])&(b[:,1]+L/2<=LIP_X[1])
        received=(b[:,1]>=.49)&(b[:,1]<=.66)&(b[:,2]>=.32)&(b[:,2]<=.52)
        crossing=(b[:,2]+WIDTH/2>=LIP_Y)&(b[:,2]-WIDTH/2<=LIP_Y)
        clear=bool(np.all((b[crossing,1]-L/2>=LIP_X[0])&(b[crossing,1]+L/2<=LIP_X[1])))
        levels=np.array([w.levels(k,t)[3] for t in b[crossing,0]])
        info[k]={'exit':bool(full.any() and received.any() and clear),'reaches_shared_apron':bool(received.any()),'full_exit_time_s':float(b[full,0][0]) if full.any() else None,
            'end_xy_m':b[-1,1:3].tolist(),'max_y_m':float(b[:,2].max()),
            'opening_width_clearance':clear,'min_water_over_lip_m':float((levels-CREST).min()) if len(levels) else None,
            'conservative_crest_depth_m':float(2*(levels-CREST).min()/3) if len(levels) else None}
    residual={}
    for k,arr in [('baseline',base),('A',a)]:
        vol=np.sum((arr[:,:4]-ETA0)*AREAS,axis=1)
        residual[k]=float(np.max(np.abs(vol-(arr[:,4]-arr[:,5]-arr[:,6]))))
    metrics={'model':'4-reach storage + overflow rating + declared local velocity closure + planar rigid boat',
        'dt_s':dt,'boat_length_m':L,'boat_width_m':WIDTH,'boat_draft_m':DRAFT,'lip_y_m':LIP_Y,'lip_x_m':LIP_X,
        'same_outcome_not_same_path':True,'cases':info,'volume_balance_max_error_m3':residual,
        'baseline_spill_litre_per_s':SPILL0*1000,'peak_A_spill_litre_per_s':C*B*(a[-1,3]-CREST)**1.5*1000,
        'pole_stroke_m':STROKE,'pole_stiffness_N_per_m':STIFFNESS,'pole_command_s':[START,END],
        'scope':'Volume balance verified. Local velocity closure and decorative ripples are illustrative, not a solved 2D momentum field.'}
    if save:
        np.savez_compressed(ROOT/'boat_states.npz',**boats)
        (ROOT/'dynamics-metrics.json').write_text(json.dumps(metrics,indent=2))
        print(json.dumps(metrics,indent=2))
    return boats,metrics

if __name__=='__main__':run()
