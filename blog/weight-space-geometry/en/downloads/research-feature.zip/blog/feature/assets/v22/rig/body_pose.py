"""Small, deterministic torso controller for the painted right-hand actor.

The controller owns only the rigid torso/pelvis motion.  Arm lengths are
treated as design constraints so callers can pass the returned transform to
the mesh IK without silently asking for an impossible hand pose.
"""

from __future__ import annotations

import math
from typing import Mapping, Sequence


_SHOULDERS = {
    "front": (1320.0, 423.0),
    "back": (1400.0, 411.0),
}
_ELBOWS = {
    "front": (1298.0, 482.0),
    "back": (1390.0, 455.0),
}
_HANDS = {
    "front": (1281.0, 521.0),
    "back": (1330.0, 460.0),
}
_PIVOT = (1410.0, 580.0)


def _finite(value: object, default: float = 0.0) -> float:
    try:
        value = float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return default
    return value if math.isfinite(value) else default


def _clamp(value: object, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, _finite(value)))


def _point(value: object, fallback: Sequence[float]) -> list[float]:
    try:
        x, y = value  # type: ignore[misc]
        x, y = _finite(x, fallback[0]), _finite(y, fallback[1])
        return [x, y]
    except (TypeError, ValueError):
        return [float(fallback[0]), float(fallback[1])]


def _norm(x: float, y: float) -> float:
    return math.hypot(x, y)


def _rotate(point: Sequence[float], pivot: Sequence[float], angle: float) -> list[float]:
    x, y = point[0] - pivot[0], point[1] - pivot[1]
    c, s = math.cos(angle), math.sin(angle)
    return [pivot[0] + c * x - s * y, pivot[1] + s * x + c * y]


def solve_body(hands: Mapping[str, Sequence[float]] | None = None,
               cue: Mapping[str, float] | None = None) -> dict:
    """Return one rigid torso transform and diagnostics for the two arm chains.

    ``hands`` uses the mesh names ``hand_front`` and ``hand_back``.  Missing or
    non-finite values mean the painted source hand.  ``cue`` values are all
    normalized to ``[0, 1]``; malformed values safely produce a rest pose.
    """
    hands = hands or {}
    cue = cue or {}
    plant = _clamp(cue.get("plant", 0.0))
    drive = _clamp(cue.get("drive", 0.0))
    load = _clamp(cue.get("load", 0.0))
    release = _clamp(cue.get("release", 0.0))

    targets = {
        side: _point(hands.get("hand_" + side), _HANDS[side])
        for side in ("front", "back")
    }
    # Screen coordinates have y down; this negative angle leans toward the
    # boat (left/down) while release gently returns the lean to neutral.
    angle = (-math.radians(2.0) * plant
             - math.radians(10.0) * drive
             - math.radians(1.0) * load) * (1.0 - 0.35 * release)
    angle = max(-math.radians(18.0), min(math.radians(18.0), angle))
    pivot = list(_PIVOT)
    rotated = {side: _rotate(_SHOULDERS[side], pivot, angle)
               for side in ("front", "back")}
    translation = [-3.0 * drive, 12.0 * drive + 2.0 * plant]

    # Each arm constrains the transformed shoulder to an annulus around its
    # target hand. Alternating projections gives one shared translation, so
    # the shoulders can never receive independent corrective offsets.
    limits = {}
    for side in ("front", "back"):
        l1 = _norm(_ELBOWS[side][0] - _SHOULDERS[side][0],
                   _ELBOWS[side][1] - _SHOULDERS[side][1])
        l2 = _norm(_HANDS[side][0] - _ELBOWS[side][0],
                   _HANDS[side][1] - _ELBOWS[side][1])
        limits[side] = (abs(l1 - l2), 0.98 * (l1 + l2), l1, l2)

    residual_before = {}
    for side in ("front", "back"):
        dx, dy = targets[side][0] - rotated[side][0] - translation[0], targets[side][1] - rotated[side][1] - translation[1]
        residual_before[side] = _norm(dx, dy)

    for _ in range(20):
        for side in ("front", "back"):
            lo, hi, _, _ = limits[side]
            dx = targets[side][0] - (rotated[side][0] + translation[0])
            dy = targets[side][1] - (rotated[side][1] + translation[1])
            distance = _norm(dx, dy)
            if distance < lo or distance > hi:
                if distance < 1e-9:
                    dx, dy, distance = 1.0, 0.0, 1.0
                desired = lo if distance < lo else hi
                # Move the common shoulder translation toward/away from the
                # hand until this chain is on the valid reach boundary.
                translation[0] += dx * (1.0 - desired / distance)
                translation[1] += dy * (1.0 - desired / distance)
        magnitude = _norm(*translation)
        if magnitude > 40.0:
            translation[:] = [v * 40.0 / magnitude for v in translation]

    distances = {}
    ratios = {}
    violations = []
    shoulders = {}
    for side in ("front", "back"):
        shoulders[side] = [rotated[side][0] + translation[0],
                           rotated[side][1] + translation[1]]
        dx = targets[side][0] - shoulders[side][0]
        dy = targets[side][1] - shoulders[side][1]
        distance = _norm(dx, dy)
        lo, hi, l1, l2 = limits[side]
        distances[side] = distance
        ratios[side] = distance / (l1 + l2)
        if distance < lo - 1e-5:
            violations.append(side + ":below_min")
        if distance > hi + 1e-5:
            violations.append(side + ":above_max")

    max_ratio = max(ratios.values())
    return {
        "rotation": [[math.cos(angle), -math.sin(angle)],
                     [math.sin(angle), math.cos(angle)]],
        "translation": [float(translation[0]), float(translation[1])],
        "pivot": pivot,
        "shoulders": shoulders,
        "torso_angle_rad": float(angle),
        "knee_flex_px": float(4.0 * drive + 2.0 * plant + 3.0 * load),
        "max_reach_ratio": float(max_ratio),
        "hands": targets,
        "diagnostics": {
            "cue": {"plant": plant, "drive": drive, "load": load, "release": release},
            "reach_px": distances,
            "reach_limits_px": {side: [v[0], v[1]] for side, v in limits.items()},
            "reach_ratios": ratios,
            "initial_reach_px": residual_before,
            "constraint_violations": violations,
            "rigid_shoulders": True,
            "finite": all(math.isfinite(v) for v in translation + [angle, max_ratio]),
        },
    }


if __name__ == "__main__":  # focused numerical sanity check
    pose = solve_body({"hand_front": _HANDS["front"], "hand_back": _HANDS["back"]},
                      {"plant": 1, "drive": 1, "load": 1, "release": 0})
    assert pose["diagnostics"]["finite"]
    assert pose["max_reach_ratio"] <= 0.98 + 1e-6
    assert not pose["diagnostics"]["constraint_violations"]
    print(pose["translation"], pose["torso_angle_rad"], pose["max_reach_ratio"])
