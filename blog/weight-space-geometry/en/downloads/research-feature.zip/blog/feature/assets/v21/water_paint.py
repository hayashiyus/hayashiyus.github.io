"""Art-directed water paint pass over the preserved v12 water plate.

The local velocities come from the declared reduced overflow model.  The small
continuous flow-map displacement, plate sampling, and normal shading below are
artistic advection, not additional fluid equations.  Both source and
destination pixels are checked against the renderer's RIVER mask; invalid
backtraces retain the original painted-water destination pixel.
"""
from __future__ import annotations

import cv2
import numpy as np


def paint_water(renderer, take, t):
    """Return an RGB frame with only the masked painted-water pixels changed."""
    out = renderer.base.copy()
    yy, xx = renderer.yy, renderer.xx
    dst_ok = renderer.watermask[yy, xx] > 2
    texture = renderer.texture
    n = len(xx)
    uv = np.zeros((n, 2), dtype=float)
    height = np.zeros(n, dtype=float)
    loc = renderer.local
    if np.any(loc):
        h, vel = renderer.motion.water.sample("gate" if take == "A" else "baseline",
                                              max(0.0, float(t)), renderer.localxy[loc])
        uv[loc] = vel
        height[loc] = h - 0.02
    # Advection uses the same SI-to-camera map as the boat in the resolved
    # reach. Upstream tangential speed is illustrative, not a solved flow.
    levels=renderer.motion.water.levels(take,max(0,float(t)))
    idx=np.minimum(3,(renderer.arc/230).astype(int))
    flow_px=renderer.tan*(21.25*(1+18*(levels[idx]-.02)))[:,None]
    flow_px[loc]=np.c_[850*uv[loc,0]-400*uv[loc,1],150*uv[loc,0]+240*uv[loc,1]]
    # Existing route tangent and cross-stream normal supply a smooth, continuous
    # artistic wave field, instead of segmented strips or rectangular seams.
    wave = (0.35 * np.sin(renderer.arc * .061 - float(t) * 13.0)
            + 0.18 * np.sin(renderer.arc * .119 + renderer.cross * .08 - float(t) * 21.0))
    # Height produces a subtle surface-normal luminance modulation, not geometry.
    shade = 1.0 + np.clip(0.12 * (height / 0.02), -0.08, 0.12)
    samples=[];weights=[]
    for offset in (0.,.5):
        phase=(float(t)/1.2+offset)%1.;age=phase*1.2
        src_x=xx-flow_px[:,0]*age-renderer.normal[:,0]*wave
        src_y=yy-flow_px[:,1]*age-renderer.normal[:,1]*wave
        sx=np.rint(src_x).astype(int);sy=np.rint(src_y).astype(int)
        in_bounds=(sx>=0)&(sx<texture.shape[1])&(sy>=0)&(sy<texture.shape[0])
        src_ok=np.zeros(n,dtype=bool)
        src_ok[in_bounds]=renderer.watermask[sy[in_bounds],sx[in_bounds]]>240
        valid=dst_ok&src_ok
        sampled=texture[yy,xx].astype(float).copy()
        vi=np.flatnonzero(valid)
        for start in range(0,len(vi),4096):
            chunk=vi[start:start+4096]
            moved=cv2.remap(texture,src_x[chunk].astype(np.float32).reshape(1,-1),
                           src_y[chunk].astype(np.float32).reshape(1,-1),
                           cv2.INTER_LINEAR,borderMode=cv2.BORDER_REPLICATE).reshape(-1,3)
            # Color guard prevents any warm wooden bank from entering water.
            safe=moved[:,2].astype(float)>=moved[:,0].astype(float)-1
            sampled[chunk[safe]]=moved[safe]
        samples.append(sampled);weights.append(1-abs(2*phase-1))
    sampled=(samples[0]*weights[0]+samples[1]*weights[1])/sum(weights)
    normal_light=1+.014*np.sin(renderer.arc*.071+renderer.cross*.13-float(t)*12.8)
    sampled*= (shade*normal_light)[:,None]
    alpha=renderer.wateralpha
    out[yy,xx]=np.clip(out[yy,xx]*(1-alpha)+sampled*alpha,0,255).astype(np.uint8)
    return out

