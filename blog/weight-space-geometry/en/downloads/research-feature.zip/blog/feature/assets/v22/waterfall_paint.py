"""One curvilinear watercolor pass from the main reach over its lip to the pool.

The atlas transports the existing painted pigment through a continuous bend.
It replaces the painted water inside the fall, rather than layering a second
waterfall on it. This is an optical animation, not a resolved 3-D fluid solve.
"""
from __future__ import annotations
import cv2
import numpy as np
from scipy.interpolate import PchipInterpolator
from surface_raster import raster


def _smoothstep(edge0, edge1, value):
    # Support both rising and descending soft edges with their original sign.
    delta=np.asarray(edge1,dtype=float)-np.asarray(edge0,dtype=float)
    delta=np.where(abs(delta)<1e-8,np.where(delta<0,-1e-8,1e-8),delta)
    x=np.clip((value-edge0)/delta,0.,1.)
    return x*x*(3.-2.*x)


class MainFall:
    """Fixed camera-space atlas; original wood, rocks and silhouettes stay still."""
    def __init__(self, texture):
        self.texture=np.asarray(texture)
        if self.texture.shape!=(1024,1536,3):
            raise ValueError('MainFall expects the 1536x1024 production plate')
        self.roi=(1150,645,1536,960)
        x0,y0,x1,y1=self.roi;w,h=x1-x0,y1-y0
        yy,xx=np.mgrid[y0:y1,x0:x1].astype(np.float32)
        self.xx,self.yy=xx,yy
        # Corresponding front/back water edges: straight reach -> round lip ->
        # falling sheet -> impact. Never sample the wooden walls beside it.
        front=np.array([(1135,689),(1210,712),(1260,724),(1297,734),
                        (1317,744),(1324,758),(1326,790),(1327,817),(1336,841)],float)
        back=np.array([(1135,655),(1210,674),(1264,686),(1310,698),
                       (1365,710),(1404,715),(1410,759),(1417,804),(1424,836)],float)
        middle=(front+back)*.5
        distance=np.r_[0,np.cumsum(np.linalg.norm(np.diff(middle,axis=0),axis=1))]
        self.front=PchipInterpolator(distance,front,axis=0)
        self.back=PchipInterpolator(distance,back,axis=0)
        ds=np.linspace(0,distance[-1],420)
        center=(self.front(ds)+self.back(ds))*.5
        # Optical speed rises smoothly after the lip. The timing is an art
        # mapping driven by nonnegative outlet flux, not another fluid solver.
        speed=46.+120.*_smoothstep(725.,815.,center[:,1])
        travel=np.r_[0,np.cumsum(np.diff(ds)*.5*(1/speed[:-1]+1/speed[1:]))]
        self.travel=travel;self.distance=ds
        q=np.linspace(0,1,90)
        mesh=self.front(ds)[:,None,:]*(1-q[None,:,None])+self.back(ds)[:,None,:]*q[None,:,None]
        T,Q=np.meshgrid(travel,q,indexing='ij')
        atlas=raster(mesh-[x0,y0],np.broadcast_to(ds[:,None],T.shape),
                     np.dstack((T,Q,np.zeros_like(T),np.ones_like(T))).astype(np.float32),w,h)
        self.T,self.Q=atlas[...,0],atlas[...,1]
        footprint=(atlas[...,3]>.99).astype(np.uint8)
        inner=cv2.distanceTransform(footprint,cv2.DIST_L2,3)
        self.ribbon_alpha=np.clip(inner/1.3,0,1)*_smoothstep(1200.,1270.,xx)
        rgb=self.texture[y0:y1,x0:x1].astype(float)
        # Keep the wooden silhouette stationary at the soft painted edge.
        pigment_guard=_smoothstep(-4.,3.,rgb[...,2]-rgb[...,0])
        # The guard belongs only to the silhouette. Warm paper-white pigment
        # in the middle of the water must not become static holes in the flow.
        pigment_guard=1-(1-pigment_guard)*(1-_smoothstep(1.,4.,inner))
        self.ribbon_alpha*=pigment_guard
        self.low=cv2.GaussianBlur(self.texture.astype(np.float32),(0,0),9)
        self.local_low=self.low[y0:y1,x0:x1]
        # The receiving pool has its own actual painted shoreline. This mask
        # does not include the wooden walls or the side spillway.
        boundary=np.array([(1333,814),(1377,814),(1410,808),(1437,818),
                           (1477,843),(1515,860),(1535,879),(1535,923),
                           (1491,927),(1440,923),(1370,908),(1315,883),
                           (1284,858),(1302,834)],np.int32)-[x0,y0]
        mask=np.zeros((h,w),np.uint8);cv2.fillPoly(mask,[boundary],1)
        pd=cv2.distanceTransform(mask,cv2.DIST_L2,3)
        self.pool_alpha=np.clip(pd/7.,0,1)*_smoothstep(811.,833.,yy)
        # A foreground wood/stone island at the left edge is explicitly dry.
        self.pool_alpha*= _smoothstep(1289.,1320.,xx)
        self.pool_source_mask=(self.pool_alpha>.08).astype(np.float32)
        self.source=self.texture[y0:y1,x0:x1].astype(np.float32)

    def _ribbon_sample(self,clock):
        samples=[];weights=[]
        period=.92
        for offset in (0.,.5):
            phase=(clock/period+offset)%1.
            age=phase*period
            # Backtrace in continuous travel time, across the bend itself.
            tt=np.maximum(self.T-age,0.)
            dd=np.interp(tt,self.travel,self.distance)
            q=self.Q+.0035*np.sin(self.T*7.+self.Q*23.-clock*8.)
            q=np.clip(q,.007,.993)
            pos=self.front(dd)*(1-q[...,None])+self.back(dd)*q[...,None]
            moved=cv2.remap(self.texture,pos[...,0].astype(np.float32),
                            pos[...,1].astype(np.float32),cv2.INTER_LINEAR,
                            borderMode=cv2.BORDER_REPLICATE).astype(np.float32)
            # Broad illumination belongs to the lip/curtain geometry; moving
            # pigment supplies the detail. Avoid a bright crest-sized band
            # travelling down the sheet like a pasted strip.
            moved_low=cv2.remap(self.low,pos[...,0].astype(np.float32),
                               pos[...,1].astype(np.float32),cv2.INTER_LINEAR,
                               borderMode=cv2.BORDER_REPLICATE)
            moved=moved*.55+(self.local_low+moved-moved_low)*.45
            samples.append(np.clip(moved,0,255));weights.append(1-abs(2*phase-1))
        return (samples[0]*weights[0]+samples[1]*weights[1])/sum(weights)

    def _pool_sample(self,clock):
        x0,y0,_,_=self.roi
        dx=self.xx-1381.;dy=(self.yy-830.)*1.65
        length=np.maximum(np.hypot(dx,dy),8.)
        nx=dx/length;ny=dy/length/1.65
        samples=[];weights=[]
        for offset in (0.,.5):
            phase=(clock/.8+offset)%1.;age=phase*.8
            # Flow fans away from the same impact, progressively slowing.
            speed=35.*np.exp(-length/240.)
            sx=self.xx-nx*age*speed;sy=self.yy-ny*age*speed
            moved=cv2.remap(self.texture,sx.astype(np.float32),sy.astype(np.float32),
                           cv2.INTER_LINEAR,borderMode=cv2.BORDER_REPLICATE).astype(np.float32)
            ok=cv2.remap(self.pool_source_mask,(sx-x0).astype(np.float32),(sy-y0).astype(np.float32),
                         cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT)
            # Near the dry shoreline fade back inside the original water; no
            # rock/wood pigment is pulled into the receiving pool.
            moved=self.source*(1-ok[...,None])+moved*ok[...,None]
            samples.append(moved);weights.append(1-abs(2*phase-1))
        return (samples[0]*weights[0]+samples[1]*weights[1])/sum(weights)

    def draw(self,im,clock):
        out=im.copy();x0,y0,x1,y1=self.roi
        dst=out[y0:y1,x0:x1].astype(np.float32)
        # Pool first, then the continuous sheet through its soft impact edge.
        a=self.pool_alpha[...,None]
        dst=dst*(1-a)+self._pool_sample(clock)*a
        a=self.ribbon_alpha[...,None]*_smoothstep(844.,831.,self.yy)[...,None]
        dst=dst*(1-a)+self._ribbon_sample(clock)*a
        out[y0:y1,x0:x1]=np.clip(dst,0,255).astype(np.uint8)
        return out


__all__=['MainFall']
