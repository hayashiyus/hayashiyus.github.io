"""Forward-rendered SWE free surface with painterly, advected optical detail."""
import numpy as np,cv2
from PIL import Image,ImageDraw
from motion import M,ORIGIN,smooth,project
from hydro_surface import Hydro,mix_sample
from surface_raster import raster
from rig.mesh import SRC

class Spill:
 def __init__(self,texture):
  self.hydro=Hydro();self.hydro.build_optics();hy=self.hydro
  self.roi=(850,595,1505,1008);x0,y0,x1,y1=self.roi;self.size=(x1-x0,y1-y0)
  self.xy=np.stack((hy.xx,hy.yy),axis=-1)
  self.fine_size=(len(hy.x)*3,len(hy.y)*3)
  self.fine_xy=cv2.resize(self.xy,self.fine_size,interpolation=cv2.INTER_LINEAR)
  self.fine_bed=cv2.resize(hy.bed,self.fine_size,interpolation=cv2.INTER_LINEAR)
  self.fine_fade=None
  self.fade=smooth((hy.xx-hy.x[0])/.012)*smooth((hy.x[-1]-hy.xx)/.012)
  self.fade*=smooth((hy.yy-.145)/.06)
  self.fine_fade=cv2.resize(self.fade,self.fine_size,interpolation=cv2.INTER_LINEAR)
  pos=project(self.xy,hy.bed-.020)-[x0,y0]
  # The visible wood is the numerical bed, including the high shoulders and
  # open slope. No high retaining rim is omitted from the painting.
  gray=cv2.cvtColor(SRC,cv2.COLOR_RGB2GRAY).astype(np.float32)
  detail=gray-cv2.GaussianBlur(gray,(0,0),7)
  d=cv2.remap(detail,(pos[...,0]+x0).astype(np.float32),(pos[...,1]+y0).astype(np.float32),cv2.INTER_LINEAR)
  zy,zx=np.gradient(hy.bed,hy.dy,hy.dx)
  slope_shade=np.clip(-zx*.11+zy*.10,-.18,.07)
  grain=np.sin(hy.xx*1250+2*np.sin(hy.yy*31))+ .35*np.sin(hy.xx*2270+hy.yy*18)
  seams=np.exp(-(np.sin((hy.xx-.40)*np.pi/.055)/.035)**2)
  color=(np.array([243.,239.,229.])+d[...,None]*.34+grain[...,None]*1.4-seams[...,None]*np.array([18.,17.,15.]))*(1+slope_shade[...,None])
  color=np.clip(color,0,255)
  mask=smooth((hy.yy-.177)/.036)*self.fade
  order=.39*hy.xx+.82*hy.yy+.39*hy.bed
  self.ground=raster(pos,order,np.dstack((color,mask)).astype(np.float32),*self.size)
  self.ground=self.soften(self.ground,.65)
  rng=np.random.default_rng(1901);n=rng.normal(0,1,(y1-y0,x1-x0)).astype(np.float32)
  self.grain=cv2.GaussianBlur(n,(0,0),.65)*1.0+cv2.GaussianBlur(n,(0,0),6)*5
  # Reuse only brush/pigment frequencies from the original clean water plate.
  # This does not replace the simulated height, shoreline or flow field.
  patch=texture[640:673,1040:1215].astype(np.float32)
  lum=cv2.cvtColor(patch,cv2.COLOR_RGB2GRAY)
  self.brush_patch=(lum-cv2.GaussianBlur(lum,(0,0),5))/32
  self.wash_patch=cv2.GaussianBlur(lum,(0,0),3)
  self.wash_patch=(self.wash_patch-self.wash_patch.mean())/max(1,self.wash_patch.std())

 @staticmethod
 def soften(layer,sigma):
  a=layer[...,3];rgb=layer[...,:3]*a[...,None]
  a=cv2.GaussianBlur(a,(0,0),sigma);rgb=cv2.GaussianBlur(rgb,(0,0),sigma)
  return np.dstack((np.divide(rgb,a[...,None],out=np.zeros_like(rgb),where=a[...,None]>1e-6),a))

 def wake(self,im,motion,take,t):
  if t<0:return im
  out=Image.fromarray(im);d=ImageDraw.Draw(out,'RGBA')
  for side in [-1,1]:
   pts=[]
   for age in np.linspace(.05,.65,12):
    st=motion.boat(take,max(0,t-age));vel=st[3:5];speed=np.linalg.norm(vel)
    if speed<.005:continue
    normal=np.array([-vel[1],vel[0]])/speed
    xy=st[:2]+side*normal*(.019+.019*age)
    depth,_,z=self.hydro.sample(take,t,xy[None])
    if depth[0]<.0008:continue
    pts.append(tuple(project(xy,z[0])))
   if len(pts)>1:d.line(pts,fill=(247,250,246,105),width=1)
  return np.asarray(out.convert('RGB'))

 def discharge(self,im,take,t):
  """Short visible free fall after the solved open deck boundary.

  Boundary depth and velocity fix the source. The continuing ballistic
  sheet is a visual extrapolation, not a 3-D free-surface simulation.
  """
  hy=self.hydro;h,u,v=hy.frame(take,t);x0,y0,x1,y1=self.roi
  age=np.linspace(0,.145,36);x=hy.x
  speed=np.maximum(v[-1],0);wet=smooth((h[-1]-.00008)/.0005)*smooth(speed/.035)
  X=x[None]+u[-1][None]*age[:,None]
  Y=hy.y[-1]+speed[None]*age[:,None]
  slope=(hy.bed[-1]-hy.bed[-2])/hy.dy
  Z=(hy.bed[-1]+h[-1]-.020)[None]+slope[None]*speed[None]*age[:,None]-.5*9.81*age[:,None]**2
  pos=project(np.stack((X,Y),-1),Z)-[x0,y0]
  streak=.5+.5*np.sin(x[None]*780+age[:,None]*90-float(t)*8)
  paper=np.maximum(streak-.58,0)*.7
  color=np.ones((*X.shape,3))*np.array([94.,153.,211.])
  color=color*(1-paper[...,None])+np.array([235.,244.,249.])*paper[...,None]
  alpha=wet[None]*(1-np.exp(-h[-1][None]*300))*(1-smooth((age[:,None]-.055)/.09))*.72
  rgba=np.dstack((color,np.broadcast_to(alpha,X.shape))).astype(np.float32)
  layer=raster(pos,.39*X+.82*Y+.39*Z,rgba,*self.size)
  layer=self.soften(layer,.65);out=im.copy();a=layer[...,3:]
  out[y0:y1,x0:x1]=np.uint8(np.clip(out[y0:y1,x0:x1]*(1-a)+layer[...,:3]*a,0,255))
  return out

 def deck_edge(self,im):
  """Visible thickness at the open whitewood apron end; not a retaining lip."""
  hy=self.hydro;out=Image.fromarray(im);d=ImageDraw.Draw(out,'RGBA')
  top=project(np.c_[hy.x,np.full_like(hy.x,hy.y[-1])],hy.bed[-1]-.020)
  bottom=top+[0,8]
  d.polygon([tuple(p)for p in np.vstack((top,bottom[::-1]))],fill=(226,223,211,245))
  d.line([tuple(p)for p in top],fill=(250,247,237,235),width=2)
  d.line([tuple(p)for p in bottom],fill=(164,162,154,65),width=1)
  for i in range(8,len(top)-3,11):d.line([tuple(top[i]),tuple(bottom[i])],fill=(147,147,140,60),width=1)
  return np.asarray(out.convert('RGB'))

 def draw(self,im,motion,take,t):
  hy=self.hydro
  h,u,v=[cv2.resize(a,self.fine_size,interpolation=cv2.INTER_LINEAR) for a in hy.frame(take,t)]
  eta=self.fine_bed+h
  x0,y0,x1,y1=self.roi;xy=self.fine_xy[...,0];yy=self.fine_xy[...,1]
  optical_t=t if t>=0 else t+2
  optical=[cv2.resize(a,self.fine_size,interpolation=cv2.INTER_LINEAR) for a in hy.optic_frame(take,optical_t)]
  weights=[];waves=[];streaks=[];brushes=[];pigments=[];washes=[]
  for k,offset in enumerate((0.,.5)):
   phase=(max(0,optical_t)/1.4+offset)%1;weights.append(1-abs(2*phase-1))
   a,b=optical[k*2:k*2+2]
   waves.append(np.sin(b*320+a*105)+.38*np.sin(b*570-a*150)+.17*np.sin(a*710+b*410))
   streaks.append(.65*np.sin(a*350+1.4*np.sin(b*72))+.24*np.sin(a*620-b*45))
   # Long broken pigment ridges are transported by the computed flow.
   # They are an optical layer, not a deformation of the solved surface.
   ridge=np.maximum(np.sin(a*470+3*np.sin(b*42+a*23)+1.8*np.sin(a*110+b*90)),0)**10
   broken=np.clip(.20+.5*np.sin(b*117+a*24)+.40*np.sin(b*289)+.3*np.sin(b*511+a*57),0,1)
   brushes.append(ridge*broken)
   tx=(b*960+8*np.sin(a*32+b*41)).astype(np.float32)
   ty=(a*820+5*np.sin(b*21+a*30)).astype(np.float32)
   pigments.append(cv2.remap(self.brush_patch,tx,ty,cv2.INTER_LINEAR,borderMode=cv2.BORDER_REFLECT_101))
   washes.append(cv2.remap(self.wash_patch,tx*.36,ty*.36,cv2.INTER_LINEAR,borderMode=cv2.BORDER_REFLECT_101))
  wave=(waves[0]*weights[0]+waves[1]*weights[1])/sum(weights)
  streak=(streaks[0]*weights[0]+streaks[1]*weights[1])/sum(weights)
  brush=(brushes[0]*weights[0]+brushes[1]*weights[1])/sum(weights)
  original_pigment=(pigments[0]*weights[0]+pigments[1]*weights[1])/sum(weights)
  wash=(washes[0]*weights[0]+washes[1]*weights[1])/sum(weights)
  dy,dx=np.gradient(eta,hy.dy/3,hy.dx/3);speed=np.hypot(u,v)
  absorption=1-np.exp(-h*130)
  # Brighter, more chromatic indigo-blue. The original muted navy made the
  # receiving pool read as a dark solid insert at article viewing size.
  water=np.array([45.,108.,183.])+wave[...,None]*np.array([3.,4.,5.])+streak[...,None]*np.array([1.,2.,3.])
  water+=original_pigment[...,None]*np.array([23.,27.,31.])+wash[...,None]*np.array([7.,9.,12.])
  substrate=np.array([150.,193.,228.])
  pigment=substrate*(1-absorption[...,None])+water*absorption[...,None]
  # Computed macroscopic normal, plus a small subgrid optical highlight layer.
  reflection=np.clip(.06-.13*dx+.10*dy+.025*np.maximum(wave-.4,0),.02,.22)
  pigment=pigment*(1-reflection[...,None])+np.array([223.,233.,245.])*reflection[...,None]
  foam=optical[4]
  sheen=np.clip((wave-.85)*.18,0,.20)*smooth(speed/.25)
  compression=np.maximum(-(np.gradient(u,hy.dx/3,axis=1)+np.gradient(v,hy.dy/3,axis=0)),0)
  # Irregular froth is concentrated at a computed hydraulic compression,
  # rather than painted uniformly across a fixed horizontal band.
  jump=np.clip(compression*.012,0,.35)*(.2+.8*brush)
  jump*=smooth((yy-.27)/.06)*smooth(h/.001)
  # Broken paper-white reserves follow the transported original brushwork;
  # these are pigment/optical marks, not additional simulated air or water.
  paper_reserve=smooth((original_pigment-.05)/1.6)*(.20+.18*smooth(wash+.5))
  air=np.clip(foam*(.12+.3*brush)+jump+sheen*.6+brush*.18+paper_reserve,0,.58)
  pigment=pigment*(1-air[...,None])+np.array([232.,241.,247.])*air[...,None]
  # A millimetre-thin film leaves the painted wood visible underneath.
  # Coverage follows the solved wet front; optical opacity follows depth.
  wet=smooth((h-.00008)/.00035)*self.fine_fade*(.28+.65*(1-np.exp(-h*170)))
  meniscus=np.exp(-((h-.0005)/.0003)**2)*.16
  pigment=pigment*(1-meniscus[...,None])+np.array([105.,164.,205.])*meniscus[...,None]
  pos=project(self.fine_xy,eta-.020)-[x0,y0];order=.39*xy+.82*yy+.39*eta
  layer=raster(pos,order,np.dstack((np.clip(pigment,0,255),wet)).astype(np.float32),*self.size)
  layer=self.soften(layer,.55)
  out=self.discharge(self.deck_edge(im),take,t);dst=out[y0:y1,x0:x1].astype(float)
  a=self.ground[...,3:];dst=dst*(1-a)+self.ground[...,:3]*a
  a=layer[...,3:];color=layer[...,:3]+self.grain[...,None]*1.35
  dst=dst*(1-a)+color*a
  out[y0:y1,x0:x1]=np.uint8(np.clip(dst,0,255))
  return out
