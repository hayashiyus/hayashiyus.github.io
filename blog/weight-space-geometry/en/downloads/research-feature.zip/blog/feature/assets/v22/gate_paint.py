"""Optical water pass for the V22 gate.

This module deliberately owns water only. The renderer owns the fixed rails
and the translated rigid leaf/stem/handle and should call this pass before
drawing that hardware. The paint is illustrative watercolor optics, not a
resolved gate CFD result.
"""
from __future__ import annotations

import cv2
import numpy as np

_CENTER = np.array(((262., 414.), (290., 404.), (319., 394.), (350., 382.),
                    (395., 381.), (440., 384.), (495., 408.)), dtype=np.float32)
_APERTURE = _CENTER[:2]


def _line_mask(shape, points, width, blur=1.1):
    mask = np.zeros(shape, dtype=np.uint8)
    cv2.polylines(mask, [np.rint(points).astype(np.int32)], False,
                  255, max(1, int(round(width))), lineType=cv2.LINE_AA)
    if blur:
        k = max(3, int(round(blur * 6)) | 1)
        mask = cv2.GaussianBlur(mask, (k, k), blur)
    return mask.astype(np.float32) / 255.


def _composite(im, paint, alpha):
    a = np.clip(alpha, 0., 1.)[..., None]
    return np.clip(im.astype(np.float32) * (1. - a) + paint.astype(np.float32) * a,
                   0, 255).astype(np.uint8)


def paint_gate_water(im: np.ndarray, texture: np.ndarray, lift: float, t: float,
                     command: float = 0.) -> np.ndarray:
    """Paint only the under-leaf current; never redraw or move gate hardware.

    ``lift`` slightly raises the visible aperture. ``command`` in ``[0, 1]``
    changes opacity and streak density while preserving the same channel.
    """
    if im.ndim != 3 or im.shape[2] != 3 or im.dtype != np.uint8:
        raise ValueError("im must be an HxWx3 uint8 RGB array")
    if texture.shape != im.shape or texture.dtype != np.uint8:
        raise ValueError("texture must match im as an HxWx3 uint8 RGB array")
    h, w = im.shape[:2]
    q = float(np.clip(command, 0., 1.))
    lift = float(np.clip(lift, 0., 18.))

    # Narrow channel from the actual sill to the existing river band. It bends
    # slightly upward/right and does not paint the dry front bank.
    center = _CENTER.copy()
    center[:3, 1] -= .35 * lift * np.linspace(0., 1., 3)
    alpha = _line_mask((h, w), center, 9. + 2.5 * q, 1.)
    # Continue the original upper cascade at normal level, using only its local
    # channel, x=327..356; there is no invented source on the right.
    cascade = _line_mask((h, w), np.array(((327., 380.), (356., 381.))), 11., 1.)
    alpha = np.maximum(alpha, cascade * (.52 + .18 * q))

    yy, xx = np.mgrid[:h, :w]
    phase = float(t) * (2.8 + 1.7 * q)
    sx = (xx.astype(np.float32) - 1.8 * np.sin(phase + yy * .018)).astype(np.float32)
    sy = (yy.astype(np.float32) - .8 * np.cos(phase + xx * .013)).astype(np.float32)
    paint = cv2.remap(texture, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    paint = np.clip(paint.astype(np.float32) * np.array((.82, .98, 1.12), dtype=np.float32),
                    0, 255).astype(np.uint8)
    mod = .86 + .10 * np.sin(xx * .091 - yy * .037 - phase)
    out = _composite(im, paint, alpha * mod * (.36 + .16 * q))

    # Dark-blue thin sill line begins exactly at the basal aperture.
    aperture = _line_mask((h, w), _APERTURE, 4.2 + 1.5 * q, .65) * (.48 + .18 * q)
    dark = np.zeros_like(out)
    dark[..., 0], dark[..., 1], dark[..., 2] = 30, 88, 139
    out = _composite(out, dark, aperture)

    # Broken narrow white highlights. Every segment starts on the aperture and
    # follows the same positive-x, slightly-upward channel direction.
    edge = np.linspace(np.array((264., 413.)), np.array((316., 395.)), 8)
    white = np.full_like(out, (244, 249, 247))
    for i, start in enumerate(edge[::2]):
        p0 = start.copy()
        p1 = np.array((p0[0] + 19. + 4. * q,
                       p0[1] - 6. + 1.3 * np.sin(phase + i)), dtype=np.float32)
        p2 = np.array((p1[0] + 19., p1[1] - 1.5 + 1.1 * np.sin(phase * .8 + i)), dtype=np.float32)
        out = _composite(out, white,
                         _line_mask((h, w), np.vstack((p0, p1, p2)), 1.5 + .6 * q, .7)
                         * (.42 + .18 * q))
    for i, (x0, y0) in enumerate(((345, 381), (375, 380), (408, 382), (445, 388))):
        p = np.array(((x0, y0), (x0 + 13. + 3. * q,
                                  y0 + 1.5 * np.sin(phase + i))), dtype=np.float32)
        out = _composite(out, white, _line_mask((h, w), p, 1.4, .7) * (.26 + .12 * q))
    return out


paint_gate = paint_gate_water
__all__ = ["paint_gate_water", "paint_gate"]
