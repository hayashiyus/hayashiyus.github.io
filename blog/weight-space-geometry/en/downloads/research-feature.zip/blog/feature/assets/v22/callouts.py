"""Quiet, scene-registered editorial annotations; no motion-model changes.

Text settles first, then a dotted leader draws out, then an open target ring.
All times are scene-local. Leaders use live geometry, not guessed keyframes.
"""
from functools import lru_cache
import math
import numpy as np
from PIL import Image, ImageDraw, ImageFont

SIZE=(1536,1024)
SERIF='/System/Library/Fonts/Supplemental/Georgia.ttf'
SANS='/System/Library/Fonts/Helvetica.ttc'
INK=(48,64,81)
SLATE=(100,127,144)
BLUE=(70,132,170)
GOLD=(162,130,75)
SCALE=2

def ease(x):
    x=float(np.clip(x,0,1))
    return x*x*(3-2*x)

@lru_cache(maxsize=8)
def font(path,size):
    return ImageFont.truetype(path,size*SCALE)

def annotation_specs(take,t,g,done=False):
    """Plain records also serve as inspectable timing/registration evidence."""
    boat=np.asarray(g['boat_px'],float)
    common=dict(radius=(30,22))
    if take=='baseline':
        return [dict(id='baseline',start=.25,end=10.49,box=(944,421,292),
            title='Follow the current.',subtitle='No intervention.',color=SLATE,
            target=boat,anchor_x=1005,control=(963,584),
            note='Main channel · recorded exit' if done else '',**common)]
    if take=='A':
        return [
            dict(id='gate',start=.04,end=1.94,box=(430,118,284),
                title='Change the flow.',subtitle='Weight edit',color=BLUE,
                target=np.array([289.,377.-g['gate_lift_px']*.5]),
                anchor_x=445,control=(355,252),radius=(32,39),note=''),
            dict(id='carried',start=1.12,end=3.,box=(900,418,336),
                title='Carried by the current.',subtitle='Into the side opening.',color=BLUE,
                target=boat,anchor_x=1000,control=(1008,605),
                note='Side exit · frame held' if done else '',**common)]
    if take=='B':
        # The contact halo appears only when the pole actually touches the hull.
        contact=bool(g['contact'] and g['contact']['active'])
        released=t>5.6
        return [dict(id='push',start=3.0,end=7.,box=(945,415,291),
            title='Push the boat.',subtitle='Activation steering',color=GOLD,
            target=(1-ease((t-5.6)/.30))*np.asarray(g['tip_px'])+ease((t-5.6)/.30)*boat,
            anchor_x=1040,control=(1050,601),
            radius=tuple(np.array([19.,19.])+ease((t-5.6)/.30)*np.array([11.,3.])),
            marker_visible=contact or released,marker_opacity=ease((t-4.4)/.20),leader_delay=.58,
            note='Side exit · frame held' if done else '')]
    if take=='summary':
        return [dict(id='comparison',start=0.,end=2.,box=(897,410,340),
            title='The same side exit.',subtitle='Different actions and paths.',color=SLATE,
            target=np.array([1152.,772.]),anchor_x=1000,control=(1007,621),
            radius=(57,29),note='Recorded paths',leader_delay=.15)]
    return []

def _path_points(start,control,end,n=120):
    u=np.linspace(0,1,n)[:,None]
    return (1-u)**2*start+2*u*(1-u)*control+u*u*end

def _partial_dashes(draw,points,progress,color):
    """Fixed dash phase: reveal the line, never animate a marching-ants effect."""
    arc=np.r_[0,np.cumsum(np.linalg.norm(np.diff(points,axis=0),axis=1))]
    limit=arc[-1]*progress
    def at(s):
        return tuple(np.array([np.interp(s,arc,points[:,k]) for k in range(2)])*SCALE)
    for a in np.arange(0,limit,11.):
        b=min(a+4.8,limit)
        draw.line([at(a),at(b)],fill=color,width=4)

def draw_callouts(im,take,t,g,done=False):
    layer=Image.new('RGBA',(SIZE[0]*SCALE,SIZE[1]*SCALE))
    d=ImageDraw.Draw(layer)
    for s in annotation_specs(take,t,g,done):
        age=t-s['start'];remaining=s['end']-t
        opacity=ease(age/.34)*ease(remaining/.28)
        if opacity<=0:continue
        color=s['color'];dy=5*(1-ease(age/.40))
        x,y,w=s['box'];y+=dy;note=s.get('note','')
        note_mix=ease(g.get('held_for_s',1.)/.20) if note else 0.
        height=83+20*note_mix
        # A translucent paper wash, without a drop shadow or a speech-bubble tail.
        box=tuple(v*SCALE for v in (x,y,x+w,y+height))
        d.rounded_rectangle(box,radius=11*SCALE,fill=(253,252,250,round(224*opacity)),
                            outline=(*color,round(35*opacity)),width=1*SCALE)
        d.line([(x*SCALE,(y+19)*SCALE),(x*SCALE,(y+height-19)*SCALE)],
               fill=(*color,round(145*opacity)),width=2*SCALE)
        d.text(((x+17)*SCALE,(y+12)*SCALE),s['title'],font=font(SERIF,26),
               fill=(*INK,round(250*opacity)))
        d.text(((x+18)*SCALE,(y+49)*SCALE),s['subtitle'],font=font(SANS,18),
               fill=(99,112,125,round(242*opacity)))
        if note:
            d.text(((x+18)*SCALE,(y+77)*SCALE),note,font=font(SANS,13),
                   fill=(112,121,132,round(232*opacity*note_mix)))
        anchor=np.array([s['anchor_x'],y+height-3.])
        target=np.asarray(s['target'],float);control=np.asarray(s['control'],float)
        radius=np.array(s['radius'],float)
        vec=target-control;unit=vec/max(np.linalg.norm(vec),1e-6)
        border=1/math.sqrt(float(np.sum((unit/radius)**2)))
        end=target-unit*(border+7)
        delay=s.get('leader_delay',.20)
        progress=ease((age-delay)/.55)
        _partial_dashes(d,_path_points(anchor,control,end),progress,(*color,round(210*opacity)))
        if progress>.97:
            # Tiny open arrowhead stops outside the subject, never covers the grip.
            cross=np.array([-unit[1],unit[0]])
            pts=[end-unit*7+cross*3,end,end-unit*7-cross*3]
            d.line([tuple(p*SCALE) for p in pts],fill=(*color,round(210*opacity)),width=4)
        ring=ease((age-delay-.40)/.38)
        ring*=s.get('marker_opacity',1.)
        if not s.get('marker_visible',True):ring=0
        if ring>0:
            rect=tuple(np.r_[target-radius,target+radius]*SCALE)
            d.arc(rect,start=205,end=205+310*ring,fill=(*color,round(210*opacity)),width=4)
    layer=layer.resize(SIZE,Image.Resampling.LANCZOS)
    return np.asarray(Image.alpha_composite(Image.fromarray(im).convert('RGBA'),layer).convert('RGB'))
