from pathlib import Path
import sys,json
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent.parent))
import atlas_v3 as a
D=dict(np.load(ROOT/'fluid_fields.npz'));x,y,z=D['x'],D['y'],D['bed'];j=int(np.argmin(abs(y-.245)));i=int(np.argmin(abs(x-.58)))
s=a.SVG('One visible sill. An open way out.','The painted stage and the solved terrain use the same geometry.','V21 / STAGE DESIGN')
ink='#293b58';mut='#7b889a';blue='#4387bd';gold='#bc965b'
s.line((880,278),(930,278),blue,3);s.text(940,285,'gate open',19,blue);s.line((1140,278),(1190,278),'#76b6d4',3);s.text(1200,285,'baseline',19,'#76b6d4')
s.text(100,240,'Across the bank',30,ink,True);s.text(850,240,'Down the open slope',30,ink,True)
left=lambda X,Z:np.c_[110+(X-.38)/.4*590,650-Z/.07*330]
right=lambda Y,Z:np.c_[860+(Y-.12)/.70*590,430-Z/.08*250]
# Exact piecewise sampled bed sections, with translucent water columns.
for chart,coord,bed,h0,h1 in [(left,x,z[j],D['h_baseline'][0,j],D['h_A'][-1,j]),(right,y,z[:,i],D['h_baseline'][0,:,i],D['h_A'][-1,:,i])]:
 p=chart(coord,bed);base=chart(coord,np.full_like(bed,-.008 if chart is left else -.095));s.path(np.vstack((p,base[::-1])),'none',0,fill='#ebe9e2',opacity=.7,close=True)
 for h,col,opacity in [(h1,blue,.26),(h0,'#76b6d4',.35)]:
  wet=h>.00008
  idx=np.flatnonzero(wet)
  for seg in np.split(idx,np.flatnonzero(np.diff(idx)>1)+1):
   if len(seg)<2:continue
   s.path(np.vstack((chart(coord[seg],bed[seg]+h[seg]),chart(coord[seg],bed[seg])[::-1])),'none',0,fill=col,opacity=opacity,close=True)
   s.path(chart(coord[seg],bed[seg]+h[seg]),col,2.2,opacity=.95)
 s.path(p,gold,3)
s.text(404,708,'low sill',24,gold,True,anchor='middle');p=left(np.array([.58]),np.array([z[j,i]]))[0];s.line((404,682),p,gold,1)
s.text(120,355,'high shoulder',22,mut);s.text(540,355,'high shoulder',22,mut)
s.text(100,770,'A shallow baseline flow already crosses the sill.',21,ink)
s.text(850,770,'No retaining rim. No hidden pool.',21,ink)
s.text(850,810,'Water leaves through open boundaries.',21,mut)
s.text(100,810,'Opening the gate increases that flow.',21,mut)
s.footer('Here, the low sill explains where the water crosses the bank.','Model sections, not measured terrain • water profiles: baseline at t=0 and opened gate at t=8 s • SI geometry')
(ROOT/'stage-plan.svg').write_text(s.finish())
import subprocess
subprocess.run(['rsvg-convert','-o',str(ROOT/'stage-plan.png'),str(ROOT/'stage-plan.svg')],check=True)
print('stage diagram')
