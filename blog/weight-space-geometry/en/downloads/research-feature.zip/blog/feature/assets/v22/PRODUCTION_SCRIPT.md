# V22 production script

## Editorial boundary

V22 is a local review artifact for a revised open stage. The stage uses a real `+x` inlet/main/right outlet and a real `+y` side apron. The ordinary downstream fall is kept visually distinct from the side exit. The gate-water mask is constrained to the under-leaf aperture and existing channel; it is an optical watercolor pass, not gate-scale CFD. The straight clean plate is applied only to the local reach. It is a static clean background for the right actor, pole, and boat; it does not use Weave.

The intended causal storyboard is:

1. Baseline: no intervention; designed expectation `MAIN CHANNEL`.
2. Gate condition: gate raises flow; designed expectation `SIDE EXIT`.
3. Pole condition: pole gives lateral force; designed expectation `SIDE EXIT`.

These are design targets until `verification-v22.json` records a passing current run. A common exit boundary is not a claim of common trajectory or a proof of duality.

## Timing and frame holds

- 0–10.5 s: baseline.
- 10.5–11 s: dissolve/reset.
- 11–14 s: gate condition.
- 14–14.5 s: dissolve/reset.
- 14.5–21.5 s: pole condition.
- 21.5–23.5 s: comparison hold at the recorded computed exits.
- 23.5–24 s: loop dissolve.
- Physical seconds equal display seconds for all conditions; there is no `1.6` clock factor.
- Freeze the entire frame at each computed exit and label it as a recorded exit, never as a long intervention hold or extrapolated success.

## Evidence gates

Do not freeze numeric prose into the page. `build_review.py` reads the nested `cases` object from `dynamics-metrics.json`; if `verification-v22.json` is absent or does not explicitly pass, the page says verification is pending. Baseline, A, and B outcomes remain conditional on the current hashes and verification record.

Do not reuse old baseline/RK data or claim `.01L` grid convergence unless the current source hashes match the evidence that supports the statement. The current final junction configuration is 144×96 with `Qbase = 0.00043`; the final verification is rerunning after the pole-angle fix. Physics and rig statuses must remain pending until `verification-v22.json` explicitly records them as passed.

The pole projection uses fixed reach `RIG_VERTICAL = 0.60`. The final junction solve is allowed to remain in progress; the review page must not invent a terminal result while it is computing.

## Rendering and delivery

Expected media names are `motion-review.mp4`, `motion-review.gif`, `poster.jpg`, `detail-left/right/water.mp4`, corresponding JPG stills, `stage-board.svg`, `straight-clean-plate.png`, `dynamics-metrics.json`, and the forthcoming `verification-v22.json`. Missing media are listed as missing by the page builder rather than fabricated.

Run `junction.py`, `run_cases.py`, `render.py --movie`, then `build_review.py` only after review. The builder writes the local publish and Downloads package paths documented in `README.md`; it does not itself run publication. Large field arrays remain out of the package unless a separately authorized data option is supplied.

## Shared gate response and river continuity revision

During the gate take, the left actor raises the leaf over 0.8 s. The illustrative upstream response advances from upstream to downstream over 0.4 s; the resolved local inlet starts its ramp after that delay. Water pigment and passive boats sample the same route-time field. A passive boat retains its position and velocity on entering the local body solver. No frame-dependent teleport, hard x-coordinate velocity switch, or arbitrary disappearance at the handoff is permitted.

The A terminal time is taken from the new integration; the full scene is held only after the observed side exit. All boats are displayed at 120% scale, around the same waterline anchor. The shared 24 s timing, transparent sidewalls, under-leaf gate flow and continuous main waterfall are retained. The scope remains an illustrative upstream extension with local 2D dynamics, not full-river or 3D CFD.

## Pole rigidity

Keep the original rest-pose shaft length in every frame (312.869534476912 px). Translate and rotate the whole rod from its contact tip; do not scale it to meet the hands. Drive both hand targets from their material positions on this one shaft, and solve the actor pose from those targets. The 0.57 m unit-axis 3D lift must remain continuous on its fixed branch. Verify the derived endpoint distance in the actual camera, not only the nominal length parameter. Boat contact points and hydrodynamic trajectories remain those of the preceding continuity revision.

## Two-hand force-transfer choreography

For the B take, plant the pole over local 3.3–4.4 s, brace and drive over 4.4–5.6 s, then recover smoothly over the following 1.3 s. During contact, both grip distances remain 0.36 m and 0.49 m from the same fixed shaft tip. Keep the existing tip trajectory and rod length. The torso pivots from the pelvis and lowers into the stance; both shoulders follow that one transform. Both elbows solve from the shoulders to the grips without shoulder separation or arm stretching. Head, neckline and Nioh sash follow the torso; the exposed foot contacts stay planted. Rotate the palm texture frame with the rod and place the fingers above the shaft at both grips. Do not animate two detached hand cutouts against a static body.


## Editorial overlay revision: quiet callouts

Central titles are replaced with scene-local annotations in the negative space. Baseline follows the target boat; the gate sequence points first to the moving gate and then the carried boat; the pole sequence points to its live tip and adds a ring only on contact. After release the marker smoothly follows the boat. The final panel points to the shared side-exit region and explicitly describes different actions and paths. Timing and target definitions are in `callouts.py`. Existing 24-second scene timing and physical motion remain unchanged.
