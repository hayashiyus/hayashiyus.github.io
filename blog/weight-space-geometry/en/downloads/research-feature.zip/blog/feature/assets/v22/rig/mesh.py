"""Continuous source-texture mesh, with destination-domain inverse sampling."""
from pathlib import Path
import json
import cv2
import numpy as np
from PIL import Image
from scipy.spatial import Delaunay
from .body_pose import solve_body
HERE=Path(__file__).resolve().parent
SPEC=json.loads((HERE/'geometry.json').read_text())
# Corrected against the full-resolution painting: the former front shoulder
# was placed on the actor's neck, and the rear elbow on his forearm.
SPEC['actors']['right_operator']['joints'].update(
    shoulder_front=[1320,423],elbow_front=[1298,482],hand_front=[1281,521],
    shoulder_back=[1400,411],elbow_back=[1390,455],hand_back=[1330,460])
SRC=np.asarray(Image.open(HERE/'../../v14/sluice-reference.png').convert('RGB'))
TEXTURE=np.asarray(Image.open(HERE/'actor-texture.png').convert('RGB')) if (HERE/'actor-texture.png').exists() else SRC
FREE=np.asarray(Image.open(HERE/'../../v13/actor-free-plate.png').convert('RGB'))
OUTLINES={
'left_operator':[(12,497),(0,462),(0,350),(8,291),(26,245),(13,223),(25,200),(62,202),(88,182),(109,147),(153,114),(198,111),(243,131),(258,163),(252,192),(240,224),(255,247),(279,270),(306,280),(311,301),(293,314),(268,310),(251,289),(241,320),(240,346),(225,355),(229,382),(206,400),(189,432),(152,457),(132,484),(108,506),(68,500)],
'right_operator':[(1256,540),(1267,495),(1285,449),(1276,412),(1285,379),(1283,350),(1280,326),(1290,315),(1314,315),(1331,299),(1360,299),(1376,314),(1396,324),(1413,320),(1412,336),(1450,322),(1480,332),(1515,352),(1516,389),(1500,417),(1507,454),(1490,473),(1518,497),(1526,530),(1504,550),(1526,579),(1535,600),(1510,624),(1502,648),(1500,673),(1522,701),(1501,727),(1466,693),(1443,653),(1414,658),(1385,647),(1368,635),(1337,618),(1331,578),(1309,559),(1290,547)]}

def mask(poly):
    m=np.zeros(SRC.shape[:2],np.uint8)
    cv2.fillPoly(m,[np.asarray(poly,np.int32)],255)
    return cv2.GaussianBlur(m,(3,3),.6)

def ik(s,e,h,t,shift):
    s,e,h,t,shift=map(lambda x:np.asarray(x,float),(s,e,h,t,shift))
    l1,l2=np.linalg.norm(e-s),np.linalg.norm(h-e)
    ss=s+shift;v=t-ss;r=np.linalg.norm(v)
    if r>l1+l2-.05:
        ss+=(r-(l1+l2-.05))*v/r;v=t-ss;r=np.linalg.norm(v)
    if r<abs(l1-l2)+.05:raise ValueError('unreachable folded arm')
    if np.linalg.norm(ss-s)>60:raise ValueError('shoulder reach exceeds design range')
    u=v/r;n=np.array([-u[1],u[0]])
    a=(l1*l1+r*r-l2*l2)/(2*r);b=np.sqrt(max(0,l1*l1-a*a))
    original=h-s; elbow=e-s
    bend_sign=1 if original[0]*elbow[1]-original[1]*elbow[0]>=0 else -1
    ee=ss+a*u+bend_sign*b*n
    return ss,ee,t

class Actor:
    def __init__(self,name):
        self.name=name;self.a=SPEC['actors'][name];self.j=self.a['joints']
        self.alpha=mask(OUTLINES[name]);self.left=name=='left_operator'
        matte=HERE/('left-alpha.png' if self.left else 'right-alpha.png')
        if matte.exists():self.alpha=np.asarray(Image.open(matte))
        self.sides=[''] if self.left else ['front','back']
        self.keys=[];pts=[];self.neighborhoods={}
        outline=np.asarray(OUTLINES[name],float)
        margin=16 if self.left else 100
        xmin,ymin=outline.min(0)-margin;xmax,ymax=outline.max(0)+margin
        for p in [(xmin,ymin),(xmax,ymin),(xmax,ymax),(xmin,ymax)]:
            self.keys.append('boundary');pts.append(p)
        support=([[60,478],[108,490],[159,448],[196,397]] if self.left
                 else [[1400,610],[1446,644],[1478,694],[1501,714],[1355,602]])
        for p in support:self.keys.append('support');pts.append(p)
        heads=([[143,137],[217,151],[219,203],[167,216]] if self.left
               else [[1285,310],[1395,310],[1410,370],[1365,416],[1308,396]])
        for p in heads:self.keys.append('head');pts.append(p)
        if not self.left:
            # A connected torso silhouette, pelvis and fixed foot contacts.
            # The old mesh only moved shoulders and a few face points.
            extra=[(p,'shell') for p in OUTLINES[name] if p not in [(1267,495),(1309,559),(1290,547)]]
            extra += [(p,'torso') for p in [[1430,425],[1455,465],[1454,510],[1408,545],[1410,580],[1360,545]]]
            extra += [(p,'foot') for p in [[1500,704],[1490,700],[1480,688],[1510,713]]]
            for p,key in extra:
                if min(np.linalg.norm(np.asarray(q)-p) for q in pts)<2:continue
                self.keys.append(key);pts.append(p)
        for side in self.sides:
            suffix='_'+side if side else ''
            for part in ('shoulder','elbow','hand'):
                key=part+suffix;self.keys.append(key);pts.append(self.j[key])
        # Preserve the painted fingers/cuffs locally. A single wrist vertex
        # alone allows its surrounding texture to smear across long triangles.
        for side in self.sides:
            suffix='_'+side if side else ''
            for part,radius in [('hand',9.),('elbow',10. if self.left else 4.)]:
                key=part+suffix
                for angle in np.linspace(0,2*np.pi,8,endpoint=False):
                    offset=radius*np.array([np.cos(angle),np.sin(angle)])
                    self.neighborhoods[len(pts)]=(key,offset)
                    self.keys.append('neighborhood');pts.append(np.asarray(self.j[key])+offset)
        self.src=np.asarray(pts,np.float32);self.tri=Delaunay(self.src).simplices

    def targets(self,hands,cue=None):
        if not self.left:return self.right_targets(hands,cue or {})
        names=['hand'+('_'+s if s else '') for s in self.sides]
        shift=np.mean([np.asarray(hands.get(k,self.j[k]))-self.j[k] for k in names],axis=0)*.82
        joints={};errors=[]
        for side in self.sides:
            suff='_'+side if side else '';ns=[p+suff for p in ('shoulder','elbow','hand')]
            s,e,h=[self.j[k] for k in ns];chain=ik(s,e,h,hands.get(ns[2],h),shift)
            joints.update(zip(ns,chain))
            errors.extend([abs(np.linalg.norm(chain[1]-chain[0])-np.linalg.norm(np.array(e)-s)),abs(np.linalg.norm(chain[2]-chain[1])-np.linalg.norm(np.array(h)-e))])
        dst=self.src.copy()
        for i,key in enumerate(self.keys):
            if key in joints:dst[i]=joints[key]
            elif key=='head':dst[i]+=shift*.42
            elif key=='neighborhood':
                joint,offset=self.neighborhoods[i];dst[i]=joints[joint]+offset
        feet=np.array([[82,490],[100,482]] if self.left else [[1500,704],[1490,700]],float)
        triangulation=Delaunay(self.src)
        mapped=[]
        for point in feet:
            k=triangulation.find_simplex(point)
            ids=triangulation.simplices[k]
            bary=np.linalg.solve(np.vstack((self.src[ids].T,np.ones(3))),np.r_[point,1.])
            mapped.append(bary@dst[ids])
        foot_error=float(np.linalg.norm(np.asarray(mapped)-feet,axis=1).max())
        return dst,dict(joints={k:v.tolist() for k,v in joints.items()},max_segment_error_px=float(max(errors)),foot_drift_px=foot_error,foot_source_px=feet.tolist(),foot_mapped_px=np.asarray(mapped).tolist(),shoulder_shift_px=shift.tolist())

    def right_targets(self,hands,cue):
        pose=solve_body(hands,cue)
        if pose['diagnostics']['constraint_violations']:
            raise ValueError('Coupled torso cannot reach both grips: '+str(pose['diagnostics']))
        R=np.asarray(pose['rotation']);pivot=np.asarray(pose['pivot']);shift=np.asarray(pose['translation'])
        torso=lambda p:pivot+R@(np.asarray(p)-pivot)+shift
        joints={};errors=[];bone_maps={}
        def rot(v,w):
            a=np.arctan2(w[1],w[0])-np.arctan2(v[1],v[0]);c,s=np.cos(a),np.sin(a)
            return np.array([[c,-s],[s,c]])
        for side in self.sides:
            names=[p+'_'+side for p in ('shoulder','elbow','hand')]
            s,e,h=[np.asarray(self.j[k],float) for k in names]
            shoulder=np.asarray(pose['shoulders'][side])
            chain=ik(s,e,h,hands.get(names[2],h),shoulder-s)
            if np.linalg.norm(chain[0]-shoulder)>1e-6:raise ValueError('Independent shoulder correction forbidden')
            joints.update(zip(names,chain))
            errors.extend([abs(np.linalg.norm(chain[1]-chain[0])-np.linalg.norm(e-s)),abs(np.linalg.norm(chain[2]-chain[1])-np.linalg.norm(h-e))])
            bone_maps[side]=[(s,e,chain[0],rot(e-s,chain[1]-chain[0])),
                             (e,h,chain[1],rot(h-e,chain[2]-chain[1]))]
        src_axis=np.asarray(self.j['hand_back'])-self.j['hand_front']
        dst_axis=joints['hand_back']-joints['hand_front']
        handR=rot(src_axis,dst_axis)
        def lower(p):
            p=np.asarray(p);w=np.clip((690-p[1])/110,0,1);w=w*w*(3-2*w)
            return p+shift*w+np.array([-pose['knee_flex_px']*.35,0.])*w*(1-w)*4
        def shell(p):
            p=np.asarray(p)
            if p[1]>=580:return lower(p)
            out=torso(p)
            if p[1]<420:return out
            candidates=[]
            for side in self.sides:
                for a,b,A,Q in bone_maps[side]:
                    f=np.clip((p-a)@(b-a)/np.sum((b-a)**2),0,1)
                    distance=np.linalg.norm(p-(a+f*(b-a)))
                    candidates.append((distance,A+Q@(p-a)))
            distance,arm=min(candidates,key=lambda x:x[0])
            w=np.clip((44-distance)/25,0,1);w=w*w*(3-2*w)
            return out*(1-w)+arm*w
        dst=self.src.copy()
        for i,key in enumerate(self.keys):
            p=self.src[i]
            if key in joints:dst[i]=joints[key]
            elif key in ('head','torso'):dst[i]=torso(p)
            elif key=='shell':dst[i]=shell(p)
            elif key=='support':dst[i]=lower(p)
            elif key=='neighborhood':
                joint,offset=self.neighborhoods[i]
                side=joint.split('_')[-1]
                Q=handR if joint.startswith('hand') else np.eye(2)
                dst[i]=joints[joint]+Q@offset
        feet=np.array([[1500,704],[1490,700]],float)
        triangulation=Delaunay(self.src);mapped=[]
        for p in feet:
            ids=triangulation.simplices[triangulation.find_simplex(p)]
            bary=np.linalg.solve(np.vstack((self.src[ids].T,np.ones(3))),np.r_[p,1.]);mapped.append(bary@dst[ids])
        return dst,dict(joints={k:v.tolist() for k,v in joints.items()},max_segment_error_px=float(max(errors)),
                        foot_drift_px=float(np.linalg.norm(np.asarray(mapped)-feet,axis=1).max()),
                        foot_source_px=feet.tolist(),foot_mapped_px=np.asarray(mapped).tolist(),
                        shoulder_shift_px=shift.tolist(),body=pose,hand_rotation=handR.tolist(),
                        hand_axis_px=(dst_axis/np.linalg.norm(dst_axis)).tolist())

    def layer(self,hands,cue=None):
        key=(tuple((k,*np.asarray(v,dtype=float).ravel()) for k,v in sorted(hands.items())),
             tuple(sorted((cue or {}).items())))
        if getattr(self,'_last_layer_key',None)==key:return self._last_layer_result
        result=self._render_layer(hands,cue)
        self._last_layer_key=key;self._last_layer_result=result
        return result

    def _render_layer(self,hands,cue=None):
        dst,diag=self.targets(hands,cue)
        if np.max(abs(dst-self.src))<1e-4:return np.dstack((TEXTURE,self.alpha)),diag
        yy,xx=np.mgrid[:1024,:1536];mx=xx.astype(np.float32);my=yy.astype(np.float32)
        for ids in self.tri:
            to=dst[ids];fr=self.src[ids]
            cross=lambda a,b:a[0]*b[1]-a[1]*b[0]
            if cross(to[1]-to[0],to[2]-to[0])*cross(fr[1]-fr[0],fr[2]-fr[0])<=0:raise ValueError('inverted actor triangle')
            x,y,w,h=cv2.boundingRect(to.astype(np.float32))
            xa,ya=max(0,x),max(0,y);xb,yb=min(1536,x+w+1),min(1024,y+h+1)
            if xb<=xa or yb<=ya:continue
            mm=np.zeros((yb-ya,xb-xa),np.uint8)
            cv2.fillConvexPoly(mm,np.rint(to-[xa,ya]).astype(np.int32),255)
            M=cv2.getAffineTransform(to.astype(np.float32),fr.astype(np.float32))
            gx,gy=xx[ya:yb,xa:xb],yy[ya:yb,xa:xb]
            sx=M[0,0]*gx+M[0,1]*gy+M[0,2];sy=M[1,0]*gx+M[1,1]*gy+M[1,2]
            mx[ya:yb,xa:xb][mm>0]=sx[mm>0];my[ya:yb,xa:xb][mm>0]=sy[mm>0]
        rgba=cv2.remap(np.dstack((TEXTURE,self.alpha)),mx,my,cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT)
        return rgba,diag

ACTORS={name:Actor(name) for name in OUTLINES}
def over(dst,rgba):
    a=rgba[:,:,3:4].astype(np.float32)/255
    return np.clip(dst*(1-a)+rgba[:,:,:3]*a,0,255).astype(np.uint8)

def render_targets(left_lift=0.,right_handfront=None,right_handback=None,base_image=None):
    out=FREE.copy() if base_image is None else base_image.copy();diags={}
    for name,actor in ACTORS.items():
        hands={}
        if actor.left:hands['hand']=np.array(actor.j['hand'])-[0,left_lift]
        else:
            if right_handfront is not None:hands['hand_front']=right_handfront
            if right_handback is not None:hands['hand_back']=right_handback
        rgba,diag=actor.layer(hands);out=over(out,rgba);diags[name]=diag
    return out,diags

def preflight():
    frames=[];metrics={}
    for name,lift,h1,h2 in [('rest',0,None,None),('pull',18,None,None),('push',0,[1275,530],[1324,469])]:
        im,diag=render_targets(lift,h1,h2)
        Image.fromarray(im).save(HERE/('mesh-'+name+'.jpg'),quality=88)
        frames.append(Image.fromarray(im).resize((768,512)));metrics[name]=diag
    sheet=Image.new('RGB',(768,1536),'white')
    for i,im in enumerate(frames):sheet.paste(im,(0,512*i))
    sheet.save(HERE/'mesh-keyposes.jpg',quality=88)
    (HERE/'mesh-metrics.json').write_text(json.dumps(metrics,indent=2))

if __name__=='__main__':preflight()
