"""Reproducible, current-config verification for the v22 artifact.

This checker reports scoped kinematic/causal outcomes only.  It intentionally
does not turn the old coarse/fine comparisons into a convergence claim.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np

import boats
from motion import Motion, POLE_LENGTH, POLE_LENGTH_PX
from rig.mesh import ACTORS

ROOT = Path(__file__).resolve().parent
INITIAL = np.array([.15, .16, 0., .09, 0., 0.])
CASES = ("baseline", "A", "B")


def _field(data, kind, case, t, xy):
    typ = "A" if case == "A" else "baseline"
    return boats.field(data[f"{kind}_{typ}"], data[f"u_{typ}"], data[f"v_{typ}"],
                      t, xy, data["x"][0], data["y"][0],
                      data["x"][1] - data["x"][0], data["y"][1] - data["y"][0])


def _hull_points(row, dense=13):
    _, x, y, theta = row[:4]
    c, s = np.cos(theta), np.sin(theta)
    pts = []
    for a in np.linspace(-boats.L / 2, boats.L / 2, dense):
        for d in np.linspace(-boats.WIDTH / 2, boats.WIDTH / 2, dense):
            if abs(a) in (boats.L / 2,) or abs(d) in (boats.WIDTH / 2,):
                pts.append([x + c * a - s * d, y + s * a + c * d])
    return np.asarray(pts)


def check_cases(data):
    report = {}
    for case in CASES:
        states = boats.simulate(data, case, INITIAL)
        minimum = float("inf")
        worst = None
        inside = True
        for row in states:  # every integration dt, with a dense perimeter
            points = _hull_points(row)
            inside &= bool(np.all((points[:, 0] >= data["x"][0]) & (points[:, 0] <= data["x"][-1]) &
                                  (points[:, 1] >= data["y"][0]) & (points[:, 1] <= data["y"][-1])))
            for p in points:
                h = float(_field(data, "h", case, float(row[0]), p)[0])
                if h < minimum:
                    minimum, worst = h, [float(row[0]), float(p[0]), float(p[1])]
        terminal = "main" if states[-1, 1] > .93 else "side" if states[-1, 2] > .32 else "none"
        terminal_pass = (terminal == "main" and states[-1, 1] > .93) or (terminal == "side" and states[-1, 2] > .32)
        report[case] = {
            "terminal": terminal, "terminal_t_s": float(states[-1, 0]),
            "terminal_pass": bool(terminal_pass),
            "whole_hull_main_x_gt_093_or_side_y_gt_032": bool(terminal_pass),
            "minimum_dense_hull_depth_m": minimum,
            "minimum_depth_pass_ge_0008": bool(minimum >= .0008),
            "body_all_points_within_field": bool(inside),
            "state_rows_checked": int(len(states)), "worst_t_xy": worst,
        }
    return report


def check_causality(data):
    fields_initial_equal = all(np.array_equal(data[f"{k}_baseline"][0], data[f"{k}_A"][0]) for k in ("h", "u", "v"))
    base = boats.simulate(data, "baseline", INITIAL)
    b = boats.simulate(data, "B", INITIAL)
    pre = min(np.searchsorted(base[:, 0], boats.START), np.searchsorted(b[:, 0], boats.START))
    pre_exact = bool(np.array_equal(base[:pre + 1], b[:pre + 1]))
    motion = Motion()
    gaps = np.array([motion.contact(float(t))["gap_m"] or 0. for t in np.linspace(boats.START, boats.RETRACT, 101)])
    forces = np.array([motion.contact(float(t))["force_N"] for t in np.linspace(boats.START, boats.RETRACT, 101)])
    return {
        "A_baseline_initial_huv_exact": fields_initial_equal,
        "B_baseline_pre_pole_state_exact": pre_exact,
        "pole_only_compression": bool(np.min(gaps) < 0 and np.max(forces) > 0),
        "minimum_contact_gap_m": float(np.min(gaps)),
        "maximum_contact_force_N": float(np.max(forces)),
        "yaw_torque_response_present": bool(np.max(np.abs(b[:, 6])) > 0),
    }


def _rig_check():
    motion = Motion()
    samples = np.unique(np.r_[np.linspace(0., 8., 961), motion.boats['B'][-1,0]])
    max_seg = 0.; max_foot = 0.; inverted = 0; pole_lengths = []; pose_errors = []
    image_lengths=[];grip_errors=[]
    shoulder_errors=[];hand_axis_errors=[];head_errors=[];area_ratios=[];leans=[];hips=[];reaches=[]
    for t in samples:
        g = motion.geometry("B", float(t))
        # Measure the derived geometry, not the constant length metadata.
        pole_lengths.append(float(np.linalg.norm(g['pole_vector_3d'])))
        image_lengths.append(float(np.linalg.norm(g['pole_end_px']-g['tip_px'])))
        for key,distance in zip(('hand_front_px','hand_back_px'),g['grip_distances_m']):
            expected=g['tip_px']+(distance/POLE_LENGTH)*(g['pole_end_px']-g['tip_px'])
            grip_errors.append(float(np.linalg.norm(g[key]-expected)))
        try:
            dst, diag = ACTORS["right_operator"].targets({"hand_front": g["hand_front_px"], "hand_back": g["hand_back_px"]},g['right_body_cue'])
        except ValueError as exc:
            pose_errors.append({"t_s": float(t), "error": str(exc)})
            continue
        max_seg = max(max_seg, float(diag["max_segment_error_px"]))
        max_foot = max(max_foot, float(diag["foot_drift_px"]))
        actor=ACTORS['right_operator'];src=actor.src
        joints=diag['joints'];source_width=np.linalg.norm(np.asarray(actor.j['shoulder_front'])-actor.j['shoulder_back'])
        shoulder_errors.append(abs(np.linalg.norm(np.asarray(joints['shoulder_front'])-joints['shoulder_back'])-source_width))
        pole=g['pole_end_px']-g['tip_px'];pole/=np.linalg.norm(pole)
        hand_axis_errors.append(float(np.linalg.norm(pole-diag['hand_axis_px'])))
        pose=diag['body'];R=np.asarray(pose['rotation']);pivot=np.asarray(pose['pivot']);shift=np.asarray(pose['translation'])
        for k,key in enumerate(actor.keys):
            if key=='head':head_errors.append(float(np.linalg.norm(dst[k]-(pivot+R@(src[k]-pivot)+shift))))
        leans.append(float(np.degrees(pose['torso_angle_rad'])));hips.append(pose['translation']);reaches.append(pose['max_reach_ratio'])
        for tri in ACTORS["right_operator"].tri:
            a, b, c = src[tri]; A, B, C = dst[tri]
            cross = lambda p, q: p[0] * q[1] - p[1] * q[0]
            ratio=float(cross(B-A,C-A)/cross(b-a,c-a));area_ratios.append(ratio)
            if ratio <= 0: inverted += 1
    pole_lengths = np.asarray(pole_lengths)
    return {
        "all_run_poses_checked": int(len(samples)),
        "all_poses_targetable": not pose_errors,
        "pose_errors": pose_errors,
        "triangle_orientation_preserved": inverted == 0,
        "inverted_triangle_count": int(inverted),
        "fixed_feet_max_drift_px": max_foot,
        "fixed_feet_pass_lt_1px": bool(max_foot < 1.),
        "max_segment_error_px": max_seg,
        "pole_length_constant_m": bool(np.max(abs(pole_lengths-POLE_LENGTH))<1e-12),
        "pole_length_range_m": [float(pole_lengths.min()), float(pole_lengths.max())],
        "projected_pole_length_constant_px": bool(max(abs(np.asarray(image_lengths)-POLE_LENGTH_PX))<1e-9),
        "projected_pole_length_range_px": [min(image_lengths),max(image_lengths)],
        "grips_on_same_rigid_shaft": bool(max(grip_errors)<1e-9),
        "maximum_grip_registration_error_px": max(grip_errors),
        "rigid_shoulder_girdle_preserved": bool(max(shoulder_errors)<1e-6),
        "maximum_shoulder_width_error_px": max(shoulder_errors),
        "hand_axis_aligned_with_pole": bool(max(hand_axis_errors)<1e-9),
        "maximum_hand_axis_error": max(hand_axis_errors),
        "head_follows_torso": bool(max(head_errors)<1e-3),
        "maximum_head_transform_error_px": max(head_errors),
        "torso_lean_range_degrees": [min(leans),max(leans)],
        "hip_translation_range_px": [np.min(hips,axis=0).tolist(),np.max(hips,axis=0).tolist()],
        "maximum_arm_reach_ratio": max(reaches),
        "minimum_triangle_area_ratio": min(area_ratios),
        "elbows_keep_extension_margin": bool(max(reaches)<.981),
        "motion_projection": {"M": [[500., -400.], [100., 240.]], "ORIGIN": [965., 604.], "grips_preparing": [.24, .37], "grips_push": [.36, .49]},
    }


def main():
    data = dict(np.load(ROOT / "fluid_fields.npz"))
    checks = check_cases(data)
    causal = check_causality(data)
    digest = hashlib.sha256((ROOT / "fluid_fields.npz").read_bytes()).hexdigest()
    status = all(v["terminal_pass"] and v["minimum_depth_pass_ge_0008"] and v["body_all_points_within_field"] for v in checks.values()) and all(causal.values())
    report = {
        "status": "PASS" if status else "FAIL", "scope": "current 144x96 fine fields and current boat cases",
        "config": {"grid": [144, 96], "QBASE_m3s": .00043, "QEXTRA_m3s": .0024, "Y1_m": .48, "fluid_fields_sha256": digest},
        "cases": checks, "causal": causal,
        "spatial_convergence": {"status": "NOT TESTED", "limitation": "Previous coarse/fine versions failed strict comparison; no convergence claim for this final config."},
    }
    rig = _rig_check()
    required=('all_poses_targetable','triangle_orientation_preserved','fixed_feet_pass_lt_1px',
              'pole_length_constant_m','projected_pole_length_constant_px','grips_on_same_rigid_shaft',
              'rigid_shoulder_girdle_preserved','hand_axis_aligned_with_pole','head_follows_torso','elbows_keep_extension_margin')
    rig_report = {"status": "PASS" if all(rig[k] for k in required) else "FAIL", "scope": "all sampled current rig poses, derived shaft length and projected length", "checks": rig, "blocker": "At least one current motion pose exceeds the rig shoulder reach guard." if rig["pose_errors"] else None}
    (ROOT / "verification-v22.json").write_text(json.dumps(report, indent=2) + "\n")
    (ROOT / "rig-verification-v22.json").write_text(json.dumps(rig_report, indent=2) + "\n")
    print(json.dumps({"verification": report["status"], "rig": rig_report["status"]}))


if __name__ == "__main__":
    main()
