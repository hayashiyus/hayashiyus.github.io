"""Watercolor advection on one shared curved route-time velocity field.

Upstream visual response and passive boats use RiverFlow. Downstream velocities
come from the saved SWE fields. The shared route map removes the former hard
spatial switch at x=970; the side-spill and final-fall passes keep their own
explicit surface geometry. No new full-river CFD is claimed here.
"""
import cv2
import numpy as np

def sample(image,sx,sy):
    # OpenCV remap limits either destination dimension to <32767. Pack the
    # water-pixel list into short rows instead of one 60k-wide scanline.
    n=len(sx);cols=2048;pad=(-n)%cols
    x=np.pad(sx.astype(np.float32),(0,pad),mode='edge').reshape(-1,cols)
    y=np.pad(sy.astype(np.float32),(0,pad),mode='edge').reshape(-1,cols)
    a=cv2.remap(image,x,y,cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT)
    return a.reshape((-1,)+a.shape[2:])[:n]

def paint_water(renderer,take,t):
    out=renderer.base.copy();yy,xx=renderer.yy,renderer.xx
    flow=renderer.river_flow;arc=renderer.arc;cross=renderer.cross
    texture=renderer.texture;samples=[];weights=[];period=.55
    # A small transverse optical wave; flow direction comes from the curve.
    wave=.30*np.sin(arc*.061-float(t)*13)+.15*np.sin(arc*.119+cross*.08-float(t)*21)
    for offset in (0.,.5):
        phase=(float(t)/period+offset)%1.;age=phase*period
        traced=flow.backtrace(take,float(t),age)
        source_s=np.interp(arc,flow.s,traced)
        source_xy=flow.path(source_s)+flow.normal(source_s)*(cross+wave)[:,None]
        sx=source_xy[:,0];sy=source_xy[:,1]
        moved=sample(texture,sx,sy).astype(float)
        confidence=sample(renderer.source_watermask.astype(np.float32)/255,sx,sy)
        # Soft source confidence replaces the old >240 all-or-nothing reset.
        # Geometry controls the shoreline; warmth guards only invalid samples.
        safe=np.clip((moved[:,2]-moved[:,0]+3)/8,0,1)
        confidence*=safe
        moved=moved*confidence[:,None]+texture[yy,xx]*(1-confidence[:,None])
        samples.append(moved);weights.append(1-abs(2*phase-1))
    sampled=(samples[0]*weights[0]+samples[1]*weights[1])/sum(weights)
    dh=flow.depth(take,float(t),arc)-flow.depth('baseline',float(t),arc)
    shade=1+np.clip(dh*.08/.02,-.06,.10)
    normal_light=1+.012*np.sin(arc*.071+cross*.13-float(t)*12.8)
    sampled*=(shade*normal_light)[:,None]
    a=renderer.wateralpha
    out[yy,xx]=np.clip(out[yy,xx]*(1-a)+sampled*a,0,255).astype(np.uint8)
    return out
