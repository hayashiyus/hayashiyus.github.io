# Execution: one rule, two implementations

This replaces the v5 sequential boat/ledger diagram in the article's anatomy
figure. The v5 artifacts remain in the working project as design history.

The new plate devotes its main area to two matched output-coordinate charts.
The left mesh is the image of a sampled input grid under the edited linear
map. The right mesh is a fixed reference; the same intervention is applied
pointwise. Hollow markers retain the original outputs; filled markers show
the current outputs. Both axes and the display projection are fixed.

The model remains W=I, k=(1,0), d=(0,0.7), with A=(1,0), B=(0,1), C=(-1,0).
At strength alpha, both implementations give Wa + alpha*d*(k^T a).
The animation varies alpha to illustrate the identity. It is not an empirical
Qwen trajectory, a time integration of network dynamics, or Astra's search.

## Motion

- 0–1.3 s: common starting state, with a short fade in.
- 1.3–5.2 s: both interventions increase smoothly from zero to full strength.
- 5.6–8.6 s: paired rings identify matching A, B, C outputs in turn.
- 8.6–11.2 s: hold the complete comparison.
- 11.2–12 s: charts and strength indicator fade through the paper background.

The MP4 is 1280×800 at 24 fps. The GIF samples the same calculated frames at
960×600; duplicate frames may be merged without changing their total duration.
The still is 1600×1000. All mathematical labels use the article's KaTeX fonts.

## Rebuild and checks

From the archive root:

```sh
python3 blog/feature/execution_v23.py --stills-only
python3 blog/feature/execution_v23.py
```

Dependencies match the figure-rendering workflow in `blog/feature/README.md`.
The checks evaluate 241 strengths and 169 input-grid points per strength,
confirm identical output positions and their projections, and confirm that B
remains stationary. This is validation of the stated toy, not a model experiment.

The Figma board contains native vector geometry and editable prose, plus the
same rasterized KaTeX labels with their TeX preserved in the source SVG. It
contains the endpoint plate and zero/half-strength keyframes. Movie frames
are computed by the Python source rather than Figma interpolation. Figma uses
Libre Baskerville for editable prose because Georgia is unavailable there;
the web assets retain the article's established editorial typography.
