# v21: visible low spillway, open slope

The near-right bank has an explicit low sill and higher shoulders. The entire local bed, including those shoulders, is rendered as whitewood. The receiving basin and hidden retaining mound from v20 were removed. Baseline water already spills shallowly; opening the gate increases that flow. The two boats cross the same sill, not the same full trajectory. Both displayed takes use physical time 0–7.6 s over 8 screen seconds, with the same factor. The rejected full 8 s window slightly violates the declared B draft on the refined field; this remains recorded in verification-v21.json.

## Reproduce from the repository

```sh
python3 blog/feature/assets/v21/fluid_solver.py
python3 blog/feature/assets/v21/hybrid.py
python3 blog/feature/assets/v21/motion.py
python3 blog/feature/assets/v21/render.py --movie
python3 blog/feature/assets/v21/make_delivery.py
python3 blog/feature/assets/v21/build_review.py
```

Preserved v12/v13/v14 art plates and v21/water.npz are dependencies. The Downloads package contains media and evidence, not a complete solver checkout. Running physics.py directly overwrites the hybrid boat states with a reduced model; if used to prepare upstream data, run hybrid.py afterwards.

## Scope

The local 2D shallow-water solver uses HLL fluxes, hydrostatic reconstruction, SSPRK2, and Manning friction. Open side/downstream fluxes use consistent outward mass and momentum; they are a first-order outflow approximation, not an exact nonreflecting subcritical boundary. The upstream four-reach model supplies stage: global conservation across that one-way interface is not claimed. The boat is a planar drag/contact surrogate with a declared draft; buoyancy, hull-wave feedback, spray and air entrainment are not solved. Watercolor pigment and a short gravity-based falling sheet beyond the open deck are rendering layers.

The geometry, fields and source hashes are recorded in verification-v21.json and physics-contract.json. The rejected intermediate worker model and reports are kept in audit-rejected/ for traceability and are not used by the movie.
