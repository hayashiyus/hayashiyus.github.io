# V22 local river motion review

This directory contains a local review artifact for the revised stage: one real `+x` inlet/main/right outlet and one `+y` side apron. The page is intentionally evidence-aware. It reads `dynamics-metrics.json` at build time and treats `verification-v22.json` as pending unless that file explicitly records a pass.

The film is organized as three conditions with physical seconds equal to display seconds:

- `0–10.5 s`: baseline, design target `MAIN CHANNEL`
- `10.5–11 s`: dissolve/reset
- `11–14 s`: gate condition, design target `SIDE EXIT`
- `14–14.5 s`: dissolve/reset
- `14.5–21.5 s`: pole condition, design target `SIDE EXIT`
- `21.5–23.5 s`: comparison hold at the recorded exits
- `23.5–24 s`: loop dissolve

Each condition freezes the entire review frame at its recorded computed exit; the label is an explicit recorded exit, not a newly simulated continuation. A shared exit boundary is a narrow claim; it does not imply the same path, force, timing, or a proof of duality. The main fall and gate water are animated optics, not 3D CFD.

The current final junction configuration is 144×96 with `Qbase = 0.00043`. The pole projection uses fixed reach `RIG_VERTICAL = 0.60`. The local straightening uses `straight-clean-plate.png`, a static clean background for the right actor, pole, and boat; it is not a stretched-tree repair and does not use Weave.

## Reproduce locally

From the repository root:

```sh
python3 blog/feature/assets/v22/junction.py
python3 blog/feature/assets/v22/run_cases.py
python3 blog/feature/assets/v22/verify_v22.py
python3 blog/feature/assets/v22/render.py --movie
python3 blog/feature/assets/v22/make_delivery.py
python3 blog/feature/assets/v22/build_review.py
```

Run the optional verification script supplied by the parent workflow before treating the page as verified. Do not use stale `.01L` convergence claims or baseline/RK data unless the current source hashes match the evidence record. The current physics and rig statuses are read from `verification-v22.json`; absent or non-passing status remains pending.

`build_review.py` packages only files that already exist into:

- `blog/publish/blog/weight-space-geometry/en/motion-v22`
- `assets/v22/dist` (or the directory set by `WSP_MOTION_V22_OUT`)

The public package should omit `fluid_fields*.npz` and other large arrays unless an explicit data option is provided. Do not run the publication/package step until the current junction solve, media QA, and verification record have been reviewed.

## Transparent-sidewall visual revision

Both sidewalls of the lateral ramp are now fully transparent in the rendering. The floor, water field, boat states, gate/pole motion and simulated boundaries are unchanged. The previous opaque-wall source and media are retained in `revisions/opaque-sidewalls/`. This is a material/visibility change only.

## Continuous main-outlet optical pass

The main reach, rounded lip and falling sheet now share one curvilinear source atlas. The receiving pool uses an outward flow anchored at the same impact. The former overlapping reach/fall masks are replaced with one owner for the outlet. Physical inputs, boat motion and transparent sidewalls are unchanged. This is watercolor optical advection, not a new 3D fluid solve. Prior source and media are in `revisions/before-unified-main-fall/`.

## Continuous river and 120% boats

All boat sprites use the same exact 1.20 affine scale (42×24 → 50.4×28.8 px), with their waterline anchors retained. This is a visual scale change; the local rigid-body mass and hull dimensions are unchanged.

The upper S-river and local reach no longer switch optical velocities at a fixed screen x. `river_flow.py` supplies one continuous route-time field to both watercolor advection and passive boats. The gate signal has a prescribed 0.4 s transit delay to the local inlet, followed by the existing 0.8 s opening ramp. The A fields were recomputed with that inlet delay; local boat states were re-integrated without retiming. Baseline and pole dynamics remain unchanged.

The upper river is an illustrative extension of the local response, not a new full-river CFD solve. Passive boats integrate the shared route speed, then hand off continuously at x=0.13 m, y=0.16 m to the existing force-based body model inside the solved reach. Using an interior point avoids an inlet ghost-cell projection kink. Exact bilinear geometry sampling avoids image-interpolation quantization in boat height.

Run `verify_river_continuity.py` for scale, causal response, and handoff checks. It records the actual position and speed errors in `river-continuity-qa.json`. `detail-join.mp4` shows the changed final bend at normal speed. Prior source and media are in `revisions/before-river-continuity/`.

## Rigid-pole staging revision

The former 0.57 m rod projected to 312.87–398.02 px as its pitch changed through the illustration's oblique camera. The old check inspected a copied length constant, so it missed this visible extension. `motion.rigid_staged_axis` now chooses a continuous unit 3D orientation with the desired image direction and the rest pose's constant projected length. Both hands and the rear endpoint use this same shaft geometry; the hand regrip during preparation is explicit.

The 3D lift uses a fixed camera-nullspace branch. The tip's contact trajectory, boat states, water fields, and 120% boat scale are preserved. The actor reaches and leans to follow the new hand targets. `verify_v22.py` measures derived 3D and projected lengths, as well as hand registration, arm lengths, feet and triangle orientation. `rigid-pole-qa.json` records the before/after values. This is a kinematic staging constraint, not a full 3D load or biomechanical simulation. Prior source and media are retained in `revisions/before-rigid-pole/`.

## Whole-body two-hand push

`rig/body_pose.py` solves one rigid torso transform around the pelvis for both shoulders. The arms then use fixed-length IK from those shoulder positions to the same pole grip targets as the rigid-pole revision. The torso/head outline follows the common transform, the pelvis and lower clothing settle into the stance, and explicit foot pins remain fixed. The right actor's old independent shoulder corrections are forbidden on this path.

The body cue separates planting the pole, driving the stroke, and release. A causal 0.10 s smoothing of the recorded contact force provides a small load cue; it does not apply a new force to the boat. The main lean is choreographed from stroke progress. Hand texture control points and the palm occlusion masks rotate with the pole, preserving the two visible grips.

`verify_v22.py` now passes the same body cue as the renderer and checks 961 poses: rigid shoulder spacing, arm lengths, foot pins, head/torso consistency, hand/shaft alignment, pole lengths, reach margin and triangle orientation. `body-push-qa.json` also checks exact preservation of the prior tip, rear endpoint, grip targets and boat states. This is character kinematics and visual choreography, not a medical or full 3D biomechanical validation. Exact-pose actor-layer caching changes no pixels. Previous media and source are in `revisions/before-body-push/`.


## Quiet action callouts

The current editorial layer is `callouts.py`: translucent paper labels settle in over 0.34 seconds, then a stationary-phase dotted leader draws toward live gate/boat/pole geometry and an open ring appears. No bounce, flashing, or marching dashes. Labels clear before scene transitions. The pole contact halo waits for actual contact. All physical trajectories, painted actors, and body rig are unchanged from the accepted body-push revision. Prior source and media are retained in `revisions/before-callouts/`. See `callouts-qa.json`.
