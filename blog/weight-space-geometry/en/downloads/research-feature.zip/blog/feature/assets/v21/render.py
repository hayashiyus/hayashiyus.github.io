"""Deterministic watercolor compositor; no generated video or boat retiming.

An upstream storage model drives a local two-dimensional shallow-water model.
The boat is integrated from flow and pole forces; subgrid optics are artistic.
"""
from pathlib import Path
import sys,json,subprocess,math
import cv2,numpy as np
from PIL import Image,ImageDraw,ImageFont
from scipy.interpolate import CubicSpline
from scipy.spatial import cKDTree
from motion import Motion,project,M,ORIGIN,ZPX,smooth
from rig.mesh import SRC,FREE,ACTORS,over
from water_paint import paint_water
from spill import Spill
ROOT=Path(__file__).resolve().parent
W,H=1536,1024
TAKE_END=7.6  # same physical observation interval for A/B, shown over 8 s
CLOCK=TAKE_END/8
PAPER=(253,252,250);BLUE=(61,131,178);GOLD=(180,137,58);INK=(42,54,76)
RIVER=np.array([(315,351),(440,352),(510,365),(565,393),(574,428),(585,448),(670,446),(738,452),(781,471),(797,511),(813,532),(875,547),(924,567),(945,603),(974,626),(1070,627),(1172,622),(1242,629),(1313,654),(1362,682),(1393,708),(1407,754),(1435,830),(1388,841),(1368,774),(1351,746),(1290,712),(1221,696),(1136,699),(1040,709),(974,709),(937,692),(917,638),(884,619),(829,613),(786,591),(760,561),(746,524),(710,512),(637,523),(568,520),(528,497),(507,454),(487,424),(442,399),(363,390),(316,384)],float)
ROUTE=np.array([(338,374),(435,383),(505,414),(535,476),(585,498),(679,487),(748,502),(780,543),(815,572),(898,595),(937,635),(974,666),(1090,660),(1190,659),(1268,680),(1350,716),(1381,755)],float)
FONT='/System/Library/Fonts/Supplemental/Georgia.ttf'
SANS='/System/Library/Fonts/Helvetica.ttc'

def polyalpha(points):
    a=np.zeros((H,W),np.uint8);cv2.fillPoly(a,[np.rint(points).astype(np.int32)],255)
    return cv2.GaussianBlur(a,(3,3),.65)

def curve(points,n=700):
    t=np.r_[0,np.cumsum(np.linalg.norm(np.diff(points,axis=0),axis=1))]
    cs=CubicSpline(t,points,bc_type='natural');s=np.linspace(0,t[-1],n)
    return s,cs(s),cs(s,1)

class Renderer:
    def __init__(self):
        self.motion=Motion()
        self.base=SRC.copy()
        self.watermask=polyalpha(RIVER)
        clean=np.asarray(Image.open(ROOT/'../v12/water-clean-plate.png').convert('RGB'))
        self.base=over(self.base,np.dstack((clean,self.watermask)))
        # Erase the two original actors only inside their original silhouettes.
        for actor in ACTORS.values():
            # Mats have closed opaque interiors; a 1px exterior guard removes
            # original ink contours without cutting into hair/costume holes.
            erase=cv2.dilate(actor.alpha,np.ones((3,3),np.uint8))
            self.base=over(self.base,np.dstack((FREE,erase)))
        # The wig and braided sash are surrounded by blank paper. Clear their
        # complete original footprint so fine ink outlines do not remain behind
        # the moving head. This changes only the working background layer.
        self.base[294:421,1270:1536]=FREE[294:421,1270:1536]
        # Original upper staff between actor and boat, outside the silhouette.
        pole=np.zeros((H,W),np.uint8);cv2.line(pole,(1192,654),(1334,456),255,28)
        self.base=over(self.base,np.dstack((FREE,pole)))
        # Only the exposed stem below the hand must be erased. A wide inpaint
        # rectangle would smear the whitewood into the mechanism.
        hardware=np.zeros((H,W),np.uint8)
        cv2.rectangle(hardware,(277,310),(292,346),255,-1)
        hardware=(hardware.astype(float)*(1-ACTORS['left_operator'].alpha/255)).astype(np.uint8)
        self.base=cv2.inpaint(self.base,hardware,4,cv2.INPAINT_TELEA)
        self.texture=clean
        self.s,self.route,self.tangent=curve(ROUTE)
        self.tangent/=np.linalg.norm(self.tangent,axis=1)[:,None]
        self.yy,self.xx=np.where(self.watermask>2)
        pix=np.c_[self.xx,self.yy]
        _,nearest=cKDTree(self.route).query(pix)
        self.arc=self.s[nearest];self.tan=self.tangent[nearest]
        self.normal=np.c_[-self.tan[:,1],self.tan[:,0]]
        self.cross=np.sum((pix-self.route[nearest])*self.normal,axis=1)
        delta=pix-ORIGIN;inv=np.linalg.inv(M)
        self.localxy=np.c_[delta[:,0]*inv[0,0]+delta[:,1]*inv[0,1],delta[:,0]*inv[1,0]+delta[:,1]*inv[1,1]]
        self.local=(self.xx>970)&(self.yy>625)&(self.localxy[:,0]>=0)&(self.localxy[:,0]<=.8)&(self.localxy[:,1]>=0)&(self.localxy[:,1]<=.4)
        self.wateralpha=self.watermask[self.yy,self.xx,None]/255.
        self.boat=self.boat_texture()
        self.spill=Spill(self.texture)

    def boat_texture(self):
        outline=np.array([(614,478),(641,479),(651,462),(662,479),(690,467),(683,490),(662,501),(637,503),(624,492)])
        a=polyalpha(outline);b=np.dstack((SRC,a))[457:509,608:697]
        return Image.fromarray(b).resize((76,44),Image.Resampling.LANCZOS)

    def water(self,take,t):
        return paint_water(self,take,t)

    def gate(self,im,lift):
        # Fixed two rails, single vertically translated leaf/short stem. The
        # working copy beneath the leaf reveals water rather than stretched gold.
        out=Image.fromarray(im);d=ImageDraw.Draw(out,'RGBA')
        rails=[(254,352,258,418),(322,334,327,398)]
        opening=polyalpha(np.array([(257,354),(324,335),(324,402),(257,422)]))
        wet=cv2.resize(self.texture[367:393,350:415],(68,88),interpolation=cv2.INTER_LINEAR)
        waterplate=np.zeros_like(im);waterplate[335:423,257:325]=wet
        out=Image.fromarray(over(np.asarray(out.convert('RGB')),np.dstack((waterplate,opening))))
        d=ImageDraw.Draw(out,'RGBA')
        for x1,y1,x2,y2 in rails:d.line([(x1,y1-20),(x2,y2)],fill=(145,111,48,255),width=7)
        p=np.array([(260,356),(319,339),(320,392),(260,413)],float)
        a=polyalpha(p);layer=np.dstack((SRC,a))
        layer=cv2.warpAffine(layer,np.array([[1,0,0],[0,1,-lift]],float),(W,H))
        out=Image.fromarray(over(np.asarray(out.convert('RGB')),layer));d=ImageDraw.Draw(out,'RGBA')
        # Leaf top at x=285 is y=348.8. The stem must overlap the leaf,
        # rather than stopping above it and leaving a floating handle.
        d.line([(285,352-lift),(285,306-lift)],fill=(143,109,43,255),width=6)
        d.line([(283,351-lift),(283,307-lift)],fill=(222,190,107,255),width=2)
        # A visible notch/latch holds the opened gate after the lift.
        if lift>17.9:d.line([(320,332-lift),(328,332-lift)],fill=(114,94,57,255),width=3)
        return np.asarray(out.convert('RGB'))

    def hull(self,im,pos,yaw=0):
        sprite=self.boat.rotate(-float(yaw)*180/np.pi,resample=Image.Resampling.BICUBIC,expand=True)
        out=Image.fromarray(im);d=ImageDraw.Draw(out,'RGBA')
        x,y=pos;d.ellipse((x-33,y-5,x+33,y+7),fill=(45,84,105,35))
        out=out.convert('RGBA');out.alpha_composite(sprite,(int(x-sprite.width/2),int(y-sprite.height+8)))
        return np.asarray(out.convert('RGB'))

    def scene(self,take,t,comparison=False):
        im=self.spill.draw(self.water(take,t),self.motion,take,t)
        g=self.motion.geometry(take,max(0,t))
        if t<0:
            g['state'][:2]+=g['state'][3:5]*t
            g['boat_px']=project(g['state'][:2])
        im=self.gate(im,g['gate_lift_px'])
        # Upstream boats are passive flow tracers outside the resolved reach.
        for offset in [100,360,620]:
            levels=self.motion.water.levels(take,max(0,t))
            reach=min(3,int(offset/230))
            s=offset+21.25*t*(1+12*(levels[reach]-.02))
            if s>820:continue
            p=np.array([np.interp(s,self.s,self.route[:,k]) for k in range(2)])
            im=self.hull(im,p,0)
        state=g['state'];im=self.spill.wake(im,self.motion,take,t);im=self.hull(im,g['boat_px'],state[2])
        # A single shaft, before the grips. Both hand targets are computed from
        # two fixed distances on this same finite rigid pole.
        actorlayers=[]
        for name,actor in ACTORS.items():
            hands={'hand':np.asarray(actor.j['hand'])-[0,g['gate_lift_px']]} if actor.left else {'hand_front':g['hand_front_px'],'hand_back':g['hand_back_px']}
            rgba,diag=actor.layer(hands);im=over(im,rgba);actorlayers.append((actor,rgba,diag))
        # The hand and its gripped original handle form one rigid local part;
        # the whole shoulder/elbow mesh still drives the surrounding cloth.
        handpoly=np.array([(257,287),(267,281),(295,279),(309,290),(308,305),(298,312),(280,315),(262,306),(256,299)],float)
        hl=np.dstack((SRC,polyalpha(handpoly)))
        hl=cv2.warpAffine(hl,np.array([[1,0,0],[0,1,-g['gate_lift_px']]],float),(W,H))
        im=over(im,hl)
        out=Image.fromarray(im).convert('RGBA');d=ImageDraw.Draw(out,'RGBA')
        tip,end=g['tip_px'],g['pole_end_px']
        d.line([tuple(tip),tuple(end)],fill=(142,109,46,255),width=4)
        d.line([tuple(tip+[-1,0]),tuple(end+[-1,0])],fill=(226,198,128,240),width=1)
        im=np.asarray(out.convert('RGB'))
        actor,rgba,diag=actorlayers[1]
        fingers=np.zeros((H,W),np.uint8)
        for p in [g['hand_front_px'],g['hand_back_px']]:cv2.ellipse(fingers,tuple(np.rint(p).astype(int)),(11,9),-48,0,360,255,-1)
        hand_layer=rgba.copy();hand_layer[:,:,3]=(hand_layer[:,:,3].astype(float)*fingers/255).astype(np.uint8)
        im=over(im,hand_layer)
        return im

    def caption(self,im,title,subtitle='',footer=''):
        out=Image.fromarray(im);d=ImageDraw.Draw(out)
        def center(text,y,font,color):
            box=d.textbbox((0,0),text,font=font);d.text(((W-(box[2]-box[0]))/2,y),text,font=font,fill=color)
        if title:center(title,116,ImageFont.truetype(FONT,36),INK)
        if subtitle:center(subtitle,169,ImageFont.truetype(SANS,17),(113,123,135))
        if footer:center(footer,956,ImageFont.truetype(FONT,22),INK)
        return np.asarray(out)

    def outcome_card(self,im):
        out=Image.fromarray(im);d=ImageDraw.Draw(out,'RGBA')
        font=ImageFont.truetype(SANS,19)
        d.text((590,220),'FLOW: OVER THE EDGE',font=font,fill=(*BLUE,235))
        d.text((590,254),'POLE: OVER THE EDGE',font=font,fill=(*GOLD,235))
        return np.asarray(out.convert('RGB'))

    def frame(self,t):
        if t<2:
            out=Image.fromarray(self.scene('baseline',t-2));d=ImageDraw.Draw(out,'RGBA')
            tip=project(np.array([.58,.245]),.017-.020)
            d.line([(1105,605),(1160,635),tuple(tip)],fill=(134,154,176,170),width=1)
            d.ellipse((tip[0]-3,tip[1]-3,tip[0]+3,tip[1]+3),fill=(186,148,82,220))
            d.text((1033,582),'Low spillway',font=ImageFont.truetype(FONT,18),fill=(*INK,235))
            return self.caption(np.asarray(out),'One low sill. Two ways across.','A shallow flow is already crossing the sill.')
        if t<10:
            return self.caption(self.scene('A',(t-2)*CLOCK),'Open the gate.','Weight edit · a stronger current carries the boat across.')
        if t<11:
            a=self.scene('A',TAKE_END);b=self.scene('B',0);w=float(smooth(t-10))
            return self.caption(np.uint8(a*(1-w)+b*w),'Same starting state.','A second take, with the gate back at its original opening.')
        if t<19:
            return self.caption(self.scene('B',(t-11)*CLOCK),'Push the boat.','Activation steering · the pole pushes the boat out.')
        if t<21:
            return self.caption(self.outcome_card(self.scene('B',TAKE_END)),'Different actions. Both leave the channel.','The same outcome; the paths need not be identical.')
        a=self.frame(20);b=self.frame(0);w=float(smooth(t-21));return np.uint8(a*(1-w)+b*w)

def main():
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--movie',action='store_true');p.add_argument('--fps',type=int,default=24);p.add_argument('--width',type=int,default=1536);p.add_argument('--output',type=Path,default=ROOT/'motion-review.mp4');args=p.parse_args()
    r=Renderer()
    if not args.movie:
        for t in [0,4,7,12,16,18,20]:Image.fromarray(r.frame(t)).save(ROOT/f'frame-{t:02}.jpg',quality=93)
        return
    h=round(args.width*H/W/2)*2
    proc=subprocess.Popen(['ffmpeg','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(args.fps),'-i','-','-an','-vf',f'scale={args.width}:{h}:flags=lanczos','-c:v','libx264','-preset','medium','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart','-y',str(args.output)],stdin=subprocess.PIPE)
    try:
        for i in range(22*args.fps):
            proc.stdin.write(r.frame(i/args.fps).tobytes())
            if i%args.fps==0:print(f'{i/args.fps:.0f}/22 seconds rendered',flush=True)
    finally:proc.stdin.close()
    if proc.wait():raise RuntimeError('ffmpeg failed')

if __name__=='__main__':main()
