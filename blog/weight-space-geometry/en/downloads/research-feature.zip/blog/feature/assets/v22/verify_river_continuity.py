"""Artifact-level checks for the shared upstream visual flow and handoff.

This is not a full-river CFD verification or a spatial-convergence claim.
"""
from pathlib import Path
import hashlib
import json
import numpy as np
from motion import Motion
from river_flow import RiverFlow
from river_tracers import RiverTracers
from render import BOAT_SCALE

ROOT = Path(__file__).resolve().parent


def main():
    motion = Motion()
    flow = RiverFlow(motion)
    tracers = RiverTracers(flow, motion)
    entries = []
    for case in ("baseline", "A", "B"):
        end = float(motion.boats[case][-1, 0])
        for index, trace in enumerate(tracers._traces[case]):
            t = trace["entry_time"]
            if t is None or t > end:
                continue
            step = 1 / 24
            pts = np.array([tracers.frame(case, t + d)[index]["pos_px"]
                            for d in (-step, 0, step)])
            speeds = np.linalg.norm(np.diff(pts, axis=0) / step, axis=1)
            entries.append({"case": case, "boat": index, "time_s": t,
                            "speed_before_after_px_s": speeds.tolist(),
                            "relative_speed_change": float(abs(np.diff(speeds)[0]) / speeds[0])})
    sample_s = np.linspace(0, flow.entry_s, 5)
    speed_samples = {str(t): flow.speed("A", t, sample_s).tolist()
                     for t in (0, .4, .8, 1.2, 2.)}
    join_samples = []
    for case in ("baseline", "A"):
        for t in (0, .4, .8, 1., 2.):
            v = flow.speed(case, t, flow.entry_s + np.array([-.001, .001]))
            join_samples.append({"case": case, "t": t, "gap_px_s": float(abs(np.diff(v)[0]))})
    checks = {
        "boat_visual_scale_exactly_1_2": BOAT_SCALE == 1.2,
        "route_arc_strictly_increasing": bool(np.all(np.diff(flow.s) > 0)),
        "finite_speed_fields": all(np.isfinite(a).all().item() for a in flow.tables.values()),
        "no_entry_position_jump": all(d["entry_position_px_error_max"] < .001 for d in tracers.diagnostics.values()),
        "entry_velocity_mismatch_under_1px_s": all(d["entry_velocity_px_s_jump_max"] < 1 for d in tracers.diagnostics.values()),
        "visible_entry_frame_speed_change_under_5_percent": all(d["relative_speed_change"] < .05 for d in entries),
        "water_speed_continuous_at_join_under_01px_s": all(d["gap_px_s"] < .1 for d in join_samples),
        "no_arbitrary_tracer_removal": all(d["inactive_before_observation"] == 0 for d in tracers.diagnostics.values()),
        "upstream_response_reaches_all_sampled_locations": bool(np.all(flow.speed('A',1.2,sample_s) > 2*flow.speed('baseline',1.2,sample_s))),
    }
    report = {"status": "PASS" if all(checks.values()) else "FAIL",
              "scope": "Visual scale and shared route-time transport; local body handoff. Not global CFD.",
              "checks": checks, "boat_sprite_dimensions_px": {"before": [42,24], "after": [50.4,28.8]},
              "gate_transit_s": .4, "handoff_xy_m": flow.entry_xy.tolist(),
              "speed_samples_upstream_to_downstream_px_s": speed_samples,
              "water_join_samples": join_samples, "visible_boat_entries": entries,
              "tracer_diagnostics": tracers.diagnostics,
              "sources": {n: hashlib.sha256((ROOT/n).read_bytes()).hexdigest()
                          for n in ['river_flow.py','river_tracers.py','water_paint.py','render.py','hydro_surface.py','fluid_fields.npz','boat_states.npz']}}
    (ROOT/'river-continuity-qa.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({"status": report['status'], "checks": checks}, indent=2))
    if not all(checks.values()):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
