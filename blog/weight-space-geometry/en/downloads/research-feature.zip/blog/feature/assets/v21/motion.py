"""One physical-to-camera map; all rendered contact uses this rigid pole."""
from pathlib import Path
import json
import numpy as np
from hybrid import Water
from physics import START, END, RETRACT, WIDTH, pole_y, pole_force
ROOT=Path(__file__).resolve().parent
M=np.array([[850.,-400.],[150.,240.]])
ORIGIN=np.array([840.,562.]);ZPX=np.array([0.,-650.])
POLE_LENGTH=.44;LOWER_GRIP=.24;UPPER_GRIP=.37;VERTICAL=.45
REST_AXIS_3D=np.array([-.019797010761235,-.967068647867624,.253744573688592])
REST_TIP=np.array([1193.1,608.])
def project(xy,z=0.):
    xy=np.asarray(xy)
    return np.stack((xy[...,0]*M[0,0]+xy[...,1]*M[0,1],xy[...,0]*M[1,0]+xy[...,1]*M[1,1]),axis=-1)+ORIGIN+np.asarray(z)[...,None]*ZPX
def smooth(x):x=np.clip(x,0,1);return x*x*(3-2*x)
def axis_project(d):return M@d[:2]+ZPX*d[2]
def slerp(a,b,t):
    a=a/np.linalg.norm(a);b=b/np.linalg.norm(b)
    angle=np.arccos(np.clip(a@b,-1,1))
    if angle<1e-7:return a
    return (np.sin((1-t)*angle)*a+np.sin(t*angle)*b)/np.sin(angle)

class Motion:
    def __init__(self):
        self.boats=dict(np.load(ROOT/'boat_states.npz'))
        self.water=Water()
        self.entry_y=self.boat('B',START)[1]
    def boat(self,take,t):
        a=self.boats[take];return np.array([np.interp(t,a[:,0],a[:,k]) for k in range(1,7)])
    def contact(self,t):
        state=self.boat('B',t)
        force=pole_force(t,state,self.entry_y)
        return dict(t=float(t),force_N=float(force),gap_m=float(state[1]-WIDTH/2-pole_y(t,self.entry_y)) if START<=t<=RETRACT else None,active=bool(force>1e-8))
    def geometry(self,take,t):
        state=self.boat(take,t)
        z=float(self.water.surface_z(take,t,state[None,:2])[0])
        pboat=project(state[:2],z)
        push_axis=np.array([0.,-np.sqrt(1-VERTICAL**2),VERTICAL])
        def commanded_tip(t):
            st=self.boat('B',t)
            xy=np.array([st[0],pole_y(t,self.entry_y)])
            zz=float(self.water.surface_z('B',t,st[None,:2])[0])
            return project(xy,zz)
        if take=='B':
            if t<START:
                mix=float(smooth((t-1.3)/(START-1.3)))
                tip=(1-mix)*REST_TIP+mix*commanded_tip(START)
                axis3d=slerp(REST_AXIS_3D,push_axis,mix)
            elif t<=RETRACT:
                tip=commanded_tip(t);axis3d=push_axis
            else:
                mix=float(smooth((t-RETRACT)/1.3))
                tip=(1-mix)*commanded_tip(RETRACT)+mix*REST_TIP
                axis3d=slerp(push_axis,REST_AXIS_3D,mix)
        else:tip=REST_TIP;axis3d=REST_AXIS_3D
        axis=axis_project(axis3d)
        return dict(state=state,boat_px=pboat,water_z_m=z,tip_px=tip,
                    pole_end_px=tip+POLE_LENGTH*axis,
                    hand_front_px=tip+LOWER_GRIP*axis,hand_back_px=tip+UPPER_GRIP*axis,
                    pole_length_m=POLE_LENGTH,pole_axis_3d=axis3d,
                    contact=self.contact(t) if take=='B' else None,
                    gate_lift_px=18*float(smooth(t/1.6)) if take=='A' else 0.)

if __name__=='__main__':
    from rig.mesh import ACTORS
    m=Motion();report=[]
    for t in np.linspace(0,8,193):
        g=m.geometry('B',t)
        d,diag=ACTORS['right_operator'].targets({'hand_front':g['hand_front_px'],'hand_back':g['hand_back_px']})
        report.append(dict(t=float(t),hand_front=g['hand_front_px'].tolist(),hand_back=g['hand_back_px'].tolist(),diag=diag))
    (ROOT/'pole-grip-check.json').write_text(json.dumps(report,separators=(',',':')))
    print('checked',len(report),'pole-driven poses')
