"""One physical-to-camera map; all rendered contact uses this rigid pole."""
from pathlib import Path
import json
import numpy as np
from hybrid import Water
from boats import START, END, RETRACT, WIDTH, pole_y, STIFFNESS
ROOT=Path(__file__).resolve().parent
M=np.array([[500.,-400.],[100.,240.]])
ORIGIN=np.array([965.,604.]);ZPX=np.array([0.,-650.])
POLE_LENGTH=.57;LOWER_GRIP=.36;UPPER_GRIP=.49;VERTICAL=.60
REST_AXIS_3D=np.array([-.019797010761235,-.967068647867624,.253744573688592])
REST_TIP=np.array([1193.1,608.])
CAMERA=np.column_stack((M,ZPX))
CAMERA_PINV=np.linalg.pinv(CAMERA)
CAMERA_NULL=np.linalg.svd(CAMERA)[2][-1]
REST_PROJECTED_UNIT_LENGTH=np.linalg.norm(CAMERA@REST_AXIS_3D)
POLE_LENGTH_PX=POLE_LENGTH*REST_PROJECTED_UNIT_LENGTH
REST_LIFT_SIGN=1. if REST_AXIS_3D@CAMERA_NULL>=0 else -1.

def rigid_staged_axis(desired):
    """Keep the rest shaft's on-screen length while rotating a unit 3D rod.

    The illustration's oblique camera strongly changes projected length under
    the former pitch animation. Choose another 3D pose with the same image
    direction, fixed image length, and unit world length. The camera-nullspace
    branch is fixed by the rest pose, so the lift cannot flip between frames.
    This is a staging constraint; it does not change the 2D contact solver.
    """
    image_axis=CAMERA@desired
    image_axis*=REST_PROJECTED_UNIT_LENGTH/np.linalg.norm(image_axis)
    parallel=CAMERA_PINV@image_axis
    remaining=1.-parallel@parallel
    if remaining < -1e-10:
        raise ValueError('Fixed-length projected pole has no unit 3D lift')
    return parallel+REST_LIFT_SIGN*np.sqrt(max(remaining,0.))*CAMERA_NULL
def project(xy,z=0.):
    xy=np.asarray(xy)
    return np.stack((xy[...,0]*M[0,0]+xy[...,1]*M[0,1],xy[...,0]*M[1,0]+xy[...,1]*M[1,1]),axis=-1)+ORIGIN+np.asarray(z)[...,None]*ZPX
def smooth(x):x=np.clip(x,0,1);return x*x*(3-2*x)
def axis_project(d):return M@d[:2]+ZPX*d[2]
def slerp(a,b,t):
    a=a/np.linalg.norm(a);b=b/np.linalg.norm(b)
    angle=np.arccos(np.clip(a@b,-1,1))
    if angle<1e-7:return a
    return (np.sin((1-t)*angle)*a+np.sin(t*angle)*b)/np.sin(angle)

class Motion:
    def __init__(self):
        self.boats=dict(np.load(ROOT/'boat_states.npz'))
        self.water=Water()
        self.entry_y=self.boat('B',START)[1]
        self.brace_times=np.arange(0,8+1/120,1/120)
        raw=np.array([self.contact(t)['force_N'] for t in self.brace_times])
        self.brace_load=np.zeros_like(raw)
        alpha=1-np.exp(-(1/120)/.10)
        for i in range(1,len(raw)):
            self.brace_load[i]=self.brace_load[i-1]+alpha*(raw[i]-self.brace_load[i-1])
        self.brace_load/=max(float(self.brace_load.max()),1e-12)
    def boat(self,take,t):
        a=self.boats[take];return np.array([np.interp(t,a[:,0],a[:,k]) for k in range(1,7)])
    def contact(self,t):
        state=self.boat('B',t)
        gap=state[1]-WIDTH/2*np.cos(state[2])-pole_y(t,self.entry_y)
        force=STIFFNESS*max(-gap,0.)/max(np.cos(state[2]),.2) if START<=t<=RETRACT else 0.
        return dict(t=float(t),force_N=float(force),gap_m=float(gap) if START<=t<=RETRACT else None,active=bool(force>1e-8))
    def body_cue(self,take,t):
        if take!='B':return dict(plant=0.,drive=0.,load=0.,release=0.)
        release=float(smooth((t-RETRACT)/1.3))
        return dict(plant=float(smooth((t-(START-1.1))/1.1))*(1-release),
                    drive=float(smooth((t-START)/(RETRACT-START)))*(1-release),
                    load=float(np.interp(t,self.brace_times,self.brace_load)),release=release)
    def geometry(self,take,t):
        state=self.boat(take,t)
        z=float(self.water.surface_z(take,t,state[None,:2])[0])
        pboat=project(state[:2],z)
        theta=self.boat('B',np.clip(t,START,RETRACT))[2]
        grip_mix=1. if START<=t<=RETRACT else float(smooth((t-(START-1.1))/1.1)) if t<START else 1-float(smooth((t-RETRACT)/1.3))
        if take!='B':grip_mix=0.
        front=.24+.12*grip_mix;back=.37+.12*grip_mix
        push_axis=np.array([np.sin(theta)*np.sqrt(1-VERTICAL**2),-np.cos(theta)*np.sqrt(1-VERTICAL**2),VERTICAL])
        def commanded_tip(t):
            st=self.boat('B',t)
            xy=np.array([st[0]+WIDTH/2*np.sin(st[2]),pole_y(t,self.entry_y)])
            zz=float(self.water.surface_z('B',t,st[None,:2])[0])
            return project(xy,zz)
        if take=='B':
            if t<START:
                mix=float(smooth((t-(START-1.1))/1.1))
                tip=(1-mix)*REST_TIP+mix*commanded_tip(START)
                axis3d=slerp(REST_AXIS_3D,push_axis,mix)
            elif t<=RETRACT:
                tip=commanded_tip(t);axis3d=push_axis
            else:
                mix=float(smooth((t-RETRACT)/1.3))
                tip=(1-mix)*commanded_tip(RETRACT)+mix*REST_TIP
                axis3d=slerp(push_axis,REST_AXIS_3D,mix)
        else:tip=REST_TIP;axis3d=REST_AXIS_3D
        axis3d=rigid_staged_axis(axis3d)
        axis=axis_project(axis3d)
        return dict(state=state,boat_px=pboat,water_z_m=z,tip_px=tip,
                    pole_end_px=tip+POLE_LENGTH*axis,
                    hand_front_px=tip+front*axis,hand_back_px=tip+back*axis,
                    pole_length_m=POLE_LENGTH,pole_axis_3d=axis3d,
                    pole_vector_3d=POLE_LENGTH*axis3d,
                    grip_distances_m=(front,back),
                    right_body_cue=self.body_cue(take,t),
                    contact=self.contact(t) if take=='B' else None,
                    gate_lift_px=18*float(smooth(t/.8)) if take=='A' else 0.)

if __name__=='__main__':
    from rig.mesh import ACTORS
    m=Motion();report=[]
    for t in np.linspace(0,8,193):
        g=m.geometry('B',t)
        d,diag=ACTORS['right_operator'].targets({'hand_front':g['hand_front_px'],'hand_back':g['hand_back_px']},g['right_body_cue'])
        report.append(dict(t=float(t),hand_front=g['hand_front_px'].tolist(),hand_back=g['hand_back_px'].tolist(),diag=diag))
    (ROOT/'pole-grip-check.json').write_text(json.dumps(report,separators=(',',':')))
    print('checked',len(report),'pole-driven poses')
