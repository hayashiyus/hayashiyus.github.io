"""Low-text empirical plates for the reconstruction and controls results.

The two figures intentionally keep reported benchmark numbers separate from
the E1 numerical check and show every E2 measured grid point.  No fitted
curves, confidence intervals, or invented intermediate observations appear.
"""
from pathlib import Path
import html
import hashlib
import json
import math
import subprocess

import math_typesetting as typeset

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "assets" / "v24" / "measurements"
DATA = json.loads((ROOT.parent / "data" / "measurements.json").read_text())
PAPER = "#fffefc"
INK, MUT = "#263653", "#72829a"
BLUE, LAV, GOLD, CORAL = "#4c83be", "#9892c7", "#c6a164", "#c47d7a"


def sci_tex(value):
    """Compact TeX label without relying on Unicode superscripts."""
    mantissa, exponent = f"{value:.2e}".split("e")
    return rf"{float(mantissa):.2g}\times10^{{{int(exponent)}}}"


class SVG:
    def __init__(self, title, subtitle, tag):
        self.a = [f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1600" height="1000" viewBox="0 0 1600 1000"><rect width="1600" height="1000" fill="{PAPER}"/>']
        self.text(64, 45, "THE GEOMETRY OF WEIGHT-SPACE PROGRAMMING", 15, MUT, spacing=3)
        self.text(1536, 45, tag, 14, MUT, anchor="end")
        self.text(64, 108, title, 46, INK, True)
        self.text(66, 151, subtitle, 23, MUT)
        self.line((64, 178), (1536, 178), "#e0e8f3", 1)

    def text(self, x, y, s, size=24, color=INK, bold=False, anchor="start", spacing=0):
        self.a.append(f'<text x="{x:.2f}" y="{y:.2f}" font-family="Georgia, serif" font-size="{size}" font-weight="{700 if bold else 400}" fill="{color}" text-anchor="{anchor}" letter-spacing="{spacing}">{html.escape(str(s))}</text>')

    def math(self, x, y, tex, size=24, color=INK, anchor="start", max_width=None):
        return self.a.append(typeset.svg_math(x, y, tex, size, color, anchor, max_width))

    def line(self, p, q, color=BLUE, width=2, dash=None, opacity=1):
        self.path([p, q], color, width, dash, opacity)

    def path(self, pts, color=BLUE, width=2, dash=None, opacity=1, fill="none", close=False):
        d = "M" + " L".join(f"{x:.2f},{y:.2f}" for x, y in pts) + (" Z" if close else "")
        extra = f' stroke-dasharray="{dash}"' if dash else ""
        self.a.append(f'<path d="{d}" fill="{fill}" stroke="{color}" stroke-width="{width}" stroke-linecap="round" stroke-linejoin="round" opacity="{opacity}"{extra}/>')

    def circle(self, x, y, r, fill=BLUE, stroke=PAPER, width=1):
        self.a.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>')

    def box(self, x, y, w, h, fill="#f2f6fc", r=18, stroke="none"):
        self.a.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}"/>')

    def finish(self):
        return "".join(self.a) + "</svg>"


def axis(s, box, xr, yr, xticks, yticks, xlabel, ylabel, logx=False, logy=False):
    x, y, w, h = box
    import math
    def fx(v):
        a = (math.log10(v) - math.log10(xr[0])) / (math.log10(xr[1]) - math.log10(xr[0])) if logx else (v - xr[0]) / (xr[1] - xr[0])
        return x + w * a
    def fy(v):
        a = (math.log10(v) - math.log10(yr[0])) / (math.log10(yr[1]) - math.log10(yr[0])) if logy else (v - yr[0]) / (yr[1] - yr[0])
        return y + h - h * a
    for v, label in yticks:
        yy = fy(v); s.line((x, yy), (x + w, yy), "#e2e9f3", 1); s.math(x - 14, yy + 6, label, 17, MUT, "end")
    for v, label in xticks:
        s.math(fx(v), y + h + 31, label, 18, MUT, "middle")
    s.line((x, y), (x, y + h), "#9caec6", 1.3); s.line((x, y + h), (x + w, y + h), "#9caec6", 1.3)
    if xlabel:
        s.math(x + w / 2, y + h + 68, xlabel, 20, MUT, "middle")
    if ylabel:
        s.math(x, y - 22, ylabel, 20, MUT)
    return fx, fy


def reconstruction(t=1):
    """Reported benchmark beside the separate E1 reconstruction check."""
    s = SVG("A score, then a numerical check.", "The reported benchmark and our reconstruction are different evidence.", "03 / RECONSTRUCTION")
    s.box(70, 220, 690, 610, "#f5f8fc")
    s.text(112, 274, "REPORTED BENCHMARK", 18, MUT, True, spacing=2)
    s.text(112, 323, "MATH-500 accuracy", 32, INK, True)
    fx, fy = axis(s, (145, 390, 540, 335), (-.5, 1.5), (0, 60), [(0, r"\text{base}"), (1, r"\text{edited}")], [(0, r"0\%"), (20, r"20\%"), (40, r"40\%"), (60, r"60\%")], "", r"\text{accuracy}")
    vals = [DATA["source_report"]["math500"]["base_accuracy"] * 100, DATA["source_report"]["math500"]["edited_accuracy"] * 100]
    for i, value in enumerate(vals):
        s.box(fx(i) - 62, fy(value), 124, fy(0) - fy(value), BLUE if i else "#b8c8dc", 8)
        s.math(fx(i), fy(value) - 16, rf"{value:.1f}\%", 30, INK, "middle")
    s.text(112, 790, "Authors' report · not a full reproduction", 18, MUT)

    s.box(840, 220, 690, 610, "#f5f8fc")
    s.text(882, 274, "E1 NUMERICAL CHECK", 18, MUT, True, spacing=2)
    s.text(882, 323, "40 fixed prefixes", 32, INK, True)
    e = DATA["e1"]["e1"]
    panels = [(895, r"\max\,|\Delta\mathrm{logit}|", (1e-6, 3), "logit units", "max_logit_difference"), (1210, r"\max\,\mathrm{KL}", (1e-12, 1), "nats", "max_kl")]
    for x0, title, yr, unit, key in panels:
        xx, yy = axis(s, (x0, 410, 245, 290), (-.5, 1.5), yr, [(0, r"\mathrm{FP32}"), (1, r"\mathrm{BF16}")], [(yr[0], r"10^{-6}" if yr[0] == 1e-6 else r"10^{-12}"), (yr[1], r"3" if yr[1] == 3 else r"1")], "", title, logy=True)
        s.text(x0 + 245, 388, f"{unit} · log scale", 14, MUT, anchor="end")
        for i, cond in enumerate(("e1fp32", "e1")):
            val = DATA["e1"][cond][key]
            s.line((xx(i), yy(yr[0])), (xx(i), yy(val)), BLUE if i == 0 else LAV, 6)
            s.circle(xx(i), yy(val), 9, BLUE if i == 0 else LAV)
            s.math(xx(i), yy(val) - 18, sci_tex(val), 20, INK, "middle")
        # The unit is already carried by the panel title/footer; keeping this
        # row clear prevents collision with the FP32/BF16 labels.
    s.math(1185, 790, r"\text{BF16 residual} > \text{FP32 residual}", 22, INK, "middle")
    return s


def controls(t=1):
    """E2 curves at the five observed gains, with exact target and markers."""
    s = SVG("The coarse grid misses the target.", "Three controls, five tested gains; lines join actual points.", "04 / CONTROLS")
    fx, fy = axis(s, (130, 300, 980, 490), (.23, 4.4), (.002, 10), [(.25, ".25"), (.5, ".5"), (1, "1"), (2, "2"), (4, "4")], [(.01, ".01"), (.1, ".1"), (1, "1"), (10, "10")], r"\text{gain }g", r"-\,\text{mean }\Delta\log p\;\text{(nats)}", True, True)
    colors = {"constant": BLUE, "shuffle": LAV, "random": GOLD}
    labels = {"constant": "constant", "shuffle": "shuffled gate", "random": "random direction"}
    for name, rec in DATA["e2"]["calibration"].items():
        points = sorted((float(g), -float(v)) for g, v in rec["curve"].items())
        c = colors[name]
        s.path([(fx(g), fy(v)) for g, v in points], c, 4)
        for g, value in points:
            s.circle(fx(g), fy(value), 7, c)
        chosen = float(rec["gain"])
        selected = -float(rec["curve"][str(rec["gain"])])
        s.circle(fx(chosen), fy(selected), 13, PAPER, c, 3)
    target = -float(DATA["e2"]["calibration"]["constant"]["target"])
    s.line((130, fy(target)), (1110, fy(target)), CORAL, 2, "8 7")
    s.math(143, fy(target) - 14, rf"\text{{target}}={target:.3f}", 22, CORAL)
    for i, name in enumerate(("constant", "shuffle", "random")):
        x = 170 + i * 300; s.circle(x, 248, 7, colors[name]); s.text(x + 19, 255, labels[name], 21, INK)
    s.text(130, 842, "filled = measured grid point", 18, MUT)
    s.text(540, 842, "outlined = selected gain", 18, MUT)
    # A visual zoom of the measured endpoints that bracket the target.  The
    # gap is deliberately shown as an interval between observed points, never
    # as a fabricated matching gain.
    s.box(1160, 220, 360, 620, "#f2f6fc")
    s.text(1200, 274, "TARGET BRACKETS", 18, MUT, True, spacing=2)
    gain_x = {0.25: 1220, 0.5: 1285, 1.0: 1350, 2.0: 1415, 4.0: 1480}
    for row, name in enumerate(("constant", "shuffle", "random")):
        rec = DATA["e2"]["calibration"][name]; c = colors[name]
        y0 = 315 + row * 180
        values = {float(g): -float(v) for g, v in rec["curve"].items()}
        s.text(1200, y0 - 20, labels[name], 20, INK, True)
        ordered = sorted(values)
        lower = max(g for g in ordered if values[g] < target)
        upper = min(g for g in ordered if values[g] > target)
        # Endpoints and target use the same local logarithmic transform.
        # Each inset has its own range; no data are clipped to fit the card.
        lo,hi=math.log(values[lower]),math.log(values[upper])
        map_y=lambda value:y0+90-75*(math.log(value)-lo)/(hi-lo)
        target_y=map_y(target)
        lower_y,upper_y=map_y(values[lower]),map_y(values[upper])
        assert upper_y < target_y < lower_y
        s.line((1215, target_y), (1490, target_y), CORAL, 2, "6 5")
        s.math(1490, target_y - 8, r"\text{target}", 15, CORAL, "end")
        s.line((gain_x[lower], lower_y), (gain_x[upper], upper_y), c, 4)
        s.circle(gain_x[lower], lower_y, 7, c)
        s.circle(gain_x[upper], upper_y, 7, c)
        s.line((gain_x[lower], y0 + 101), (gain_x[upper], y0 + 101), c, 1.5)
        s.math((gain_x[lower] + gain_x[upper]) / 2, y0 + 122, rf"{lower:g}\,\text{{–}}\,{upper:g}", 16, c, "middle")
    s.text(1200, 824, "mini: measured · main rings: selected", 15, MUT)
    return s


def verify():
    assert DATA["source_report"]["math500"]["base_accuracy"] == 0.079
    assert DATA["source_report"]["math500"]["edited_accuracy"] == 0.481
    vals = [DATA["source_report"]["math500"]["base_accuracy"] * 100, DATA["source_report"]["math500"]["edited_accuracy"] * 100]
    assert DATA["e1"]["e1"]["n"] == DATA["e1"]["e1fp32"]["n"] == 40
    calibration = DATA["e2"]["calibration"]
    assert set(calibration) == {"constant", "shuffle", "random"}
    assert all(len(rec["curve"]) == 5 and rec["match_failure"] for rec in calibration.values())
    assert all(float(rec["gain"]) in {0.25, 0.5, 1.0, 2.0, 4.0} for rec in calibration.values())
    OUT.mkdir(parents=True, exist_ok=True)
    labels = {}
    with typeset.collect():
        reconstruction(); controls()
    labels["requested_labels"] = list(typeset.REQUESTS.values())
    (OUT / "proposed_math_labels.json").write_text(json.dumps(labels, indent=2) + "\n")
    source_bytes = (ROOT.parent / "data" / "measurements.json").read_bytes()
    model = {
        "schema": 1,
        "source": "blog/data/measurements.json",
        "source_sha256": hashlib.sha256(source_bytes).hexdigest(),
        "classification": "empirical report and numerical probes; connecting lines join observations",
        "reconstruction": {
            "reported_math500_accuracy_percent": {"base": vals[0], "edited": vals[1]},
            "e1_n": {"FP32": DATA["e1"]["e1fp32"]["n"], "BF16": DATA["e1"]["e1"]["n"]},
            "plotted": {dtype: {key: DATA["e1"][cond][key] for key in ("max_logit_difference", "max_kl")} for dtype, cond in (("FP32", "e1fp32"), ("BF16", "e1"))},
        },
        "controls": {
            "scope": DATA["e2"]["scope"],
            "n_calibration": DATA["e2"]["calibration_repetitive_cases"],
            "target_positive": -DATA["e2"]["calibration"]["constant"]["target"],
            "arms": {name: {"gains": [float(g) for g in sorted(rec["curve"], key=float)], "values_positive": [-float(rec["curve"][g]) for g in sorted(rec["curve"], key=float)], "selected_gain": rec["gain"], "match_failure": rec["match_failure"]} for name, rec in DATA["e2"]["calibration"].items()},
            "intersection_note": "No empirical match at plotted intersections; no extra gains are inferred.",
        },
    }
    (OUT / "model.json").write_text(json.dumps(model, indent=2) + "\n")
    captions = {
        "reconstruction": {"en": "Reported MATH-500 accuracy (7.9% base, 48.1% edited) is shown separately from our E1 numerical check on 40 fixed prefixes. E1 compares FP32 and BF16 residuals; it is not a full benchmark reproduction.", "ja": "報告されたMATH-500精度（base 7.9%、edited 48.1%）と、40個の固定prefixで行ったE1数値チェックを分けて示す。E1はFP32とBF16の残差比較であり、ベンチマーク全体の再現ではない。", "alt_en": "Two-panel chart: the reported benchmark rises from 7.9% to 48.1%; separate FP32 and BF16 E1 points show residual logit and KL changes.", "alt_ja": "2パネル図。報告ベンチマークは7.9%から48.1%へ上がり、別パネルでE1のFP32/BF16のlogit残差とKL残差を示す。"},
        "controls": {"en": "E2 shows three controls at five discrete gains. Lines join actual measured points; the exact target is marked, selected gains are outlined, and no empirical match is observed at the plotted intersections.", "ja": "E2は3種類のcontrolを5つの離散gainで示す。線は実測点を結ぶ。exact targetを破線、選択gainを輪郭付き点で示し、プロット上の交差点に実測matchはない。", "alt_en": "Log-log chart of three measured control curves at five gains, with a horizontal target and outlined selected points; connecting lines join observations and do not add measurements.", "alt_ja": "5つのgainで測定した3本のcontrol曲線、水平target線、輪郭付きの選択点を示すlog-log図。接続線は観測点を結ぶだけで、新しい測定値を追加しない。"}}
    (OUT / "captions_alt.json").write_text(json.dumps(captions, ensure_ascii=False, indent=2) + "\n")
    print("v24 invariants: PASS")


def save():
    OUT.mkdir(parents=True, exist_ok=True)
    for name, figure in (("reconstruction", reconstruction), ("controls", controls)):
        svg = figure().finish()
        (OUT / f"{name}.svg").write_text(svg)
        subprocess.run(["rsvg-convert", "-o", str(OUT / f"{name}.png"), str(OUT / f"{name}.svg")], check=True)


if __name__ == "__main__":
    verify()
    save()
