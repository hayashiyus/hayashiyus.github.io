"""Original editorial atlas. SVG keeps text, paths, meshes and charts editable.
Raster allegories were generated in Figma; all numerical geometry is computed here.
No generated surface is represented as a measured Qwen manifold.
"""
from pathlib import Path
import base64, html, json, math, subprocess, io
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent; O=R/'assets'/'v3'; O.mkdir(parents=True,exist_ok=True)
D=json.loads((R.parent/'data/measurements.json').read_text())
INK='#1d3154'; MUT='#687b96'; BLUE='#477fca'; LAV='#9795ce'; GOLD='#d3a257'; CORAL='#cb817e'; PALE='#f1f5fc'
class SVG:
 def __init__(self,title,subtitle,tag):
  self.a=[f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1600" height="1000" viewBox="0 0 1600 1000"><rect width="1600" height="1000" fill="#fff"/>']
  self.text(64,45,'THE GEOMETRY OF WEIGHT-SPACE PROGRAMMING',15,MUT,False,'sans-serif',spacing=3)
  self.text(1536,45,tag,14,MUT,False,'sans-serif','end')
  self.text(64,108,title,46,INK,True)
  self.text(66,151,subtitle,23,MUT)
  self.line((64,178),(1536,178),'#e0e8f3',1)
 def text(self,x,y,s,size=24,color=INK,bold=False,font='Georgia',anchor='start',spacing=0):
  self.a.append(f'<text x="{x:.2f}" y="{y:.2f}" font-family="{font}" font-size="{size}" font-weight="{700 if bold else 400}" fill="{color}" text-anchor="{anchor}" letter-spacing="{spacing}">{html.escape(str(s))}</text>')
 def lines(self,x,y,ls,size=24,color=MUT,dy=31):
  for i,s in enumerate(ls):self.text(x,y+i*dy,s,size,color)
 def line(self,p,q,c=BLUE,w=2,dash=None,opacity=1):self.path([p,q],c,w,dash,opacity)
 def path(self,pts,c=BLUE,w=2,dash=None,opacity=1,fill='none',close=False):
  ds='M'+' L'.join(f'{p[0]:.2f},{p[1]:.2f}' for p in pts)+(' Z' if close else '')
  self.a.append(f'<path d="{ds}" fill="{fill}" stroke="{c}" stroke-width="{w}" stroke-linecap="round" stroke-linejoin="round" opacity="{opacity}"'+(f' stroke-dasharray="{dash}"' if dash else '')+'/>')
 def circle(self,x,y,r=6,c=BLUE,stroke='white',w=1): self.a.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{r}" fill="{c}" stroke="{stroke}" stroke-width="{w}"/>')
 def box(self,x,y,w,h,c=PALE,r=16):self.a.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{c}"/>')
 def image(self,p,x,y,w,h):
  b=base64.b64encode(Path(p).read_bytes()).decode();self.a.append(f'<image x="{x}" y="{y}" width="{w}" height="{h}" preserveAspectRatio="xMidYMid meet" xlink:href="data:image/png;base64,{b}"/>')
 def arrow(self,p,q,c=BLUE,w=3):
  self.line(p,q,c,w);v=np.array(q)-p;v=v/np.linalg.norm(v);n=np.array([-v[1],v[0]]);b=np.array(q)-v*12
  self.path([q,b+n*5,b-n*5],c,1,fill=c,close=True)
 def number(self,x,y,n):self.circle(x,y,19,BLUE,BLUE);self.text(x,y+7,str(n),23,'white',False,anchor='middle')
 def footer(self,main,sub):
  self.box(48,900,1504,62,'#edf2fa',12);self.text(800,939,main,30,INK,True,anchor='middle');self.text(800,985,sub,15,MUT,anchor='middle')
 def finish(self):return ''.join(self.a)+'</svg>'
def save(name,s,frames=None):
 (O/f'{name}.svg').write_text(s.finish());subprocess.run(['rsvg-convert','-o',str(O/f'{name}.png'),str(O/f'{name}.svg')],check=True)
 if frames:
  ims=[]
  for i in range(frames[0]):
   raw=frames[1](i/(frames[0]-1)).finish().encode();png=subprocess.check_output(['rsvg-convert','-w','1120'],input=raw)
   ims.append(Image.open(io.BytesIO(png)).convert('RGB'))
  palette=ims[0].quantize(colors=256)
  ims=[im.quantize(palette=palette,dither=Image.Dither.NONE) for im in ims]
  ims[0].save(O/f'{name}.gif',save_all=True,append_images=ims[1:],duration=frames[2],loop=0,optimize=True)
 print(name,flush=True)

def proj(points,box,scale=(1,1,1)):
 p=np.asarray(points)*np.array(scale);x,y,z=np.moveaxis(p,-1,0)
 # Orthographic scientific projection; identical transform for surface and trajectories.
 return np.stack([box[0]+box[2]*(.72*x-.56*y),box[1]+box[3]*(.26*x+.35*y-.82*z)],-1)
def mesh(s,X,Y,Z,box,scale=(1,1,1),palette=(182,204,235)):
 pts=np.stack([X,Y,Z],-1);xy=proj(pts,box,scale); ny,nx=X.shape;faces=[]
 for i in range(ny-1):
  for j in range(nx-1):
   ids=[(i,j),(i,j+1),(i+1,j+1),(i+1,j)]
   if not all(np.isfinite(Z[a,b]) for a,b in ids):continue
   pp=np.array([pts[a,b] for a,b in ids]);depth=np.mean(pp[:,0]+pp[:,1]+.2*pp[:,2]);faces.append((depth,ids))
 for depth,ids in sorted(faces,key=lambda x:x[0]):
  q=[xy[a,b] for a,b in ids]; pp=np.array([pts[a,b] for a,b in ids])*np.array(scale)
  n=np.cross(pp[1]-pp[0],pp[3]-pp[0]); n=n/(np.linalg.norm(n)+1e-12)
  light=np.array([-.3,-.4,.866]); lam=.40+.60*abs(float(n@light))
  col=np.round(255+(np.array(palette)-255)*lam).astype(int)
  s.path(q,'#d9e2f1',.20,opacity=.83,fill=f'rgb({col[0]},{col[1]},{col[2]})',close=True)
 # Fine, continuous grid lines, not arbitrary decorative trajectories.
 for row in range(0,ny,3):
  p=xy[row][np.isfinite(Z[row])]
  if len(p)>1:s.path(p,'#6b8ebc',.7,opacity=.42)
 for col in range(0,nx,3):
  p=xy[:,col][np.isfinite(Z[:,col])]
  if len(p)>1:s.path(p,'#b0a8cd',.7,opacity=.55)
 return xy

def cover(t=.5):
 s=SVG('How do you turn a vast machine?','Astra found a small interface inside Qwen. Information geometry explains the cost of using it.','01 / ORIGINAL ALLEGORY')
 s.image(R/'art/whale-manifold.png',12,245,1070,669)
 s.text(65,228,'Observe the failure. Find the handle.',27,INK,True)
 # Fine editorial leaders anchor to illustrated features, not fake empirical coordinates.
 for label,p,q in [('repeated trajectory',(290,510),(95,331)),('structured intervention',(540,587),(589,792)),('changed continuation',(974,418),(803,293))]:
  s.line(p,q,'#8ea7ca',1.3);s.circle(*p,4,GOLD);s.text(q[0],q[1]-12,label,19,MUT)
 rail=[('Find a tractable failure',['85 of 96 initial trials reached','the generation cap. The log','made the failure observable.']),('Change two writing paths',['Two MLP down-projections.','A direction, selected columns,','and a tested intervention gain.']),('Measure the behavioral move',['KL measures output change.','Fisher describes its local cost;','it did not run Astra’s search.'])]
 for i,(title,ls) in enumerate(rail):
  y=220+i*217;s.box(1090,y,455,192,'#f3f6fb');s.number(1120,y+34,i+1);s.text(1153,y+40,title,25,INK,True);s.lines(1120,y+87,ls,22,dy=30)
 s.text(1120,870,'50 evaluation API calls ≠ 50 forward passes.',17,MUT)
 # Animated attention marker follows a purely illustrative trace and is labeled as such.
 x=370+560*t;y=570-150*t+28*np.sin(2*np.pi*t);s.circle(x,y,11,GOLD,'white',2)
 s.footer('A small interface can redirect a large learned system.','Original Figma-generated allegory • curves are schematic • search facts: public Astra log, not new measurements')
 return s

def anatomy(t=.7):
 s=SVG('Change the writer. Change the state.','A rank-one weight edit executes a state-dependent activation intervention.','02 / EXACT IDENTITY + ALLEGORY')
 s.image(R/'art/two-controls-one-light.png',35,185,1030,580)
 s.box(1080,210,460,563,'#f4f6fb');s.number(1117,248,1);s.text(1150,256,'The stored program',29,INK,True)
 s.text(1120,319,'ΔW = d kᵀ',44,BLUE);s.lines(1120,369,['d chooses the write direction.','k reads the current activation.'],23)
 s.number(1117,460,2);s.text(1150,468,'The runtime action',29,INK,True)
 s.text(1120,534,'Δh(x) = d [kᵀa(x)]',32,BLUE);s.lines(1120,587,['One fixed edit; different states','produce different magnitudes','and can reverse the sign.'],24)
 s.text(108,788,'weight-space instruction',26,INK,True);s.arrow((470,780),(760,780),BLUE,3);s.text(802,788,'activation-space execution',26,INK,True)
 # Exact signed gate demo, s(t) in [-1,1].
 g=np.sin(2*np.pi*t);s.line((260,842),(1010,842),'#c7d5e8',2);s.circle(635,842,5,INK);s.arrow((635,842),(635+250*g+(1e-8 if abs(g)<1e-9 else 0),842),GOLD,5);s.text(1095,844,f'gate  s = {g:+.2f}',26,MUT)
 s.footer('The gate is not added by a new controller. It is already in the multiplication.','Optical bench: Figma-generated allegory • signed-gate motion: exact toy identity • no claim of a measured optical mechanism')
 return s

def axis(s,box,xrange,yrange,xt,yt,xlabel,ylabel,logx=False,logy=False):
 x,y,w,h=box
 fx=lambda v: x+w*((math.log10(v)-math.log10(xrange[0]))/(math.log10(xrange[1]/xrange[0])) if logx else (v-xrange[0])/(xrange[1]-xrange[0]))
 fy=lambda v: y+h-h*((math.log10(v)-math.log10(yrange[0]))/(math.log10(yrange[1]/yrange[0])) if logy else (v-yrange[0])/(yrange[1]-yrange[0]))
 for v,label in yt:
  yy=fy(v);s.line((x,yy),(x+w,yy),'#e2e9f3',1);s.text(x-14,yy+6,label,18,MUT,anchor='end')
 for v,label in xt:s.text(fx(v),y+h+31,label,19,MUT,anchor='middle')
 s.line((x,y),(x,y+h),'#a6b8d0',1);s.line((x,y+h),(x+w,y+h),'#a6b8d0',1)
 s.text(x+w/2,y+h+68,xlabel,21,MUT,anchor='middle');s.text(x,y-23,ylabel,21,MUT)
 return fx,fy

def reconstruction():
 s=SVG('An impressive score. A different kind of check.','The original benchmark and our numerical reconstruction answer different questions.','03 / REPORTED + MEASURED')
 s.number(88,231,1);s.text(120,240,'What the authors reported',31,INK,True)
 fx,fy=axis(s,(120,340,450,370),(-.5,1.5),(0,60),[(0,'Base'),(1,'Edited')],[(0,'0%'),(20,'20%'),(40,'40%'),(60,'60%')],'MATH-500 accuracy','Original authors’ result')
 for i,v in enumerate([D['source_report']['math500']['base_accuracy']*100,D['source_report']['math500']['edited_accuracy']*100]):
  s.box(fx(i)-57,fy(v),114,fy(0)-fy(v),BLUE if i else '#b7c7dd',8);s.text(fx(i),fy(v)-17,f'{v:.1f}%',33,INK,True,anchor='middle')
 s.number(756,231,2);s.text(788,240,'What we reconstructed',31,INK,True)
 s.text(745,292,'Weight edit versus activation hook • 40 fixed prefixes',22,MUT)
 e=D['e1'];panels=[(790,'max |Δlogit|','logit units','max_logit_difference',(1e-6,1),[(1e-6,'10⁻⁶'),(1e-4,'10⁻⁴'),(.01,'10⁻²'),(1,'1')]),(1215,'max KL','nats','max_kl',(1e-12,1),[(1e-12,'10⁻¹²'),(1e-8,'10⁻⁸'),(1e-4,'10⁻⁴'),(1,'1')])]
 for x,title,unit,k,yr,yt in panels:
  xx,yy=axis(s,(x,360,280,350),(-.5,1.5),yr,[(0,'FP32'),(1,'BF16')],yt,unit,title,logy=True)
  for i,cond in enumerate(['e1fp32','e1']):
   v=e[cond][k];s.line((xx(i),yy(yr[0])),(xx(i),yy(v)),BLUE if i==0 else LAV,5);s.circle(xx(i),yy(v),9,BLUE if i==0 else LAV);s.text(xx(i),yy(v)-20,f'{v:.2g}',23,INK,True,anchor='middle')
 s.lines(120,820,['Reported improvement is not a new full replication.'],22,MUT)
 s.lines(745,820,['FP32 nearly agrees; BF16 rounding leaves a larger residual.'],22,MUT)
 s.footer('First verify what the edit does. Then test whether the behavior reproduces.','Bars: original report • numerical checks: project E1 • separate units and logarithmic scales on the right')
 return s

def controls():
 s=SVG('Do the controls deliver the same intervention?','A coarse gain search did not match the target. Its curves still bracket that target.','04 / E2 MEASURED LIMITATION')
 fx,fy=axis(s,(150,330,850,440),(.23,4.4),(.002,10),[(.25,'.25'),(.5,'.5'),(1,'1'),(2,'2'),(4,'4')],[(.01,'.01'),(.1,'.1'),(1,'1'),(10,'10')],'control gain  (log scale)','− mean Δlog p of repeated target  (nats, log scale)',True,True)
 cs=[BLUE,LAV,GOLD]
 for (name,rec),c in zip(D['e2']['calibration'].items(),cs):
  vals=sorted((float(k),-v) for k,v in rec['curve'].items());s.path([(fx(x),fy(y))for x,y in vals],c,3)
  for x,y in vals:s.circle(fx(x),fy(y),6,c)
  chosen=rec['gain'];s.circle(fx(chosen),fy(-rec['curve'][str(float(chosen))]),11,c,INK,1)
 target=-D['e2']['calibration']['constant']['target'];s.line((150,fy(target)),(1000,fy(target)),CORAL,2,'7 6');s.text(160,fy(target)-15,f'exact-gate target = {target:.3f}',23,CORAL)
 for i,(name,c)in enumerate(zip(['constant steering','shuffled gate','random direction'],cs)):
  s.circle(175+i*280,247,6,c);s.text(195+i*280,254,name,23,INK)
 s.box(1080,225,460,615,'#f2f6fc');s.number(1116,269,1);s.text(1150,277,'What was measured',27,INK,True);s.lines(1115,322,['16 calibration examples.','Five discrete gains per arm.','Large outlined dots show','the selected candidates.'],24,dy=34)
 s.number(1116,505,2);s.text(1150,513,'What remains open',27,INK,True);s.lines(1115,558,['Every curve crosses the target','between tested grid points.','A finer search may match it.','','This is teacher forcing on','constructed repetitive states,','not a live generation test.'],23,dy=31)
 s.footer('A failed grid match does not prove that a control is impossible.','E2 calibration data • lines join measured grid values, not an interpolated causal model • both axes logarithmic')
 return s

def fisher(t=1):
 s=SVG('A local ruler, not a global map.','Fisher predicts small edits well in this probe. The full Astra dose leaves the local regime.','05 / E3 + ANALYTIC SCHEMATIC')
 s.text(85,238,'1  The local metric',30,INK,True)
 x=np.linspace(-1.5,1.5,31);y=np.linspace(-1.25,1.25,31);X,Y=np.meshgrid(x,y);Z=.5*(X**2+3*Y**2)
 b=(355,520,145,85);mesh(s,X,Y,Z,b,scale=(1,1,.55));s.text(105,682,'KL ≈ ½ uᵀFu',36,BLUE);s.lines(105,735,['Equal Euclidean steps can incur','different behavioral costs.'],23)
 s.text(105,823,'Illustration only: F = diag(1, 3).',19,MUT)
 fx,fy=axis(s,(820,340,670,390),(.025,1.3),(1e-8,.1),[(.03,'.03'),(.1,'.1'),(.3,'.3'),(1,'1')],[(1e-8,'10⁻⁸'),(1e-6,'10⁻⁶'),(1e-4,'10⁻⁴'),(.01,'10⁻²'),(.1,'.1')],'edit dose α  (1 = Astra gain 6)','median KL on fixed prefixes (nats)',True,True)
 s.text(760,238,'2  The measured boundary',30,INK,True)
 doses=[.03,.1,.3,1]; med={};colors={'measured_kl':BLUE,'fisher_prediction':LAV,'weight_norm_prediction':'#a3aebe'}
 for key,c in colors.items():
  vals=[np.median([r[key]for r in D['e3']['samples'] if r['dose']==q])for q in doses];med[key]=vals;s.path([(fx(q),fy(v))for q,v in zip(doses,vals)],c,3,'7 5'if key!='measured_kl'else None)
  for q,v in zip(doses,vals):s.circle(fx(q),fy(v),5,c)
 for i,(name,c)in enumerate(zip(['measured','Fisher','weight norm'],colors.values())):s.line((840+i*205,281),(867+i*205,281),c,3);s.text(876+i*205,288,name,21,MUT)
 j=min(3,int(t*4));q=doses[j]
 for r in D['e3']['samples']:
  if r['dose']==q:s.circle(fx(q),fy(r['measured_kl']),3,GOLD,'none')
 s.circle(fx(q),fy(med['measured_kl'][j]),10,GOLD,BLUE,2)
 ratio=np.median([r['fisher_prediction']/r['measured_kl']for r in D['e3']['samples']if r['dose']==1]);s.text(820,823,f'At α = 1: median per-prefix Fisher / measured = {ratio:.2f}',23,INK)
 s.footer('A beautiful geometry is useful only within the range the data supports.','32 evaluation prefixes • Fisher estimated per prefix • doses shown excluded from derivative estimation • left surface is not Qwen')
 return s

F=np.array([[2.,.5],[.5,1.]]);v=np.array([.8,1.4]);p=np.array([1.15,0.])
def duality(t=.65):
 s=SVG('The closest reachable move depends on the metric.','A shared weight edit can realize only a subspace of activation-space requests.','06 / EXACT TWO-DIMENSIONAL MODEL')
 s.text(70,236,'The cost of missing the desired steering',30,INK,True)
 xx=np.linspace(-.6,2.2,37);yy=np.linspace(-.5,2.5,37);X,Y=np.meshgrid(xx,yy);A=X-v[0];B=Y-v[1];Z=.5*(2*A*A+A*B+B*B)
 box=(370,580,170,85);mesh(s,X,Y,Z,box,scale=(1,1,.55))
 line=np.linspace(-.6,2.2,160);lz=.5*(2*(line-v[0])**2+(line-v[0])*(-v[1])+v[1]**2);lp=proj(np.c_[line,np.zeros_like(line),lz],box,(1,1,.55));s.path(lp,BLUE,4)
 points=np.array([[v[0],v[1],0],[p[0],0,.5*(p-v)@F@(p-v)]]);qp=proj(points,box,(1,1,.55))
 for q,c in zip(qp,[GOLD,BLUE]):s.circle(*q,9,c)
 s.text(92,742,'½ (u − v)ᵀ F (u − v)',33,BLUE);s.lines(92,790,['The blue curve restricts u to the reachable line.','Its minimum is the Fisher projection.'],22)
 # Exact, calibrated tangent-plane inset.
 fx,fy=axis(s,(1030,350,420,350),(-.4,1.8),(-.3,1.8),[(0,'0'),(.8,'.8'),(1.15,'1.15')],[(0,'0'),(1.4,'1.4')],'activation coordinate u₁','activation coordinate u₂')
 s.line((fx(-.4),fy(0)),(fx(1.8),fy(0)),BLUE,3);s.text(1030,850,'reachable S = span(e₁)',22,BLUE)
 s.arrow((fx(0),fy(0)),(fx(*[v[0]]),fy(v[1])),GOLD,3);s.circle(fx(p[0]),fy(0),8,BLUE);s.circle(fx(.8),fy(0),6,CORAL)
 s.line((fx(v[0]),fy(v[1])),(fx(p[0]),fy(0)),LAV,2,'6 5');s.text(fx(v[0])+18,fy(v[1])-8,'desired v',23,INK)
 s.text(1010,240,'Fisher ≠ Euclidean projection',30,INK,True);s.text(1010,289,'F = [[2, .5], [.5, 1]]',24,MUT)
 s.text(1010,801,'Fisher: (1.15, 0)  •  Euclidean: (.8, 0)',23,INK)
 u=np.array([.8+.35*t,0]);z=.5*(u-v)@F@(u-v);dot=proj(np.array([*u,z]),box,(1,1,.55));s.circle(*dot,11,GOLD,INK,1)
 s.footer('Push forward the natural gradient; obtain the reachable Fisher projection.','Analytic model, not a measured Qwen landscape • residual satisfies (v − Πv)ᵀFe₁ = 0 • animation follows the restricted cost')
 return s

def coordinates(t=.55):
 s=SVG('One path. Two coordinate systems.','A straight line in probabilities becomes a curved line in natural coordinates.','07 / EXACT LEGENDRE DUALITY')
 s.text(85,240,'Natural coordinates',31,INK,True);s.text(855,240,'Expectation coordinates',31,INK,True)
 s.text(85,282,'ψ(h) = log(1 + exp h₁ + exp h₂)',24,MUT);s.text(855,282,'φ(η) = Σ pᵢ log pᵢ',24,MUT)
 x=np.linspace(-2,2,37);X,Y=np.meshgrid(x,x);Z=np.logaddexp(np.logaddexp(X,Y),0)
 b1=(360,550,114,110);mesh(s,X,Y,Z,b1,scale=(1,1,.6))
 # Triangular mesh over VALID simplex, never clamp negative p3.
 a=np.linspace(0,1,49);A,B=np.meshgrid(a,a);U=.03+.91*A;V=.03+.91*(1-A)*B;W=1-U-V;assert np.all(W>=.029999);PH=U*np.log(U)+V*np.log(V)+W*np.log(W)
 b2=(1160,540,370,230);mesh(s,U-.33,V-.33,PH+1.1,b2,scale=(1,1,.8),palette=(202,200,234))
 p0=np.array([.62,.23,.15]);p1=np.array([.14,.26,.6]);tt=np.linspace(0,1,121);P=p0[None,:]+tt[:,None]*(p1-p0)[None,:];H=np.log(P[:,:2]/P[:,2,None]);psi=np.logaddexp(np.logaddexp(H[:,0],H[:,1]),0);phi=np.sum(P*np.log(P),axis=1)
 path1=proj(np.c_[H,psi],b1,(1,1,.6));path2=proj(np.c_[P[:,0]-.33,P[:,1]-.33,phi+1.1],b2,(1,1,.8));s.path(path1,BLUE,3.5);s.path(path2,BLUE,3.5)
 j=int(t*120);s.circle(*path1[j],10,GOLD,INK,1);s.circle(*path2[j],10,GOLD,INK,1)
 # Correct 2D projections of precisely the same path. Same scale per coordinate within each panel.
 f1=lambda h:(280+112*h[0],760-112*h[1]);f2=lambda eta:(1000+400*eta[0],860-400*eta[1]);s.path([f1(h)for h in H],BLUE,3);s.path([f2(p[:2])for p in P],BLUE,3)
 s.circle(*f1(H[j]),8,GOLD);s.circle(*f2(P[j,:2]),8,GOLD)
 s.text(75,661,'hᵢ = log(pᵢ / p₃)',26,INK);s.text(850,661,'η = (p₁, p₂)',26,INK)
 s.text(75,878,'curved h-path',22,MUT);s.text(850,878,'straight η-path',22,MUT)
 s.text(800,582,'η = ∇ψ(h)',29,INK,True,anchor='middle');s.arrow((680,530),(880,530),LAV,2)
 s.footer('This is Amari’s coordinate duality—not “weights are dual coordinates of activations.”','Exact three-class softmax • gold markers represent the same probability state • surfaces are analytic potentials, not Qwen measurements')
 return s

def impossibility():
 s=SVG('One shared weight cannot obey every request.','A two-input example exposes the difference between direct intervention and realizable intervention.','08 / EXACT COUNTEREXAMPLE')
 s.text(80,245,'Two inputs. One parameter.',31,INK,True);s.text(86,303,'h_w(x) = wx',38,BLUE)
 s.box(65,355,560,158);s.text(95,403,'Input  x = +1',27,INK,True);s.text(95,459,'weight edit: Δh = +δw',29,BLUE)
 s.box(65,545,560,158,'#f0eff9');s.text(95,593,'Input  x = −1',27,INK,True);s.text(95,649,'weight edit: Δh = −δw',29,LAV)
 s.text(90,771,'Direct steering asks for (+d, +d).',27,INK);s.lines(90,816,['A shared scalar edit gives (δw, −δw).'],25,MUT)
 fx,fy=axis(s,(855,330,590,450),(-1.5,1.5),(-1.5,1.5),[(-1,'−d'),(0,'0'),(1,'+d')],[(-1,'−d'),(0,'0'),(1,'+d')],'response on input +1','response on input −1')
 s.path([(fx(-1.4),fy(1.4)),(fx(1.4),fy(-1.4))],BLUE,5);s.arrow((fx(0),fy(0)),(fx(1),fy(1)),GOLD,3);s.circle(fx(1),fy(1),10,GOLD,INK,1);s.text(fx(1)-5,fy(1)-24,'desired (+d, +d)',23,INK,anchor='middle');s.text(970,880,'reachable line: u₂ = −u₁',25,BLUE)
 s.footer('For d ≠ 0, no δw can equal d and −d at once.','Exact scalar model • allowing an editable bias or another path changes the reachable set • no claim that all neural edits are scalar')
 return s

def verify():
 assert np.all(np.linalg.eigvalsh(F)>0);assert abs((v-p)@F@np.array([1.,0.]))<1e-12
 ps=np.array([.62,.23,.15])+np.linspace(0,1,100)[:,None]*(np.array([.14,.26,.6])-np.array([.62,.23,.15]));assert np.all(ps>0);assert np.allclose(ps.sum(1),1)
 h=np.log(ps[:,:2]/ps[:,2,None]);q=np.c_[np.exp(h),np.ones(len(h))];q/=q.sum(1)[:,None];assert np.allclose(q,ps)
 assert all(sum(r['dose']==d for r in D['e3']['samples'])==32 for d in [.03,.1,.3,1])
 print('geometry/data invariants passed')
if __name__=='__main__':
 import sys
 verify();names=sys.argv[1:] or ['cover','anatomy','reconstruction','controls','fisher','duality','coordinates','impossibility']
 for n in names:
  fn=globals()[n];frames=(32,fn,120)if n in ['cover','anatomy','duality','coordinates']else (4,fn,1200)if n=='fisher'else None
  save(n,fn(),frames)
