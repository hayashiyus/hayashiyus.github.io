"""Execution plate: a shared linear map and its pointwise activation policy.

All geometry is an exact two-dimensional toy. The oblique display projection
is fixed in both panels. The left mesh is the IMAGE of a sampled input grid,
never a weight-space manifold or a moving coordinate system.
"""
from pathlib import Path
import argparse
import io
import json
import subprocess

import numpy as np
from PIL import Image
import atlas_v3 as atlas
import math_typesetting as typeset

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'assets/v23/execution'
PAPER = '#fffefc'
INK, MUT = '#263653', '#72829a'
BLUE, LAV, GOLD = '#4c83be', '#9892c7', '#c6a164'
W = np.eye(2)
K = np.array([1., 0.])
D = np.array([0., .7])
STATES = np.array([[1., 0.], [0., 1.], [-1., 0.]])
CAMERA = np.array([[180., 62.], [42., -130.]])
ORIGINS = [np.array([420., 530.]), np.array([1180., 530.])]
DURATION, FPS = 12., 24


def ease(t):
    t = np.clip(t, 0., 1.)
    return t*t*(3.-2.*t)


def state_at(seconds):
    """One shared edit strength, not an optimization or network trajectory."""
    alpha = float(ease((seconds-1.3)/3.9))
    opacity = float(min(ease(seconds/.6), 1-ease((seconds-11.2)/.8)))
    focus = None
    if 5.6 <= seconds < 8.6:
        focus = int((seconds-5.6)//1.)
    return alpha, opacity, focus


def outputs(alpha):
    left = STATES @ (W + alpha*np.outer(D, K)).T
    right = STATES @ W.T + alpha*(STATES @ K)[:, None]*D
    return left, right


def project(points, panel):
    return np.asarray(points) @ CAMERA.T + ORIGINS[panel]


def arrow(s, p, q, color=GOLD, width=3.4, opacity=1):
    p, q = np.asarray(p), np.asarray(q)
    v = q-p
    length = np.linalg.norm(v)
    if length < 1: return
    u = v/length
    q = q-u*min(13.,length*.2)
    length = float(np.linalg.norm(q-p))
    n = np.array([-u[1], u[0]])
    head = min(12., .35*length)
    s.line(p, q, color, width, opacity=opacity)
    s.path([q, q-u*head+n*head*.36, q-u*head-n*head*.36],
           color, 0, opacity=opacity, fill=color, close=True)


def mesh(s, panel, alpha, mapped=False):
    extent = 1.35
    transform = W + alpha*np.outer(D, K) if mapped else W
    corners = np.array([[-extent,-extent],[extent,-extent],
                        [extent,extent],[-extent,extent]])
    q = project(corners @ transform.T, panel)
    color = LAV if mapped else BLUE
    s.path(q, color, 1.2, opacity=.7,
           fill='url(#violet-wash)' if mapped else 'url(#blue-wash)', close=True)
    # Every line is the exact image of a straight line under the same matrix.
    for t in np.linspace(-extent, extent, 13):
        for axis in range(2):
            pts = np.array([[t,-extent],[t,extent]]) if axis==0 else np.array([[-extent,t],[extent,t]])
            q = project(pts @ transform.T, panel)
            s.path(q, color, .85 if abs(t)>.01 else 1.2, opacity=.26)


def figure(alpha=1., opacity=1., focus=None):
    s = atlas.SVG('One rule. Two ways to move a state.',
                  'The same input. The same correction. The same output.',
                  'EXECUTION / EXACT LINEAR MODEL')
    s.a[0] = s.a[0].replace('fill="#fff"', f'fill="{PAPER}"')
    s.a.append('<defs><linearGradient id="blue-wash" x1="0" y1="0" x2="1" y2="1">'
               '<stop stop-color="#c6d9ee" stop-opacity=".14"/><stop offset=".5" stop-color="#b7cce6" stop-opacity=".43"/>'
               '<stop offset="1" stop-color="#e6edf7" stop-opacity=".16"/></linearGradient>'
               '<linearGradient id="violet-wash" x1="0" y1="1" x2="1" y2="0">'
               '<stop stop-color="#bcb7da" stop-opacity=".42"/><stop offset=".65" stop-color="#d2d8e9" stop-opacity=".24"/>'
               '<stop offset="1" stop-color="#f0edf6" stop-opacity=".1"/></linearGradient></defs>')
    s.text(420, 240, 'Edit the weights', 31, INK, True, anchor='middle')
    s.text(1180, 240, 'Steer the activations', 31, INK, True, anchor='middle')
    s.math(420, 287, r'\Delta W_\alpha=\alpha dk^\top', 29, LAV, anchor='middle')
    s.math(1180, 287, r'u_\alpha(a)=\alpha d(k^\top a)', 29, BLUE, anchor='middle')
    s.a.append(f'<g id="computed-scene" opacity="{opacity:.5f}">')
    left, right = outputs(alpha)
    for panel, result in enumerate([left, right]):
        # Fixed coordinate reference: neither chart nor camera deforms.
        corners = np.array([[-1.35,-1.35],[1.35,-1.35],[1.35,1.35],[-1.35,1.35]])
        s.path(project(corners,panel), '#a3b2c6', 1, '4 5', .48, close=True)
        mesh(s, panel, alpha, mapped=(panel==0))
        for axis in (0,1):
            pts = np.zeros((2,2));pts[:,axis]=[-1.52,1.52]
            s.path(project(pts,panel), '#9baabe', 1.1, opacity=.64)
            end=project(pts[1],panel)
            s.math(end[0]+8,end[1]+7,'h_1' if axis==0 else 'h_2',20,MUT)
        origin=project([0.,0.],panel)
        s.circle(*origin,2.4,MUT,'none',0)
        for j,(a,h) in enumerate(zip(STATES,result)):
            initial, final = project(a,panel), project(h,panel)
            c = [BLUE, '#7b879b', LAV][j]
            # Hollow reference points remain anchored to the original output.
            s.circle(*initial,10,PAPER,'#9eacc1',1.6)
            if j != 1:
                arrow(s, initial, final, GOLD, 3.7)
                # The ghost label is deliberately separated from the moving dot.
                s.text(initial[0]+(-16 if j==0 else 16), initial[1]+(35 if j==0 else -25),
                       'ABC'[j],23,INK,True,anchor='end' if j==0 else 'start')
                if alpha>.04:
                    mid=.48*initial+.52*final
                    s.math(mid[0]+(20 if j==0 else -24),mid[1]+7,
                           r'+\alpha d' if j==0 else r'-\alpha d',24,GOLD,
                           anchor='start' if j==0 else 'end')
            else:
                s.text(initial[0]+25,initial[1]-17,'B',23,INK,True)
                s.math(initial[0]+25,initial[1]+19,'0',23,MUT)
            s.circle(*final,11,c,PAPER,3)
            if j==1: s.circle(*final,18,'none',c,1.2)
            # Paired pulses only identify correspondence; they do not move data.
            if focus==j:s.circle(*final,25,'none',GOLD,2)
        # A short legend on the edge identifies the mesh, not an extra space.
        s.text(ORIGINS[panel][0],775,
               'one map acts on the whole grid' if panel==0 else 'one rule acts on each input',
               22,MUT,False,anchor='middle')
    s.math(800,535,r'=',43,GOLD,anchor='middle')
    s.a.append('</g>')
    # Fade the common control with the chart so the loop has no slider jump.
    s.a.append(f'<g id="strength-control" opacity="{opacity:.5f}">')
    # One common strength control makes the interpolation explicit.
    s.math(570,829,r'\alpha',25,MUT,anchor='end')
    s.line((602,821),(962,821),'#dce3ed',5)
    s.line((602,821),(602+360*alpha,821),GOLD,5)
    s.circle(602+360*alpha,821,7,GOLD,PAPER,2)
    s.math(587,855,'0',17,MUT)
    s.math(967,855,'1',17,MUT)
    s.text(996,829,'edit strength',19,MUT)
    s.a.append('</g>')
    s.line((110,885),(1490,885),'#dce3ec',1)
    s.math(800,945,r'(W+\alpha dk^\top)a=Wa+\alpha d(k^\top a)',36,INK,anchor='middle')
    s.text(800,984,'Fixed output coordinates · hollow: before · filled: after',17,MUT,anchor='middle')
    return s


def verify():
    errors=[]
    grid=np.array([(x,y) for x in np.linspace(-1.35,1.35,13) for y in np.linspace(-1.35,1.35,13)])
    for alpha in np.linspace(0,1,241):
        l,r=outputs(alpha);errors.append(float(np.max(np.abs(l-r))))
        assert np.array_equal(l[1],STATES[1])
        assert np.allclose(project(l,0)-ORIGINS[0],project(r,1)-ORIGINS[1],atol=1e-12)
        assert np.allclose(grid@(W+alpha*np.outer(D,K)).T,
                           grid@W.T+alpha*(grid@K)[:,None]*D,atol=1e-14)
    l,r=outputs(1.)
    assert np.allclose(l,[[1,.7],[0,1],[-1,-.7]])
    assert np.allclose((W+np.outer(D,K))[:,1],[0,1])
    record={'classification':'exact linear-writer toy; not Qwen activations or an optimization record',
        'W':W.tolist(),'k':K.tolist(),'d':D.tolist(),'states':STATES.tolist(),
        'weight_outputs':l.tolist(),'hook_outputs':r.tolist(),
        'max_absolute_discrepancy':max(errors),'alpha_values_checked':241,
        'grid_samples_checked_per_alpha':len(grid),'stationary_B':True,
        'display_projection':CAMERA.tolist(),'panel_origins':[o.tolist() for o in ORIGINS],
        'mesh_semantics':'left: image of sampled input grid under W+alpha*d*k.T; right: fixed output-coordinate reference',
        'timing':{'duration_seconds':DURATION,'fps':FPS,'start_hold_until':1.3,
                  'full_strength_at':5.2,'paired_highlights':[5.6,6.6,7.6],
                  'reset':'crossfade through paper; not reverse dynamics'}}
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'model.json').write_text(json.dumps(record,indent=2)+'\n')
    print('Exact model, fixed charts, signed displacements: PASS',flush=True)


def prepare():
    with typeset.collect():
        for a in [0.,.5,1.]:figure(a)
    typeset.prepare()


def save_still():
    svg=figure().finish();(OUT/'execution.svg').write_text(svg)
    subprocess.run(['rsvg-convert','-o',str(OUT/'execution.png'),str(OUT/'execution.svg')],check=True)
    for name,a in [('start',0.),('half',.5),('end',1.)]:
        (OUT/f'{name}.svg').write_text(figure(a).finish())


def render_motion():
    outsize=(1280,800)
    encoder=subprocess.Popen(['ffmpeg','-y','-v','error','-f','image2pipe','-vcodec','png',
        '-framerate',str(FPS),'-i','-','-an','-c:v','libx264','-crf','18','-pix_fmt','yuv420p',
        '-movflags','+faststart',str(OUT/'execution.mp4')],stdin=subprocess.PIPE)
    gifs=[]
    for i in range(round(DURATION*FPS)):
        alpha,opacity,focus=state_at(i/FPS)
        png=subprocess.check_output(['rsvg-convert','-w',str(outsize[0])],input=figure(alpha,opacity,focus).finish().encode())
        encoder.stdin.write(png)
        if i%2==0:
            im=Image.open(io.BytesIO(png)).convert('RGB');im.thumbnail((960,600));gifs.append(im)
        if i%72==0:print(f'Frame {i}/{round(DURATION*FPS)}',flush=True)
    encoder.stdin.close();assert encoder.wait()==0
    contact=Image.new('RGB',(960,1800),PAPER)
    for j,k in enumerate([12,32,80]):contact.paste(gifs[k],(0,j*600))
    pal=contact.quantize(colors=224)
    qs=[im.quantize(palette=pal,dither=Image.Dither.NONE) for im in gifs]
    qs[0].save(OUT/'execution.gif',save_all=True,append_images=qs[1:],
               duration=[80,80,90]*(len(qs)//3),loop=0,optimize=True)
    print('MP4 and GIF rendered from the same calculated frames.',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--stills-only',action='store_true')
    args=parser.parse_args();verify();prepare();save_still()
    if not args.stills_only:render_motion()
