// Native Figma animation, v12. Execute with use_figma on page 55:11.
// Painting is an allegory, not a fluid simulation or measured Qwen trajectory.
const page = await figma.getNodeByIdAsync('55:11');
await figma.setCurrentPageAsync(page);
const source = await figma.getNodeByIdAsync('110:11');
const fonts = new Map();
for (const t of source.findAllWithCriteria({types:['TEXT']})) {
  for (const s of t.getStyledTextSegments(['fontName'])) fonts.set(JSON.stringify(s.fontName), s.fontName);
}
for (const f of fonts.values()) await figma.loadFontAsync(f);
const cover = source.clone(); page.appendChild(cover);
cover.x = Math.max(...page.children.filter(n=>n.id!==cover.id).map(n=>n.x+n.width))+240;
cover.y=0;cover.name='Cover v12 — the river and the move · 18s loop';
const changed=[cover.id];
// The annotation points to the working hand, leaving the boat-contact zone clear.
const leader=cover.children.find(n=>n.type==='VECTOR'&&n.x===1118&&n.y===480);
const dot=cover.children.find(n=>n.type==='VECTOR'&&n.x===1223&&n.y===814);
leader.vectorPaths=[{windingRule:'NONE',data:'M0 0 L0 105 L197 213'}];leader.x=1118;leader.y=480;dot.x=1311;dot.y=689;
changed.push(leader.id,dot.id);
const painting=cover.children.find(n=>n.type==='FRAME');
for(const n of [...painting.children]) n.remove();
painting.name='Living watercolor · original actors + independent boats';
painting.fills=[]; painting.clipsContent=false;
const original='6ddace52c6be07fb0a9591b66523b847b2f65ed7';
const clean='b84411e09f600d69a16164f710384ab9f211bdfe';
const W=1536,H=1024,T=18,N=180;
function track(values,type='FLOAT') {return {keyframes:values.map(([t,v])=>({timelinePosition:t,value:{type,value:v},easing:{type:'LINEAR'}}))};}
function rect(parent,name,x,y,w,h,hash) {const n=figma.createRectangle();parent.appendChild(n);n.name=name;n.x=x;n.y=y;n.resize(w,h);n.fills=[{type:'IMAGE',imageHash:hash,scaleMode:'FILL'}];changed.push(n.id);return n;}
function cut(parent,name,points,hash) {
  const xs=points.map(p=>p[0]),ys=points.map(p=>p[1]);const x=Math.min(...xs),y=Math.min(...ys),w=Math.max(...xs)-x,h=Math.max(...ys)-y;
  const n=figma.createVector();parent.appendChild(n);n.name=name;
  n.vectorPaths=[{windingRule:'NONZERO',data:points.map((p,i)=>(i?'L':'M')+(p[0]-x)+' '+(p[1]-y)).join(' ')+' Z'}];
  n.x=x;n.y=y;n.fills=[{type:'IMAGE',imageHash:hash,scaleMode:'CROP',imageTransform:[[w/W,0,x/W],[0,h/H,y/H]]}];n.strokes=[];changed.push(n.id);return n;
}
rect(painting,'Approved v11 painting — preserved',0,0,W,H,original);
const patches=[
 [[295,325],[355,336],[364,353],[440,352],[510,365],[565,393],[574,428],[585,448],[670,446],[738,452],[781,471],[797,511],[813,532],[875,547],[924,567],[945,603],[974,626],[1070,627],[1172,622],[1242,629],[1313,654],[1362,682],[1393,708],[1407,754],[1435,830],[1388,841],[1368,774],[1351,746],[1290,712],[1221,696],[1136,699],[1040,709],[974,709],[937,692],[917,638],[884,619],[829,613],[786,591],[760,561],[746,524],[710,512],[637,523],[568,520],[528,497],[507,454],[487,424],[442,399],[363,390],[316,384]],
 [[1192,653],[1203,657],[1270,552],[1262,547]]
];
patches.forEach((p,i)=>cut(painting,'Inpainted water only '+(i+1),p,clean));

// The same periodic flow phase drives water, boat spacing and the gate.
const pts=[[338,374],[435,383],[505,414],[535,476],[585,498],[679,487],[748,502],[780,543],[815,572],[898,595],[937,635],[974,666],[1090,660],[1190,659],[1268,680],[1350,716],[1381,755]];
function cr(p0,p1,p2,p3,u) {return [0,1].map(k=>.5*((2*p1[k])+(-p0[k]+p2[k])*u+(2*p0[k]-5*p1[k]+4*p2[k]-p3[k])*u*u+(-p0[k]+3*p1[k]-3*p2[k]+p3[k])*u*u*u));}
const curve=[];let length=0;
for(let j=0;j<pts.length-1;j++)for(let s=0;s<36;s++){const p=cr(pts[Math.max(0,j-1)],pts[j],pts[j+1],pts[Math.min(pts.length-1,j+2)],s/36);if(curve.length)length+=Math.hypot(p[0]-curve[curve.length-1].x,p[1]-curve[curve.length-1].y);curve.push({x:p[0],y:p[1],s:length});}
function route(q,offset=0){const distance=Math.max(0,Math.min(1,q))*length;let i=1;while(i<curve.length-1&&curve[i].s<distance)i++;const a=curve[i-1],b=curve[i],u=(distance-a.s)/Math.max(.0001,b.s-a.s),dx=b.x-a.x,dy=b.y-a.y,l=Math.hypot(dx,dy);return {x:a.x+(b.x-a.x)*u-dy/l*offset,y:a.y+(b.y-a.y)*u+dx/l*offset,angle:Math.atan2(dy,dx)*180/Math.PI};}
const phase=t=>t/T-.45*Math.sin(2*Math.PI*t/T)/(2*Math.PI);
const wrap=q=>(q%1+1)%1;
const ease=x=>x<=0?0:x>=1?1:x*x*(3-2*x);
const gate=t=>(1-Math.cos(2*Math.PI*t/T))/2;
const grid=Array.from({length:N+1},(_,i)=>i*T/N);

// Short translucent brush marks travel through the existing painted stream.
for(let i=0;i<18;i++){
  const n=figma.createVector();painting.appendChild(n);n.name='Moving water brush '+(i+1);n.vectorPaths=[{windingRule:'NONZERO',data:'M0 1 Q10 -1 24 0'}];
  n.strokes=[{type:'SOLID',color:{r:.89,g:.95,b:.99},opacity:.75}];n.strokeWeight=i%3===0?1.7:1.1;n.strokeCap='ROUND';n.fills=[];n.x=0;n.y=0;changed.push(n.id);
  const values=grid.map(t=>{const q=wrap(i/18+phase(t)*2);const p=route(q,((i%5)-2)*5);return{t,q,p};});
  n.manualKeyframeTracks={TRANSLATION_X:track(values.map(v=>[v.t,v.p.x-12])),TRANSLATION_Y:track(values.map(v=>[v.t,v.p.y])),ROTATION:track(values.map(v=>[v.t,-v.p.angle])),OPACITY:track(values.map(v=>[v.t,.425*ease(v.q/.04)*ease((1-v.q)/.04)]))};
}

// White paper boats are clipped from the approved painting, not redrawn icons.
const boatOutline=[[614,478],[641,479],[651,462],[662,479],[690,467],[683,490],[662,501],[637,503],[624,492]];
const boats=[];
for(let i=0;i<4;i++){
  const vessel=figma.createFrame();painting.appendChild(vessel);vessel.resize(100,70);vessel.name='Paper boat '+(i+1)+' · equal arc-length spacing';vessel.fills=[];vessel.clipsContent=false;vessel.x=0;vessel.y=0;changed.push(vessel.id);
  const shadow=figma.createEllipse();vessel.appendChild(shadow);shadow.name='Water contact';shadow.x=11;shadow.y=45;shadow.resize(78,10);shadow.fills=[{type:'SOLID',color:{r:.19,g:.35,b:.49},opacity:.14}];changed.push(shadow.id);
  const wake=figma.createVector();vessel.appendChild(wake);wake.name='Fine wake';wake.vectorPaths=[{windingRule:'NONZERO',data:'M0 0 Q38 19 90 0 M2 5 Q38 22 86 6'}];wake.x=4;wake.y=43;wake.strokes=[{type:'SOLID',color:{r:.91,g:.96,b:1},opacity:.6}];wake.strokeWeight=1.2;wake.fills=[];changed.push(wake.id);
  const b=cut(vessel,'Original watercolor paper hull',boatOutline,original);b.x=12;b.y=7;
  const values=grid.map(t=>{const q=wrap(.10+i*.25+phase(t));const push=34*ease((q-.805)/.028)*ease((.94-q)/.065);const p=route(q,push);return {t,q,p,push};});
  vessel.manualKeyframeTracks={TRANSLATION_X:track(values.map(v=>[v.t,v.p.x-50])),TRANSLATION_Y:track(values.map(v=>[v.t,v.p.y-48])),ROTATION:track(values.map(v=>[v.t,-v.p.angle*.66-16*ease((v.q-.80)/.035)*ease((.90-v.q)/.04)])),SCALE_X:track(values.map(v=>[v.t,1.12*(.82+.2*v.q)])),SCALE_Y:track(values.map(v=>[v.t,1.12*(.82+.2*v.q)])),OPACITY:track(values.map(v=>[v.t,ease(v.q/.035)*ease((1-v.q)/.04)]))};
  boats.push(values);
}

// Gate turns about its fixed spindle; opening shares the flow phase.
const gateUnder=cut(painting,'Water behind the gate',[[255,319],[292,321],[292,397],[280,402],[256,395]],clean);
gateUnder.fills=[{type:'IMAGE',imageHash:clean,scaleMode:'CROP',imageTransform:[[18/W,0,328/W],[0,30/H,354/H]]}];
const gateLeaf=cut(painting,'Sliding brass gate',[[255,319],[292,321],[292,397],[280,402],[256,395]],original);
gateLeaf.manualKeyframeTracks={SCALE_X:track(grid.map(t=>[t,1-.48*gate(t)]))};
cut(painting,'Fixed spindle above rotating gate',[[220,359],[265,345],[271,343],[277,346],[278,354],[271,359],[224,375]],original);
const operatingHand=cut(painting,'Left actor · wrist and gate grip',[[256,274],[268,272],[279,281],[283,291],[281,300],[272,299],[263,290]],original);
operatingHand.manualKeyframeTracks={TRANSLATION_Y:track(grid.map(t=>[t,-2.6*gate(t)])),ROTATION:track(grid.map(t=>[t,5*gate(t)]))};

// Lower pole pivots at the lower hand; tiny wrist motion stays within the cuff.
const polePivot=figma.createFrame();painting.appendChild(polePivot);polePivot.name='Pole push · contact with arriving boat';polePivot.resize(240,240);polePivot.x=1150;polePivot.y=420;polePivot.clipsContent=false;polePivot.fills=[];changed.push(polePivot.id);
const shaft=figma.createVector();polePivot.appendChild(shaft);shaft.name='Original gold pole · lower shaft';shaft.vectorPaths=[{windingRule:'NONZERO',data:'M71 0 L0 109'}];shaft.x=49;shaft.y=120;shaft.fills=[];shaft.strokes=[{type:'SOLID',color:{r:.57,g:.40,b:.14}}];shaft.strokeWeight=3.1;shaft.strokeCap='ROUND';changed.push(shaft.id);
const highlight=figma.createVector();polePivot.appendChild(highlight);highlight.name='Pale gold watercolor highlight';highlight.vectorPaths=[{windingRule:'NONZERO',data:'M71 0 L0 109'}];highlight.x=48;highlight.y=120;highlight.fills=[];highlight.strokes=[{type:'SOLID',color:{r:.89,g:.76,b:.43},opacity:.75}];highlight.strokeWeight=1.1;highlight.strokeCap='ROUND';changed.push(highlight.id);
const pushValues=grid.map((t,j)=>{let closest=boats.map(b=>b[j]).sort((a,b)=>Math.abs(a.q-.835)-Math.abs(b.q-.835))[0];const q=closest.q;const action=ease((q-.79)/.035)*ease((.90-q)/.045);return[t,action];});
polePivot.manualKeyframeTracks={ROTATION:track(pushValues.map(([t,v])=>[t,5.184*v]))};
const wrist=cut(painting,'Right actor · lower grip',[[1278,491],[1292,493],[1299,503],[1294,519],[1284,531],[1272,533],[1275,518]],original);
wrist.manualKeyframeTracks={ROTATION:track(pushValues.map(([t,v])=>[t,1.6*v])),TRANSLATION_X:track(pushValues.map(([t,v])=>[t,-.8*v]))};

// Subtle water-outlet sparkle, with the same gate rhythm.
const spill=figma.createVector();painting.appendChild(spill);spill.name='Outlet wash · breath of the current';spill.vectorPaths=[{windingRule:'NONZERO',data:'M4 0 Q0 43 17 74 M12 4 Q10 49 26 76 M19 6 Q22 51 34 73'}];spill.fills=[];spill.strokes=[{type:'SOLID',color:{r:.92,g:.96,b:1}}];spill.strokeWeight=2;spill.x=1390;spill.y=774;changed.push(spill.id);
spill.manualKeyframeTracks={OPACITY:track(grid.map(t=>[t,.12+.16*gate(t)])),TRANSLATION_Y:track(grid.map(t=>[t,1.5*Math.sin(4*Math.PI*t/T)]))};
// Keep the editable resting canvas readable without changing any evaluated pose.
for(const n of painting.children) if(n.name.startsWith('Paper boat ')||n.name.startsWith('Moving water brush')) {
  const tr=n.manualKeyframeTracks,dx=tr.TRANSLATION_X.keyframes[0].value.value,dy=tr.TRANSLATION_Y.keyframes[0].value.value;
  n.x+=dx;n.y+=dy;tr.TRANSLATION_X.keyframes.forEach(k=>k.value.value-=dx);tr.TRANSLATION_Y.keyframes.forEach(k=>k.value.value-=dy);n.manualKeyframeTracks=tr;
}
cover.setTimelineDuration(cover.timelines[0].id,T);
figma.currentPage.selection=[cover];figma.viewport.scrollAndZoomIntoView([cover]);
return {createdNodeIds:changed,coverId:cover.id,paintingId:painting.id,duration:T,boats:4,waterBrushes:18,routeLength:length,timeline:cover.timelines};
