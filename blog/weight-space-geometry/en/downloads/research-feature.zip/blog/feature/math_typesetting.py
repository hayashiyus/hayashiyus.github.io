"""Typeset figure labels with the article's exact vendored KaTeX runtime.

KaTeX HTML is laid out by Chromium once, then captured on transparent surfaces
at 4x resolution. Self-contained SVGs retain the TeX source and embed these
labels; PNG/GIF/MP4 therefore use exactly the same glyphs and layout. There is
no Unicode-subscript approximation and no per-frame generative rendering.
"""
from contextlib import contextmanager
from pathlib import Path
import base64
import hashlib
import html
import json
import math
import subprocess

ROOT = Path(__file__).resolve().parent
CACHE = ROOT/'assets/math'
RUNTIME = ROOT/'vendor/katex/katex.min.js'
RUNTIME_HASH = hashlib.sha256(RUNTIME.read_bytes()).hexdigest()
REQUESTS = {}
_cache = None
_collect = False
SCALE = 4


def key_for(tex, size, color):
    spec = dict(tex=tex, size=float(size), color=color,
                runtime_sha256=RUNTIME_HASH, scale=SCALE, renderer=1)
    return hashlib.sha256(json.dumps(spec, sort_keys=True).encode()).hexdigest()[:24], spec


@contextmanager
def collect():
    global _collect
    previous = _collect
    _collect = True
    try:
        yield
    finally:
        _collect = previous


def records():
    global _cache
    if _cache is None:
        path = CACHE/'index.json'
        _cache = json.loads(path.read_text())['labels'] if path.exists() else {}
    return _cache


def svg_math(x, y, tex, size=24, color='#1d3154', anchor='start', max_width=None):
    key, spec = key_for(str(tex), size, color)
    REQUESTS[key] = spec
    if _collect:
        return ''
    label = records().get(key)
    if not label or not (CACHE/label['file']).exists():
        raise RuntimeError(f'Unprepared KaTeX label {tex!r}; run render_figure_math.py first.')
    factor = min(1., max_width/label['width']) if max_width else 1.
    width, height = label['width']*factor, label['height']*factor
    if anchor == 'middle':
        x -= width/2
    elif anchor == 'end':
        x -= width
    y -= label['baseline']*factor
    data = base64.b64encode((CACHE/label['file']).read_bytes()).decode()
    return (f'<g class="typeset-math" data-tex="{html.escape(str(tex), quote=True)}" '
            f'data-engine="KaTeX 0.16.11" aria-label="{html.escape(str(tex), quote=True)}">'
            f'<image x="{x:.3f}" y="{y:.3f}" width="{width:.3f}" height="{height:.3f}" '
            f'xlink:href="data:image/png;base64,{data}"/></g>')


def prepare():
    """Render the collected labels in one offline browser session."""
    cache = records()
    pending = {key: spec for key, spec in REQUESTS.items()
               if key not in cache or not (CACHE/cache[key]['file']).exists()}
    if not pending:
        print(f'KaTeX: {len(REQUESTS)} labels ready in cache.', flush=True)
        return
    CACHE.mkdir(parents=True, exist_ok=True)
    node = r"""
const katex=require(process.argv[1]);let input='';
process.stdin.on('data',x=>input+=x).on('end',()=>{
 const items=JSON.parse(input);
 process.stdout.write(JSON.stringify(items.map(x=>katex.renderToString('\\displaystyle '+x.tex,
  {displayMode:false,output:'html',throwOnError:true,strict:'error'}))));
});
"""
    formulas = json.loads(subprocess.check_output(
        ['node','-e',node,str(RUNTIME)], input=json.dumps(list(pending.values())).encode()))
    blocks = []
    for (key, spec), formula in zip(pending.items(), formulas):
        blocks.append(f'<div class="row"><span class="label" id="m-{key}" '
                      f'style="font-size:{spec["size"]}px;color:{spec["color"]}">'
                      f'{formula}<i class="baseline"></i></span></div>')
    document = ('<!doctype html><html><head><meta charset="utf-8">'
                '<link rel="stylesheet" href="../../vendor/katex/katex.min.css">'
                '<style>html,body{margin:0;background:transparent}body{padding:8px}'
                '.row{display:block;margin:8px 0}.label{display:inline-block;'
                'white-space:nowrap;padding:5px;line-height:normal}.katex{font-size:1em}'
                '.baseline{display:inline-block;width:0;height:0;vertical-align:baseline}'
                '</style></head><body>'+''.join(blocks)+'</body></html>')
    sheet = CACHE/'render-sheet.html'
    sheet.write_text(document)
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        browser = pw.chromium.launch(channel='chrome', headless=True)
        page = browser.new_page(viewport={'width':2400,'height':1600}, device_scale_factor=SCALE)
        page.goto(sheet.as_uri(), wait_until='load')
        page.evaluate('document.fonts.ready')
        assert page.locator('.katex-error').count() == 0
        fonts = page.evaluate("[...document.fonts].filter(f=>f.status==='loaded').map(f=>f.family)")
        assert any('KaTeX' in family for family in fonts), 'KaTeX webfonts did not load.'
        for index, (key, spec) in enumerate(pending.items()):
            target = page.locator('#m-'+key)
            box = target.evaluate("e=>{const b=e.getBoundingClientRect();const p=e.querySelector('.baseline').getBoundingClientRect();return {width:b.width,height:b.height,baseline:p.top-b.top}}")
            target.screenshot(path=str(CACHE/(key+'.png')), omit_background=True)
            cache[key] = {**spec, **box, 'file':key+'.png'}
            if (index+1) % 100 == 0:
                print(f'KaTeX: rendered {index+1}/{len(pending)} labels.', flush=True)
        browser.close()
    sheet.unlink()
    (CACHE/'index.json').write_text(json.dumps({
        'engine':'KaTeX 0.16.11; same vendored runtime/CSS/fonts as the article',
        'runtime_sha256':RUNTIME_HASH,'scale':SCALE,'labels':cache}, ensure_ascii=False, indent=2)+'\n')
    print(f'KaTeX: rendered {len(pending)} labels with vendored webfonts.', flush=True)
