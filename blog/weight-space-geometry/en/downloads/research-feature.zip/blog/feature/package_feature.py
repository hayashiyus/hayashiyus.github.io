#!/usr/bin/env python3
"""Create the portable, public bilingual research-feature source archive."""
from pathlib import Path
import json, re, zipfile

ROOT=Path(__file__).resolve().parent; REPO=ROOT.parent.parent; OUT=REPO/'blog'/'research-feature.zip'
def public_text(p):
    # Explicit, documented transformations of two public records only.
    # Preserve the original historical QA and frozen planning files locally.
    text = p.read_text()
    if p == ROOT/'assets/v22/media-qa.json':
        record = json.loads(text)
        record['format']['filename'] = 'motion-review.mp4'
        return json.dumps(record, ensure_ascii=False, indent=2)+'\n'
    if p == REPO/'experiments/plans/e5_dual_edit_v2.md':
        notice = ('> **Public planning snapshot — not a runnable reproduction package.** '
                  'E5 has not been reported as a completed experiment in this essay. '
                  'Internal manifests, audit records, data and result directories mentioned below '
                  'are not included. File names identify dependencies, not downloadable resources. '
                  'The following source plan is preserved for transparency, including its limitations.\n>\n'
                  '> **公開用の研究計画スナップショット**：実施済み結果や単独で実行可能な再現パッケージではありません。'
                  '本文中の内部ファイルや監査記録は同梱していません。元の計画とその留保を以下に保存します。\n\n')
        return notice+text
    return text
def add_bytes(z, arc, src):
    z.writestr(arc, src.read_bytes())
def add_text(z, arc, src):
    z.writestr(arc, public_text(src).encode())
def main():
    manifest=json.loads((ROOT/'assets'/'figures.json').read_text())
    entries=[]
    def text(rel): entries.append(('text',rel,REPO/rel))
    def binary(rel): entries.append(('bin',rel,REPO/rel))
    for name in ['research.ja.md','build_ja.py','site.ja.css','verify_translation.py','assets/figures.ja.json','translations/README.md','translations/research.en.source.md','translations/research.ja.initial.md','translations/research.ja.before-polish.md','translations/alignment.json','translations/browser-qa.json','translations/polish-qa.json']:
        text('blog/feature/'+name)
    for name in ['verify_english_revision.py','translations/research.en.before-revision.md','translations/research.ja.approved.md','translations/figures.en.before-revision.json','translations/english-revision-qa.json','translations/english-editorial-review.json']:
        text('blog/feature/'+name)
    for name in ['stage_publication.py','translations/prepublication-corrections.json']:
        text('blog/feature/'+name)
    for name in ['editorial_release.py','translations/editorial-revision.json','translations/editorial-release-qa.json','translations/conclusion-outlook-20261109.json','translations/audience-outlook-20261109.json','translations/research-program-framing-20261109.json','translations/recursive-opening-20261109.json']:
        text('blog/feature/'+name)
    for p in sorted((ROOT/'translations/editorial-20261109').glob('*')):
        if p.suffix in ('.md','.json'):
            text(str(p.relative_to(REPO)))
    for name in ['atlas_v24_common.py','geometry_v24.py','constraints_v24.py','measurements_v24.py','translations/atlas-redesign.json','assets/v24/README.md','assets/v24/verification.json','assets/v24/figma-provenance.json','math_typesetting.py','figure_math_captions.py','render_figure_math.py','execution_v23.py','translations/execution-redesign.json','assets/v23/execution/README.md','assets/v23/execution/figma-provenance.json']:
        text('blog/feature/'+name)
    for p in sorted((ROOT/'assets'/'math').glob('*')):
        if p.suffix in ('.json','.png'): binary(str(p.relative_to(REPO)))
    for rel in ['blog/feature/research.md','blog/feature/geometry_v20.py','blog/feature/cover_motion_figma.js','blog/feature/assets/v12/README.md','blog/feature/atlas_v3.py','blog/feature/atlas_v4.py','blog/feature/atlas_v5.py','blog/feature/atlas_v7.py','blog/feature/atlas_v8.py','blog/feature/atlas_v9.py','blog/feature/atlas_v10.py','blog/feature/atlas_v11.py','blog/feature/build.py','blog/feature/site.css','blog/feature/site.js','blog/feature/package_feature.py','blog/feature/pilot_status.json','blog/feature/assets/figures.json','blog/feature/assets/v8/person-masks.json','blog/feature/assets/v8/background-check.json','blog/feature/assets/v9/edit-regions.json','blog/feature/assets/v11/edit-regions.json','blog/feature/art/v9/prompt.txt','blog/feature/art/v9/refinement-prompt.txt','blog/feature/art/v10/prompt.txt','blog/feature/art/v10/boat-refinement-prompt.txt','blog/feature/art/v10/retry-prompt.txt','blog/feature/art/v11/prompt.txt','blog/feature/art/v11/working-hand-prompt.txt','blog/feature/assets/v11/harmony-working-hand.json','blog/feature/art/v11/aragoto-edit-prompts.txt','blog/feature/art/v11/sumi-vegetation-prompt.txt','blog/feature/assets/v11/aragoto-sumi-regions.json','blog/feature/art/PROVENANCE.md','blog/data/measurements.json','blog/repro/README.md','blog/repro/environment.md','blog/feature/README.md','blog/repro/prepare.py','blog/repro/contrast_texts.json','blog/repro/UPSTREAM_LICENSE','theory/activation_information_geometry.md','experiments/plans/e5_dual_edit_v2.md']:
        text(rel)
    for rel in ['blog/feature/assets/v12/water-clean-plate.png','blog/feature/art/whale-manifold.png','blog/feature/art/two-controls-one-light.png','blog/feature/art/river-and-rudder.png','blog/feature/art/edo-river-and-rudder.png','blog/feature/art/hasui-pale-river-v7.png','blog/feature/art/hikyaku-geisha-v8.png','blog/feature/art/kabuki-timber-v9.png','blog/feature/art/kabuki-dance-v10-generated.png','blog/feature/art/kabuki-whitewood-v11.png','blog/feature/art/kabuki-harmony-input.png','blog/feature/art/kabuki-working-gesture-generated.png','blog/feature/art/kabuki-aragoto-human-proportions.png','blog/feature/art/kabuki-sumi-vegetation-source.png']:
        binary(rel)
    # Current deterministic stage: explicit public dependency allowlist.
    for name in ['physics.py','fluid_solver.py','hybrid.py','hydro_surface.py','motion.py','render.py','spill.py','surface_raster.py','water_paint.py','make_delivery.py','build_review.py','stage_diagram.py','verify_v21.py','README.md','PRODUCTION_SCRIPT.md','physics-contract.json','verification-v21.json','rig/mesh.py','rig/geometry.json']:
        text('blog/feature/assets/v21/'+name)
    for name in ['v21/water.npz','v21/rig/actor-texture.png','v13/actor-free-plate.png','v14/sluice-reference.png']:
        binary('blog/feature/assets/'+name)
    for name in ['junction.py','fv_core.py','boats.py','run_cases.py','hybrid.py','hydro_surface.py','motion.py','render.py','spill.py','surface_raster.py','water_paint.py','gate_paint.py','waterfall_paint.py','river_flow.py','river_tracers.py','verify_river_continuity.py','river-continuity-qa.json','rigid-pole-qa.json','body-push-qa.json','callouts.py','callouts-qa.json','rig/body_pose.py','make_delivery.py','build_review.py','verify_v22.py','README.md','PRODUCTION_SCRIPT.md','ART_PROVENANCE.md','physics-contract.json','verification-v22.json','rig-verification-v22.json','transparent-walls-qa.json','main-fall-qa.json','browser-qa.json','media-qa.json','fluid-metrics.json','dynamics-metrics.json','stage-board.svg','rig/mesh.py','rig/geometry.json']:
        text('blog/feature/assets/v22/'+name)
    for name in ['straight-reference.png','straight-clean-plate.png','boat_states.npz','rig/actor-texture.png','rig/left-alpha.png','rig/right-alpha.png']:
        binary('blog/feature/assets/v22/'+name)
    wanted=set()
    for item in manifest['figures']:
        for key in ('file','animation','video','mp4','model'):
            if isinstance(item.get(key),str): wanted.add(item[key])
    for folder in ['experiments/wsp_geometry','experiments/wsp_controls','experiments/wsp_generation']:
        for p in sorted((REPO/folder).glob('*.py')): text(str(p.relative_to(REPO)))
    for name in list(wanted):
        sibling=str(Path(name).with_suffix('.svg'))
        if (ROOT/'assets'/sibling).exists(): wanted.add(sibling)
    for name in sorted(wanted): binary(f'blog/feature/assets/{name}')
    for p in sorted((ROOT/'assets'/'paper').glob('*')):
        if p.is_file(): binary(f'blog/feature/assets/paper/{p.name}')
    for p in sorted((ROOT/'vendor').rglob('*')):
        if p.is_file(): binary(f'blog/feature/vendor/{p.relative_to(ROOT/"vendor" )}')
    entries=list({e[1]:e for e in entries if e[2].exists()}.values())
    entries.sort(key=lambda x:x[1])
    OUT.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for kind,arc,src in entries:
            if kind=='text': add_text(z,arc,src)
            else: add_bytes(z,arc,src)
    print(f'Wrote {OUT} with {len(entries)} files')
if __name__=='__main__': main()
