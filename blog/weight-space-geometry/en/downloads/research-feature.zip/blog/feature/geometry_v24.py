"""Fisher geometry as visible lengths, reachable directions and tangency.

The E3 chart reads immutable measurements. Geometric constructions are exact
quadratic toys, not Qwen manifolds or recorded optimization trajectories.
"""
from pathlib import Path
import json
import numpy as np
import atlas_v3 as atlas
from atlas_v24_common import *

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'assets/v24/geometry'
D=json.loads((ROOT.parent/'data/measurements.json').read_text())
F=np.array([[2.,.5],[.5,1.]])
V=np.array([.8,1.4])
J=np.array([[1.],[0.]])
G=J.T@F@J
P=J@np.linalg.solve(G,J.T@F@V)
B=np.array([1.,.8]);C=.6
STAR=C*np.linalg.solve(F,B)/(B@np.linalg.solve(F,B))
EUCLID=C*B/(B@B)
DOSES=[.03,.1,.3,1.]

def chart(origin,scale):
    return lambda p:np.asarray(origin)+np.asarray(p)*np.array([scale,-scale])

def axes(s,xy,limits=(-1.5,1.5,-1.5,1.5),labels=('u_1','u_2')):
    a,b,c,d=limits
    s.path(xy([[a,0],[b,0]]),'#a3b2c6',1.2)
    s.path(xy([[0,c],[0,d]]),'#a3b2c6',1.2)
    for p,label in [([b,0],labels[0]),([0,d],labels[1])]:
        q=xy(p);s.math(q[0]+8,q[1]-8,label,21,MUT)
    dot(s,xy([0,0]),MUT,3)

def fisher(t=1.):
    s=plate('Equal steps. Unequal changes.',
            'A local metric predicts a local effect.', 'FISHER / ANALYTIC MODEL + E3')
    s.text(375,239,'Direction changes the cost',29,INK,True,anchor='middle')
    s.text(1160,239,'Dose tests the approximation',29,INK,True,anchor='middle')
    xy=chart((369,536),145)
    Ft=np.diag([1.,3.])
    # Exact concentric equal-quadratic-cost contours, not loss topography.
    for cost in [1.5,1.,.5]:
        pts=xy(ellipse(Ft,cost=cost))
        s.path(pts,LAV,1.5,opacity=.7,fill='url(#metric-wash)',close=True)
    ang=np.linspace(0,2*np.pi,160)
    s.path(xy(np.c_[np.cos(ang),np.sin(ang)]),'#9eacbf',1.2,'5 6',.8)
    axes(s,xy,(-1.9,1.9,-1.27,1.55))
    # Start along x, rotate a vector of exactly constant Euclidean norm.
    a=float(ease((t-.08)/.26))*np.pi/2
    u=np.array([np.cos(a),np.sin(a)])
    arrow(s,xy([0,0]),xy([1,0]),BLUE,3.4)
    dot(s,xy([1,0]),BLUE,9)
    arrow(s,xy([0,0]),xy(u),GOLD,4)
    dot(s,xy(u),GOLD,10)
    s.math(540,548,r'\|u\|=1',22,MUT)
    s.math(140,307,r'F=\operatorname{diag}(1,3)',23,MUT)
    # The equal-length arrows are compared on a common exact cost scale.
    cost=.5*u@Ft@u
    for yy,label,value,col in [(773,'x',.5,BLUE),(821,'u',cost,GOLD)]:
        s.math(130,yy+6,label,22,col,anchor='end')
        s.line((153,yy),(588,yy),'#e4e9f0',12)
        s.line((153,yy),(153+290*value,yy),col,12)
    s.text(153,734,'quadratic cost',19,MUT)
    if t>=.34:s.math(588,734,r'\times 3',21,GOLD,anchor='end')
    # Fixed-prefix measurements: all points and medians retain their actual values.
    fx,fy=atlas.axis(s,(844,354,650,370),(.025,1.3),(1e-8,.1),
        [(.03,'.03'),(.1,'.1'),(.3,'.3'),(1,'1')],
        [(1e-8,'10^{-8}'),(1e-6,'10^{-6}'),(1e-4,'10^{-4}'),(.01,'10^{-2}'),(.1,'10^{-1}')],
        r'\text{edit dose }\alpha','median KL (nats)',True,True,math_x=True,math_y=True,math_xlabel=True)
    colors={'measured_kl':BLUE,'fisher_prediction':LAV,'weight_norm_prediction':'#a4afbd'}
    labels=['measured','Fisher','weight norm']
    med={key:[float(np.median([r[key] for r in D['e3']['samples'] if r['dose']==d])) for d in DOSES] for key in colors}
    for i,((key,col),label) in enumerate(zip(colors.items(),labels)):
        xx=850+i*210;s.line((xx,287),(xx+25,287),col,3,'5 4' if i else None)
        s.text(xx+35,294,label,20,MUT)
        s.path([(fx(d),fy(v)) for d,v in zip(DOSES,med[key])],col,3,'7 5' if i else None)
        for d,v in zip(DOSES,med[key]):dot(s,(fx(d),fy(v)),col,4)
    active=3 if t>=.91 else max(0,min(3,int((t-.34)/.14)))
    dose=DOSES[active]
    if t>=.34:
        # The highlight jumps between tested doses; it never manufactures data.
        s.line((fx(dose),335),(fx(dose),724),GOLD,1.4,'3 6',.7)
        for row in D['e3']['samples']:
            if row['dose']==dose:s.circle(fx(dose),fy(row['measured_kl']),2.8,GOLD,'none',0)
        dot(s,(fx(dose),fy(med['measured_kl'][active])),BLUE,9)
    s.text(844,823,'32 prefixes · 4 held-out doses',21,MUT)
    ratio=float(np.median([r['fisher_prediction']/r['measured_kl'] for r in D['e3']['samples'] if r['dose']==1]))
    s.math(1494,854,rf'\alpha=1:\ \operatorname{{median}}(\widehat{{\mathrm{{KL}}}}_F/\mathrm{{KL}})={ratio:.2f}',22,INK,anchor='end',max_width=650)
    footer(s,r'\mathrm{KL}(p_h\Vert p_{h+u})\simeq\frac12u^\top F_hu',
           'Left: exact quadratic toy · right: fixed-prefix measurements · the KL approximation is local')
    return s

def duality(t=1.):
    s=plate('Two routes. One reachable move.',
            'Move the weights, or project the desired steering.', 'DUALITY / EXACT TANGENT MODEL')
    s.text(330,239,'Weight space',30,INK,True,anchor='middle')
    s.text(1170,239,'Activation space',30,INK,True,anchor='middle')
    # Both coordinate systems are fixed; only tangent vectors change length.
    left=lambda theta:np.array([180+260*theta,620.])
    xy=chart((1115,720),145)
    s.line(left(-.2),left(1.55),'#a3b2c6',1.4)
    s.math(*[left(1.55)[0]+8,633],r'\delta\theta',22,MUT)
    dot(s,left(0),MUT,5)
    s.math(330,320,r'G_\theta=J^\top FJ',28,LAV,anchor='middle')
    # Pullback unit interval: maps exactly to the F-unit interval on im(J).
    r=1/np.sqrt(G[0,0])
    s.line(left(0),left(r),LAV,16,opacity=.20)
    s.text(330,733,'one permitted direction',22,MUT,anchor='middle')
    arrow(s,(640,510),(785,510),MUT,2)
    s.math(713,488,r'J',28,MUT,anchor='middle')
    axes(s,xy,(-1.4,2.6,-.35,2.9))
    # Cost contours shrink to first tangency with the reachable horizontal line.
    mincost=float(.5*(P-V)@F@(P-V))
    shrink=1-float(ease((t-.06)/.29))
    levels=[mincost,mincost+.12,mincost+.28]
    s.a.append('<clipPath id="projection-clip"><rect x="845" y="260" width="680" height="525"/></clipPath><g clip-path="url(#projection-clip)">')
    for cost in reversed(levels):s.path(xy(ellipse(F,V,cost)),LAV,1.2,opacity=.36,fill='url(#violet-wash)',close=True)
    current=mincost+.28*shrink
    s.path(xy(ellipse(F,V,current)),LAV,2.7,opacity=.85,close=True)
    s.a.append('</g>')
    s.path(xy([[-1.35,0],[2.55,0]]),BLUE,5)
    s.math(1492,760,r'\operatorname{im}J',24,BLUE,anchor='end')
    dot(s,xy(V),GOLD,11)
    s.math(*[xy(V)[0]+22,xy(V)[1]-20],r'v=\nabla_F C',27,GOLD)
    eu=np.array([V[0],0.])
    s.line(xy(V),xy(eu),'#9ba5b4',1.6,'4 6',.8)
    dot(s,xy(eu),MUT,7,True)
    s.text(xy(eu)[0]-7,xy(eu)[1]+60,'Euclidean',20,MUT,anchor='end')
    s.line(xy(V),xy(P),GOLD,2.5,'5 5')
    alpha=float(ease((t-.36)/.28))
    arrow(s,left(0),left(alpha*P[0]),LAV,5)
    dot(s,left(alpha*P[0]),LAV,11)
    arrow(s,xy([0,0]),xy(alpha*P),BLUE,5)
    dot(s,xy(alpha*P),BLUE,11)
    # End-point marker stays hollow until the common induced step reaches it.
    if alpha<.999:
        dot(s,left(P[0]),LAV,9,True);dot(s,xy(P),BLUE,9,True)
    s.math(330,550,r'\nabla_{G_\theta}(C\circ E)',29,LAV,anchor='middle')
    s.math(xy(P)[0]+24,xy(P)[1]+36,r'\Pi_{\operatorname{im}J}^{F}v',27,BLUE)
    s.math(330,830,r'J=(1,0)^\top\quad G_\theta=2',22,MUT,anchor='middle')
    s.math(1160,830,r'F=\begin{pmatrix}2&.5\\.5&1\end{pmatrix}',23,MUT,anchor='middle')
    footer(s,r'J\nabla_{G_\theta}(C\circ E)=\Pi_{\operatorname{im}J}^{F}\nabla_F C',
           'One linear tangent model · gold: desired change · blue: reachable change · contours: mismatch cost',31)
    return s

def efficiency(t=1.):
    s=plate('The same effect. Less distribution change.',
            'Keep the effect fixed; choose the smallest metric cost.', 'EFFICIENCY / EXACT QUADRATIC MODEL')
    xy=chart((430,565),365)
    cost=lambda p:float(.5*p@F@p)
    # All contours are generated by the stated F, with equal unit scaling.
    s.a.append('<clipPath id="eff-clip"><rect x="85" y="240" width="820" height="620"/></clipPath><g clip-path="url(#eff-clip)">')
    for c in [.26,.16,cost(EUCLID),cost(STAR)]:
        s.path(xy(ellipse(F,cost=c)),LAV,1.3,opacity=.55,fill='url(#metric-wash)',close=True)
    axes(s,xy,(-.80,1.08,-.68,.83),('d_1','d_2'))
    tangent=np.array([B[1],-B[0]])/np.linalg.norm(B)
    line=STAR+np.linspace(-.75,.75,120)[:,None]*tangent
    s.path(xy(line),GOLD,3.5)
    s.a.append('</g>')
    s.math(650,298,r'b^\top d=c',27,GOLD,anchor='middle')
    dot(s,xy(EUCLID),MUT,8,True)
    arrow(s,xy([0,0]),xy(EUCLID),MUT,2.4)
    a=float(ease((t-.13)/.47));candidate=(1-a)*EUCLID+a*STAR
    s.a.append('<g clip-path="url(#eff-clip)">')
    s.path(xy(ellipse(F,cost=cost(candidate))),LAV,2.7,opacity=.9,close=True)
    s.a.append('</g>')
    arrow(s,xy([0,0]),xy(candidate),BLUE,4.3)
    dot(s,xy(candidate),BLUE,11)
    dot(s,xy(STAR),BLUE,8,True)
    s.text(xy(EUCLID)[0]+25,xy(EUCLID)[1]+25,'Euclidean',23,MUT)
    s.math(xy(STAR)[0]-24,xy(STAR)[1]-25,r'd^*',28,BLUE,anchor='end')
    s.text(1085,259,'Same target effect',29,INK,True,anchor='middle')
    for yy,col in [(353,MUT),(411,BLUE)]:
        s.line((940,yy),(1400,yy),'#e7ebf2',14)
        s.line((940,yy),(1400,yy),col,14)
    s.math(1440,361,'c',25,GOLD);s.math(1440,419,'c',25,GOLD)
    s.text(1085,538,'Different local cost',29,INK,True,anchor='middle')
    scale=460/cost(EUCLID)
    for yy,col,value in [(624,MUT,cost(EUCLID)),(682,BLUE,cost(candidate))]:
        s.line((940,yy),(1400,yy),'#e7ebf2',14)
        s.line((940,yy),(940+scale*value,yy),col,14)
    s.math(1165,756,r'\frac12d^\top Fd',29,LAV,anchor='middle')
    s.circle(949,815,5,MUT);s.text(965,822,'Euclidean',21,MUT)
    s.circle(1218,815,5,BLUE);s.text(1234,822,'metric-aware',21,BLUE)
    footer(s,r'd^*=\frac{cF^{-1}b}{b^\top F^{-1}b}',
           'Exact quadratic cost · gold line: equal effect · the KL interpretation is local',35)
    return s

def verify():
    OUT.mkdir(parents=True,exist_ok=True)
    assert np.all(np.linalg.eigvalsh(F)>0)
    assert np.allclose(P,[1.15,0])
    b=F@V
    weight=np.linalg.solve(G,J.T@b)
    assert np.allclose(J@weight,P)
    assert np.allclose(J.T@F@(V-P),0)
    assert np.allclose(STAR,[.24324324324324326,.44594594594594594])
    for t in np.linspace(0,1,241):
        d=(1-t)*EUCLID+t*STAR
        assert np.isclose(B@d,C)
        assert .5*d@F@d>=.5*STAR@F@STAR-1e-13
    for q in DOSES:
        rows=[r for r in D['e3']['samples'] if r['dose']==q]
        assert len(rows)==32
        assert all(r['measured_kl']>0 and r['fisher_prediction']>0 for r in rows)
    result={'classification':'exact analytic geometry with separately identified E3 measurements',
      'fisher':{'toy_F':[[1,0],[0,3]],'equal_step_costs':[.5,1.5],
        'doses':DOSES,'evaluation_prefixes':32,'source':'blog/data/measurements.json',
        'medians':{key:[float(np.median([r[key] for r in D['e3']['samples'] if r['dose']==q])) for q in DOSES] for key in ['measured_kl','fisher_prediction','weight_norm_prediction']},
        'median_full_dose_ratio':float(np.median([r['fisher_prediction']/r['measured_kl'] for r in D['e3']['samples'] if r['dose']==1]))},
      'duality':{'F':F.tolist(),'J':J.tolist(),'G':G.tolist(),'v':V.tolist(),'differential_b':b.tolist(),'weight_natural_gradient':weight.tolist(),'induced_and_projected':P.tolist(),'euclidean_projection':[.8,0.]},
      'efficiency':{'F':F.tolist(),'b':B.tolist(),'c':C,'d_star':STAR.tolist(),'d_euclid':EUCLID.tolist(),'cost_star':float(.5*STAR@F@STAR),'cost_euclid':float(.5*EUCLID@F@EUCLID),'equal_effect_candidates_checked':241},
      'motion_semantics':'analytic interpolation and discrete highlights of measured doses; no recorded search or optimization trajectory'}
    (OUT/'model.json').write_text(json.dumps(result,indent=2)+'\n')
    print('v24 Fisher, pullback/projection, equal-effect model checks: PASS',flush=True)
    return result
