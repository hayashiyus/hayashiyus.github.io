# Original allegories and editorial plates

## Whale — selected cover, 5 November 2026

- Created inside Figma's **Create image** UI, model **GPT Image 2.5 Sunburst**.
- Figma document: https://www.figma.com/design/ot7ouesgGj6UOvQ93PPHUE
- Original image node: `5:21344`. Export: `whale-manifold.png`, 1600 × 1000.
- Visual reference: the elephant illustration supplied by the user, from deep Manifold / BetaTomorrow. The reference image was attached in Figma as visual context. The resulting composition depicts a whale and is an original generated image; it is not represented as BetaTomorrow's work or endorsement.
- Brief: natural-history graphite and watercolor, a monumental whale, translucent cobalt/lavender mesh sheets inside the torso, tiny researchers, small golden intervention points, a repeated coral trajectory and a blue continuation, white paper, no generated labels.
- The generated anatomy is illustrative rather than zoological or mechanistic evidence. The illustrated handles do not encode the exact number of edited weights. Curves inside the animal are not a measured Qwen manifold.
- Exact wording, leader lines, data plots and mathematical geometry are composed separately in `../atlas_v3.py`. The generated painting is a raster; these overlays are SVG vectors.

## Optical bench — mechanism allegory

- Generated inside the same Figma document, **GPT Image 2.5 Sunburst**. Original image node `2:3`.
- Export: `two-controls-one-light.png`.
- Two adjustable curved glass membranes and a shared output screen provide a visual analogy for changing the writer versus changing its state.
- This is not a depiction of a physical mechanism in Qwen. The identity alongside it is exact for a linear writer in real arithmetic; finite-precision reconstruction is measured separately.

## Figure construction and motion

- Final candidates: `../assets/v3`. Earlier `v2` figures were rejected and are not included in the build.
- Typography: Georgia (serif) with sans-serif metadata. White paper, cobalt, muted lavender, gold and restrained coral; numbered explanatory rails and bottom takeaway bands.
- SVG geometry is computed from declared functions, retaining editable curves, polygons and labels in the source. Figma imports may convert text to vector outlines; the source SVG and Python retain editable wording.
- Five GIFs share the same composition and renderer as their static counterparts. Motion depicts (1) schematic attention along the whale, (2) an exact signed scalar gate, (3) four measured doses, (4) a path on the restricted quadratic cost, (5) one synchronized probability path in dual coordinates.
- All empirical numbers are read from `../../data/measurements.json`. No metric surface is described as a measured Qwen landscape.

## v4 — river and rudder (5 November 2026)

- Asset: `river-and-rudder.png` (1536×1024).
- Generated directly in Figma with GPT Image 2.5 Sunburst, node `9:11`, file `ot7ouesgGj6UOvQ93PPHUE`; one AI-credit-consuming generation.
- Original concept: adjusting a shared sluice versus nudging a current boat. Graphite figures, watercolor granulation, pale blue/lavender transparent layers, sparse gold intervention cues, white paper. No copied logo, text, or exact arrangement of a reference artwork.
- Scientific scope: an allegory of stored rules versus present-state intervention, not a measured Qwen geometry. Activation steering may itself follow a state-dependent policy; the cover depicts one intervention, not a restriction to constant steering.
- Composition: `atlas_v4.py`, exact text/leader lines over a content bitmap. The generated bitmap is preserved; only its empty outer margins are reframed in the SVG viewport.
- Editable plates imported through Figma’s standard SVG import into page `8:27675` (`04 — Causal atlas · v4`), with native text changed to Source Serif 4. Source SVG/website uses Georgia. Native Figma PNG exports in `figma/export-v4/`.
- Replaced v3 whale opener and optical-bench mechanism card because their causal mapping was too weak, despite pleasing texture. Older assets remain in the working source for comparison.

## v5 — Edo river and paired mechanism (6 November 2026)

- Assets: `../assets/v5/cover.png` (1600 × 1200) and `../assets/v5/mechanism.png` (1600 × 1000), with GIF/MP4 motion and editable SVG companions.
- The cover bitmap `edo-river-and-rudder.png` was generated as an original mixed Japanese/Western watercolor in Figma and composed with native explanatory overlays. It is Edo-inspired, not a historical reproduction, copied artwork, or claim of historical provenance.
- The mechanism plate is a declared exact toy rendered by `atlas_v5.py`: states A=(1,0), B=(0,1), C=(−1,0), W=I, k=(1,0), d=(0,.7). The paired weight-writer and current-state hook agree algebraically; the animation is not a Qwen trajectory or measured activation embedding.
- The visual language uses Japanese/Edo-inspired human figures and river motifs only as explanatory framing. The main computation in `model.json` pairs the stored shared rule with a live, state-dependent hook; a separate ledger contrasts a single push on A. Boats encode input tokens, horizontal motion is execution order, and vertical displacement is the activation increment—not water dynamics.

- Figma original painting node `10:28079`, page **05 — Edo river · causal edition**. Final native composition page `12:2`, **06 — Japanese atlas · editable & motion**; cover `12:309`, GIF `12:639`. Three A/B/C frames retain native text and vector arrows; the GIF is an imported animated image, not a Figma-native keyframe timeline.
- Additional references inspected: [Alex Wang](https://alexwang.ai/) (ink/watercolor bird, bamboo, whitespace and serif editorial type) and [Goodfire’s neural-geometry article](https://www.goodfire.com/research/can-saes-capture-neural-geometry) (its historical elephant painting and modern editorial setting). These informed the balance of brushwork, volume and whitespace; neither artwork was copied into the blog.
- Rendered and checked at desktop and mobile sizes. Native Figma overlays use Source Serif 4; the reproducible website artwork uses Georgia. The generated painting is the same asset in both.

Selection status: v5 remains preserved as the earlier causal cover/mechanism trial; it is not the selected cover after the v7 review.

## v6 — dark trial (rejected, 6 November 2026)

- Asset: `../assets/v6/cover.png`, retained for comparison only.
- This dark cover trial was rejected for the selected feature direction; it is not used by the manifest or public staging.

## v7 — Modern Hasui · pale river (superseded history, 6 November 2026)

- Selected asset: `hasui-pale-river-v7.png`; the v7 renderer also preserves `../assets/v7/cover.png` and its SVG source. The cover is 1600 × 1280.
- Figma UI generation used GPT Image 2.5 Sunburst with two edits from the cloned original node `9:11` to `19:12`. Native Figma page `19:11` is **08 — Modern Hasui · pale river**; the selected native composition is cover `21:11`, with image `21:31` and twelve native-text/seven-vector overlays.
- The image is an original modern shin-hanga/Hasui-inspired pale high-key river watercolor. It borrows principles of atmospheric distance, restrained color, and spacious composition; it is not a historical reproduction, a recovered Hasui work, or a measured Qwen landscape.
- The v5 mechanism and v4/v3 plates remain selected for their scientific content; v7 changes the cover art only. No experiment or scientific conclusion is changed.

Selection status: v7 is preserved as the superseded pale-river trial; v8 is the selected cover.

## v8 — Hikyaku and geisha river cover (superseded history, 6 November 2026)

- Selected assets: `../assets/v8/cover.png` (1600 × 1280), `../assets/v8/cover.svg`, and the original source artwork `hikyaku-geisha-v8.png`. The v8 mask and background-check JSON are included as source metadata; provided reference photographs are not bundled.
- Generated in Figma with GPT Image 2.5 Sunburst using three provided photo references, then composed by clipping image-fill silhouettes over the retained original `river-and-rudder.png`. The selected figures are realistically rendered Edo-inspired characters depicting a tattooed courier and geisha; the result is graphite/watercolor allegory, not a historical reproduction or a measured Qwen landscape.
- Figma raw source is `27:11` on page `24:11`; the annotated native editable cover is `34:11`, with composite painting `34:31`. Visible silhouette nodes are `32:11` (courier) and `33:12` (geisha). The selected Figma file is https://www.figma.com/design/ot7ouesgGj6UOvQ93PPHUE?node-id=34-11.
- The central-region comparison between the retained original and the v8 export is not pixel-identical: mean channel difference is 0.303/255 and maximum difference is 9/255. This is a render-composition check, not a claim of exact pixel equality.
- The cover retains the explanatory boundary that state-dependent steering policies are possible; its river, figures, and rudder are visual intuition only.

Selection status: v8 is preserved as superseded history; v9 is also superseded, v10 was a rejected dramatic-leap test, and v11 is the selected cover.

## v9 — Kabuki and timber canal (superseded history, 6 November 2026)

- Selected asset: `kabuki-timber-v9.png`; the v9 renderer also produces `../assets/v9/cover.png` (1600 × 1280) and its SVG source. Prompt and refinement records are retained under `art/v9/`; user reference photographs are not bundled.
- The Figma pipeline used GPT Image 2.5 Sunburst with two costume-reference photos, followed by a wood-only near-white refinement. The final composition starts from the original river-and-rudder base and applies three editable image-fill regions for the two actors and canal/water interface, preserving the sky, boats, and lower landscape; these are not alpha masks.
- Raw generation is `39:12` on page `39:11`; wood refinement is `42:11`; the final annotated native cover is `46:11` with painting `46:31` and twelve editable text layers. The image uses an adult male Kabuki actor with a long white mane in black/gold costume at left and an adult male Kabuki actor in a red/purple kimono at right. These are original realistic graphite/watercolor figures, not historical reproduction or measured Qwen evidence.
- The canal walls are near-white timber in the selected composition; the serpentine layout, boats, and landscape remain from the underlying allegory. Background comparison is a render check only; it must not be described as pixel-identical.

## v10 — Kabuki dance leap test (rejected history, 6 November 2026)

- Source artwork: `kabuki-dance-v10-generated.png`; prompt records are retained under `art/v10/`.
- This trial exaggerated the actors’ motion into a dramatic leap and was not selected. It remains historical design exploration, not a scientific result.

## v11 — Kabuki poised motion (selected, 6 November 2026)

- Selected asset: `kabuki-whitewood-v11.png`; the v11 renderer produces `../assets/v11/cover.png` (1600 × 1280), its SVG, and `edit-regions.json`. Prompt records are retained under `art/v11/`; user reference photographs are not bundled.
- Generated in Figma with GPT Image 2.5 Sunburst from the refined v9 source `42:11`. Raw generation is `55:12` on page `55:11`; final raw/source composition is `57:11` with original base `57:12`; three editable image-fill regions are `57:14`, `57:16`, and `57:18`; final annotated native cover is `58:11` with painting `58:31` and twelve editable text layers.
- The selected scene keeps the pale graphite/watercolor background, boats, and serpentine canal. It shows an adult male white-long-mane actor in black/gold at left and an adult male red/purple actor at right with only slight spring/dance motion beside a near-white timber canal. The artwork is original visual allegory, not historical reproduction or measured Qwen evidence.
- The original background sits beneath three crop regions; transitions are intentionally included and are not exact object segmentation or a pixel-equality claim.

## v11 gaze correction — 2026-11-06

The user requested that the red-and-purple actor look at the paper boat touched by his pole. A Figma AI edit of a duplicate generated a downward, image-left head/gaze. Only the 95 × 121 px head region was composited over the existing painting as an editable vector image fill (raw patch `62:12`, cover patch `62:14`; generated source `60:2`). The original layers remain below the patch. Pixel comparison of the exported painting against the before-gaze backup found no changed pixels outside `(1294,297)–(1389,418)`. The selected cover remains `58:11`.

## v11 left gaze correction — 2026-11-06

The left white-haired actor now turns his head and gaze down-right toward the first upstream paper boat. A first Figma generation was rejected because the gaze remained ambiguous; a refined face was selected. Only a 98 × 103 px head region was composited onto the previously approved painting (raw patch `69:12`, cover patch `69:14`; source `63:2`). The right actor’s prior gaze correction is preserved. Export comparison found no changed pixels outside `(170,142)–(268,245)` relative to the before-left-gaze backup. The cover remains `58:11`.


## v11 aragoto and ink-brush vegetation — 2026-11-06

Figma GPT Image 2.5 Sunburst edits corrected the right actor to a five-lock wig on each side, plain scarlet robe with gold shoulder crests, and a thick purple/ivory Nio tasuki. Full-scene attempts retained floral ghosts and a hairpin; those candidates were rejected in favor of a cropped-detail refinement. A further edit shortened the exposed forehead and upper head, preserving a downward-left gaze. These are visual editorial choices, not a measured anthropometric validation.

The selected actor source is `76:12` (640 × 960), registered at `(1243,272)` with display size `320 × 480` and clipped into raw patch `84:32` / cover patch `84:54`. The earlier patches remain hidden below. A separate source `80:11` supplied nine localized vegetation regions using ink contours, dry-brush branches, and grey washes. The original golden pole is restored over the vegetation layer. Regions include nearby transition pixels and some ground/rocks; no pixel-equality claim is made for those regions.

Current raw artwork remains `57:11`; cover remains `58:11`. Geometry and composition records are in `assets/v11/aragoto-sumi-regions.json`. Prompt records are in `art/v11/aragoto-edit-prompts.txt` and `art/v11/sumi-vegetation-prompt.txt`. User reference photographs are excluded from the portable archive.


## v11 pigment harmony and working left hand — 2026-11-06

The user requested less vivid clothing and then a credible working movement for the right actor's left hand. Figma image-fill filters were applied locally: left costume saturation −0.24, exposure +0.05, shadows +0.16; right costume saturation −0.34, exposure +0.09, shadows +0.12. These are Figma slider values, not measured perceptual percentages. Native unfiltered overlays preserve the approved faces, hair and hands while the costume filters remain reversible.

A cropped Figma GPT Image 2.5 Sunburst edit then replaced the raised open left palm with an upper grip on the same golden pole. The elbow and sleeve were redrawn for a plausible two-handed working posture. This torso/arm patch covers the obsolete palm overlay and its earlier color-mask seam. The approved face, five-lock wig, forehead, boats and ink-brush landscape are retained outside that localized patch. Original clothing texture is lifted by filters; the new sleeve itself is generated watercolor.

Harmony input is `86:11`; selected gesture source is `90:13` (672 × 1008). Gesture patches are `94:12` / `94:14`, registered at `(1200,290)`, display size `336 × 504`. Raw painting remains `57:11` and annotated cover remains `58:11`. Complete paths, filter values and node IDs are in `assets/v11/harmony-working-hand.json`; prompt is `art/v11/working-hand-prompt.txt`. This revision changes the cover illustration only.
