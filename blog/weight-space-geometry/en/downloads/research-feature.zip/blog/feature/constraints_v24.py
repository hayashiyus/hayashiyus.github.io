"""Low-text constraint plates for the paper's exact analytic toys.

The three functions intentionally share one restrained visual grammar.  They
are still SVG-native: every arrow, point, axis and equation remains editable;
the only raster dependency is the prepared KaTeX label cache.
"""
from pathlib import Path
import json
import math
import numpy as np

import atlas_v3 as atlas

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "assets" / "v24" / "constraints"
PAPER = "#fffefc"
INK, MUT = "#263653", "#71819a"
BLUE, LAV, GOLD = "#4b83c7", "#9b98d3", "#d2a252"
DURATION, FPS = 12.0, 24

# Exact eight-input reachability toy from geometry_v20.py.
TH = np.arange(8) * 2 * np.pi / 8
A8 = np.array([np.cos(TH), np.sin(TH)])
V8 = np.array([.35*np.cos(TH) + .38*np.cos(2*TH),
               .55*np.sin(TH) + .42*np.sin(3*TH)])
W8 = V8 @ np.linalg.pinv(A8)
U8 = W8 @ A8
R8 = V8 - U8
RESIDUAL_FRACTION = float(np.linalg.norm(R8) / np.linalg.norm(V8))

# Exact three-class softmax path from atlas_v4.py.
P0 = np.array([.62, .23, .15])
P1 = np.array([.14, .26, .60])


def _plate(title, subtitle, tag):
    s = atlas.SVG(title, subtitle, tag)
    s.a[0] = s.a[0].replace('fill="#fff"', f'fill="{PAPER}"')
    return s


def _arrow(s, p, q, color=BLUE, width=3, opacity=1):
    p, q = np.asarray(p, float), np.asarray(q, float)
    v = q - p; nrm = np.linalg.norm(v)
    if nrm < 1e-8:
        s.circle(*p, 2.5, color, 'none', 0); return
    u = v / nrm; n = np.array([-u[1], u[0]])
    head = min(13., nrm * .32)
    base = q - u * head
    s.line(p, base, color, width, opacity=opacity)
    s.path([q, base+n*head*.35, base-n*head*.35], color, 0,
           opacity=opacity, fill=color, close=True)


def _chart(p, origin=(800, 545), scale=190):
    p = np.asarray(p, float)
    return np.stack((origin[0] + scale*p[..., 0], origin[1] - scale*p[..., 1]), -1)


def _ease(t):
    t = float(np.clip(t, 0, 1)); return t*t*(3-2*t)


def _progress(t):
    """Editorial motion: hold, move, then hold the solved state."""
    return _ease((float(t) - .10) / .50)


def reachability(t=1):
    """One registered chart: requested, realized, and residual at eight anchors."""
    s = _plate('Eight requests. One shared matrix.',
               'The same map moves every anchor.', '06 / REACHABILITY')
    # Fixed chart frame: the shared matrix is the only moving object.
    x0, y0, sc = 950, 540, 180
    for z in np.arange(-1.5, 1.51, .5):
        s.line((x0-2.15*sc, y0-z*sc), (x0+2.15*sc, y0-z*sc), '#dfe6f0', .8)
        s.line((x0+z*sc, y0-2.15*sc), (x0+z*sc, y0+2.15*sc), '#dfe6f0', .8)
    s.line((x0-1.65*sc, y0), (x0+1.65*sc, y0), '#9eafc4', 1.2)
    s.line((x0, y0-1.65*sc), (x0, y0+1.65*sc), '#9eafc4', 1.2)
    s.math(800, 875, r'\Delta W^*=VA^+\quad\text{and}\quad r_i(\alpha)=v_i-\alpha\Delta W^*a_i', 28, INK, anchor='middle')
    s.math(82, 280, r'v_i\;\text{desired}', 24, BLUE)
    s.math(82, 327, r'\alpha\Delta W^*a_i\;\text{realized}', 24, LAV)
    s.math(82, 374, r'r_i(\alpha)=v_i-\alpha\Delta W^*a_i', 23, GOLD)
    a = _progress(t)
    s.math(88, 432, r'\alpha', 22, MUT)
    s.line((122, 425), (390, 425), '#dce3ec', 5)
    s.line((122, 425), (122 + 268*a, 425), GOLD, 5)
    s.circle(122 + 268*a, 425, 7, GOLD, PAPER, 2)
    s.text(122, 456, '0', 17, MUT, anchor='middle')
    s.text(390, 456, '1', 17, MUT, anchor='middle')
    s.text(256, 456, 'shared strength', 17, MUT, anchor='middle')
    for i in range(8):
        base = _chart(A8[:, i], (x0, y0), sc)
        desired = _chart(A8[:, i] + .75*V8[:, i], (x0, y0), sc)
        realized = _chart(A8[:, i] + .75*a*U8[:, i], (x0, y0), sc)
        # Requested endpoint stays fixed while the shared-map endpoint moves.
        target = desired
        _arrow(s, base, desired, BLUE, 2.6, .75)
        _arrow(s, base, realized, LAV, 4.1, .95)
        s.line(realized, target, GOLD, 2.2, dash='6 5', opacity=.9)
        s.circle(*base, 5, PAPER, INK, 1.2)
        s.circle(*target, 4, PAPER, GOLD, 1.1)
    s.math(800, 920, rf'\|R_*\|_F/\|V\|_F={RESIDUAL_FRACTION*100:.1f}\%\quad\text{{best attainable}}', 29, GOLD, anchor='middle')
    s.text(800, 955, 'one chart · one shared map · eight paired endpoints', 19, MUT, anchor='middle')
    return s


def _simplex(p):
    verts = np.array([[1010., 680.], [1490., 680.], [1250., 320.]])
    return np.asarray(p) @ verts


def coordinates(t=.5):
    """Synchronized natural-coordinate and simplex views of one probability."""
    s = _plate('One distribution. Two coordinate systems.',
               'The state is shared; the paths are not.', '07 / COORDINATES')
    s.math(92, 252, r'h=\left(\log\frac{p_1}{p_3},\log\frac{p_2}{p_3}\right)', 26, INK)
    s.math(930, 252, r'\eta=(p_1,p_2),\quad p_3=1-p_1-p_2', 25, INK)
    # Fixed natural-coordinate chart.
    left = lambda h: np.array([385 + 125*h[0], 495 - 125*h[1]])
    s.box(90, 300, 610, 390, '#f6f8fc', 3)
    for z in [-2, -1, 0, 1, 2]:
        s.line(left((z, -1.45)), left((z, 1.45)), '#d6e1ef', .8)
        s.line(left((-2.25, z/1.5)), left((2.25, z/1.5)), '#d6e1ef', .8)
    verts = np.array([[1010., 680.], [1490., 680.], [1250., 320.]])
    s.path(verts, '#aabbd6', 1.3, fill='#eff3fa', close=True)
    for z in [.2, .4, .6, .8]:
        for i in range(3):
            p = np.zeros(3); q = np.zeros(3); p[i] = q[i] = z
            p[(i+1)%3] = 1-z; q[(i+2)%3] = 1-z
            s.line(_simplex(p), _simplex(q), '#c6cde3', .8)
    for point, lab in zip(verts, [r'p_1=1', r'p_2=1', r'p_3=1']):
        s.math(point[0], point[1] + (30 if point[1] > 500 else -15), lab, 20, MUT, anchor='middle')
    tt = np.linspace(0, 1, 121)
    ps = P0[None, :] + tt[:, None]*(P1-P0)
    hs = np.log(ps[:, :2] / ps[:, 2, None])
    s.path([left(h) for h in hs], BLUE, 3.5)
    s.path([_simplex(p) for p in ps], BLUE, 3.5)
    for j in [0, 30, 60, 90, 120]:
        s.circle(*left(hs[j]), 4, PAPER, BLUE, 1.2)
        s.circle(*_simplex(ps[j]), 4, PAPER, BLUE, 1.2)
    # Equal-time ticks are equal steps in probability space; only the editorial
    # hold/move envelope is eased by the outer progress schedule.
    a = float(np.clip((float(t)-.10)/.50, 0, 1)); p = P0 + a*(P1-P0); h = np.log(p[:2]/p[2])
    s.circle(*left(h), 11, GOLD, PAPER, 2); s.circle(*_simplex(p), 11, GOLD, PAPER, 2)
    for i, col in enumerate([BLUE, LAV, GOLD]):
        x = 88 + i*205; s.math(x, 785, rf'p_{i+1}', 22, INK)
        s.box(x, 802, 160, 14, '#e9eef6', 5); s.box(x, 802, 160*p[i], 14, col, 5)
    s.math(800, 895, r'\eta=\nabla\psi(h)\quad\text{(Amari duality)}', 29, INK, anchor='middle')
    s.text(800, 935, 'same probability bars · same t · no weight/activation identification', 17, MUT, anchor='middle')
    return s


def impossibility(t=1):
    """Two linked outputs and a target off the reachable line."""
    s = _plate('One scalar. Two linked outputs.', 'A shared weight cannot make both shifts positive.', '08 / IMPOSSIBILITY')
    s.math(120, 275, r'h_w(x)=wx', 39, BLUE)
    s.box(95, 340, 380, 112, '#f4f7fb', 12); s.math(125, 390, r'x=+1\;\Rightarrow\;\Delta h=+\delta w', 25, INK)
    s.box(95, 480, 380, 112, '#f1eff9', 12); s.math(125, 530, r'x=-1\;\Rightarrow\;\Delta h=-\delta w', 25, INK)
    s.math(95, 665, r'\text{target: }(+d,+d)', 28, GOLD)
    # response plot: line is exact reachable set, point is unreachable request.
    x0, y0, sc = 900, 545, 145
    for z in [-1, 0, 1]:
        s.line((x0-1.6*sc, y0-z*sc), (x0+1.6*sc, y0-z*sc), '#e0e7f0', .8)
        s.line((x0+z*sc, y0-1.6*sc), (x0+z*sc, y0+1.6*sc), '#e0e7f0', .8)
    # Model axes: u_1 is horizontal and u_2 is vertical.  Since the screen
    # y-axis is inverted, (w,-w) appears as a down-right line.
    s.line((x0-1.55*sc, y0-1.55*sc), (x0+1.55*sc, y0+1.55*sc), BLUE, 5)
    s.line((x0-1.55*sc, y0), (x0+1.55*sc, y0), '#9eafc4', 1.1)
    s.line((x0, y0-1.55*sc), (x0, y0+1.55*sc), '#9eafc4', 1.1)
    s.math(x0+1.55*sc, y0+24, r'u_1=\Delta h(+1)', 21, MUT, anchor='end')
    s.math(x0+16, y0-1.55*sc+5, r'u_2=\Delta h(-1)', 21, MUT)
    s.math(1140, 720, r'u_2=-u_1', 25, BLUE)
    d = 1.0; target = np.array([x0+d*sc, y0-d*sc])
    s.circle(*target, 10, PAPER, GOLD, 2.5); s.math(target[0]+16, target[1]-14, r'(+d,+d)', 23, GOLD)
    w = _progress(t)
    # Two linked local readouts make the opposite signs visible before the
    # reader has to interpret the joint response plane.
    for yy,sign,col in [(424,1,BLUE),(564,-1,LAV)]:
        s.line((175,yy),(395,yy),'#c6d1e2',1)
        s.circle(285,yy,4,PAPER,INK,1)
        _arrow(s,(285,yy),(285+95*sign*w,yy),col,3.5)
        s.circle(285+95*sign*w,yy,6,col,PAPER,1)
    current = np.array([x0+w*sc, y0+w*sc])
    _arrow(s, (x0, y0), current, LAV, 4)
    s.circle(*current, 9, LAV, PAPER, 2)
    s.math(800, 900, r'(\delta h(+1),\delta h(-1))=(\delta w,-\delta w)', 29, INK, anchor='middle')
    s.text(800, 938, 'bias or another editable path changes the reachable set', 17, MUT, anchor='middle')
    return s


def verify():
    """Numerical invariants for every animated frame; no optimization claims."""
    assert np.allclose(U8, W8 @ A8)
    # Every requested arrow decomposes exactly into realized arrow + residual.
    assert np.allclose(U8 + R8, V8)
    assert np.allclose(A8[:, 0], np.array([1., 0.]))
    assert np.linalg.norm(R8 @ A8.T) < 1e-12
    assert np.isclose(RESIDUAL_FRACTION, .6558522160191071)
    # The impossible target (d,d) has Euclidean distance sqrt(2)d from
    # reachable line u_1+u_2=0 when d=1.
    target = np.array([1., 1.]); assert np.isclose(abs(target.sum())/np.sqrt(2), np.sqrt(2))
    ts = np.linspace(0, 1, 17)
    path = np.array([P0 + t*(P1-P0) for t in ts])
    assert np.allclose(np.diff(path, axis=0), (P1-P0)/16)
    for t in np.linspace(0, 1, 241):
        p = P0 + t*(P1-P0); h = np.log(p[:2]/p[2])
        q = np.r_[np.exp(h), 1.]; q /= q.sum()
        assert np.allclose(q, p) and np.all(p > 0)
        w = _ease(t)
        # Explicit model-to-screen check for the impossibility plot.  The
        # screen y coordinate is inverted, so (w,-w) has positive slope.
        x0, y0, sc = 900., 545., 145.
        screen = np.array([x0 + w*sc, y0 + w*sc])
        assert np.isclose(screen[1]-y0, screen[0]-x0)
        target_model = np.array([1., 1.])
        reachable_normal = np.array([1., 1.])
        assert not np.isclose(reachable_normal @ target_model, 0.)
    OUT.mkdir(parents=True, exist_ok=True)
    record = {'classification': 'exact analytic toy figures; not measured Qwen geometry or optimization records',
              'reachability': {'A': A8.tolist(), 'V': V8.tolist(), 'W_star': W8.tolist(),
                               'realized': U8.tolist(), 'residual': R8.tolist(),
                               'residual_fraction': RESIDUAL_FRACTION},
              'coordinates': {'p0': P0.tolist(), 'p1': P1.tolist(),
                              'path': 'p(t)=(1-t)p0+t p1; h_i=log(p_i/p_3)'},
              'impossibility': {'model': 'h_w(x)=w x', 'inputs': [1, -1],
                                'reachable': '(delta_w,-delta_w)', 'target': '(d,d)',
                                'bias_caveat': True}, 'duration_seconds': DURATION, 'fps': FPS}
    (OUT/'model.json').write_text(json.dumps(record, indent=2) + '\n')
    print('constraints_v24 invariants: PASS')


if __name__ == '__main__':
    verify()
