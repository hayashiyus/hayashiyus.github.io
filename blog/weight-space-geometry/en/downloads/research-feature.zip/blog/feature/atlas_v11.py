"""Kabuki actors and a near-white timber canal: Figma painting, editable typography.

The channel is an allegory, not a simulation or a measured neural manifold.
The generated image is embedded without cropping, recoloring, or opacity edits.
"""
from pathlib import Path
import subprocess
from atlas_v3 import SVG

R = Path(__file__).resolve().parent
O = R / 'assets' / 'v11'
O.mkdir(parents=True, exist_ok=True)
INK, MUT, LEADER = '#243b50', '#718295', '#91a7b9'

def cover():
    s = SVG('Steer the boat. Or change the river.',
            'A stored rule and a live intervention can produce the same local move.',
            '01 / KABUKI · A MOMENT OF MOTION')
    s.a[0] = s.a[0].replace('height="1000"', 'height="1280"').replace('0 0 1600 1000', '0 0 1600 1280')
    # Keep the painting below the header and all overlay labels above the bitmap.
    s.image(R / 'art' / 'kabuki-whitewood-v11.png', 32, 174, 1536, 1024)
    s.text(620, 287, 'Change the river', 31, INK, True)
    s.lines(620, 325, ['A stored rule acts', 'on each arriving state.'], 23, MUT, 30)
    s.path([(598, 344), (496, 344), (302, 481)], LEADER, 1.4)
    s.circle(302, 481, 4, '#c4a064', 'white', 1.2)
    s.text(1000, 390, 'Steer one boat', 31, INK, True)
    s.lines(1000, 429, ['A direct move changes', 'the present state.'], 23, MUT, 30)
    s.path([(1118, 480), (1118, 628), (1227, 818)], LEADER, 1.4)
    s.circle(1227, 818, 4, '#c4a064', 'white', 1.2)
    s.box(48, 1180, 1504, 57, '#f0f5f8', 10)
    s.text(800, 1217, 'A stored weight rule can become a live, state-dependent steering policy.',
           29, INK, True, anchor='middle')
    s.text(800, 1263, 'Original Figma-generated allegory · Kabuki actors and a near-white timber canal · not a measured Qwen landscape',
           15, MUT, anchor='middle')
    return s

if __name__ == '__main__':
    svg = O / 'cover.svg'
    svg.write_text(cover().finish())
    subprocess.run(['rsvg-convert', '-o', str(O / 'cover.png'), str(svg)], check=True)
    print(O / 'cover.png')
