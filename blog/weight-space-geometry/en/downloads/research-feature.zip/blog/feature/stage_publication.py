#!/usr/bin/env python3
"""Stage only the current reviewed EN/JA builds for GitHub Pages.

No network calls, git operations or publication are performed here. Legacy
review pages in blog/publish are deliberately outside this allowlist.
"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import re
import html

ROOT = Path(__file__).resolve().parent
SITE = 'https://hayashiyus.github.io'
ARTICLE = '/blog/weight-space-geometry/'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    source = (ROOT/'research.md').read_text()
    title = html.escape(re.search(r'^# (.+)$',source,re.M)[1])
    dek = html.escape(re.search(r'^## (.+)$',source,re.M)[1])
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    article = out/'blog/weight-space-geometry'
    for language, source in [('en', ROOT/'site'), ('ja', ROOT/'site-ja')]:
        if not (source/'index.html').exists():
            raise SystemExit(f'Build {language} before staging.')
        shutil.copytree(source, article/language, dirs_exist_ok=True)
    (out/'.nojekyll').touch()
    (out/'.gitignore').write_text('.DS_Store\n')
    (article/'index.html').write_text('''<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="refresh" content="0;url=en/">
<link rel="canonical" href="https://hayashiyus.github.io/blog/weight-space-geometry/en/">
<title>A Small Switch in a Vast Machine</title></head><body>
<p><a href="en/">Read in English</a> · <a href="ja/">日本語版</a></p>
<script>location.replace('en/'+location.search+location.hash);</script></body></html>''')
    home='''<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>hayashiyus · Research notes</title><meta name="description" content="Research notes on machine learning and information geometry.">
<style>html{color:#263d51;background:#fdfbf8;font:18px/1.7 Georgia,serif}body{max-width:960px;margin:5vh auto;padding:24px}h1{font-size:clamp(24px,4vw,38px);line-height:1.2}a{color:#315e81}img{width:100%;height:auto}nav{display:flex;gap:24px}small{font:14px/1.6 system-ui,sans-serif}</style>
</head><body><small>hayashiyus · Research notes · 8 November 2026</small>
<h1>A Small Switch in a Vast Machine</h1><p>Why Astra could edit Qwen—and what information geometry explains.</p>
<a href="blog/weight-space-geometry/en/"><img src="blog/weight-space-geometry/en/assets/v22/poster-callouts.jpg" alt="Two Kabuki actors change a boat's course by controlling the water or pushing the boat."></a>
<nav><a href="blog/weight-space-geometry/en/">Read in English →</a><a href="blog/weight-space-geometry/ja/" lang="ja">日本語で読む →</a></nav>
</body></html>'''
    home=home.replace('A Small Switch in a Vast Machine',title).replace('Why Astra could edit Qwen—and what information geometry explains.',dek)
    (out/'index.html').write_text(home)
    (out/'README.md').write_text('''# hayashiyus.github.io

Reviewed static research blog, published with GitHub Pages from `main` at `/`.

- [English article](https://hayashiyus.github.io/blog/weight-space-geometry/en/)
- [日本語版](https://hayashiyus.github.io/blog/weight-space-geometry/ja/)
- [Source archive and reproduction materials](blog/weight-space-geometry/en/downloads/research-feature.zip)

The archive contains the editable article sources, build scripts, selected media,
measurement aggregates, model revisions and reproduction instructions. Its README
distinguishes completed probes, mathematical examples and unperformed experiments.
Model weights and benchmark data are obtained separately. The E5 file is a planning
snapshot, not a runnable experiment package. Third-party material retains its own
licenses and attribution; see the archive and article for provenance.

Only current reviewed English and Japanese builds are staged here. Local review
pages, connection scripts, credentials and server-specific information are excluded.
`publication.json` records hashes of the reviewed manuscripts and figure manifests.
''')
    files = ['research.md','research.ja.md','assets/figures.json','assets/figures.ja.json',
             'translations/prepublication-corrections.json','translations/editorial-revision.json',
             'translations/conclusion-outlook-20261109.json','editorial_release.py',
             'translations/editorial-release-qa.json','build.py','build_ja.py','site.css','site.js']
    record = {'publication_date':'2026-11-08','updated_date':'2026-11-09','source_sha256':{
        p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in files}}
    (out/'publication.json').write_text(json.dumps(record, indent=2)+'\n')
    urls = [SITE+'/', SITE+ARTICLE+'en/', SITE+ARTICLE+'ja/']
    (out/'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?>\n'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+
        ''.join(f'<url><loc>{url}</loc><lastmod>2026-11-09</lastmod></url>' for url in urls)+'</urlset>\n')
    (out/'robots.txt').write_text(f'User-agent: *\nAllow: /\nSitemap: {SITE}/sitemap.xml\n')
    print(f'Staged reviewed site at {out}')


if __name__ == '__main__':
    main()
