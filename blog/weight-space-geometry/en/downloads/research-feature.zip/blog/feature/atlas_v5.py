"""Edo river edition: Figma painting and a computational, paired-motion proof.

All routes are execution diagrams, not measured activation embeddings. The
moving paper boats are tokens; only their displacement encodes a numerical
quantity. Both implementations receive the same current input.
"""
from pathlib import Path
import json
import numpy as np
import atlas_v3 as a
import atlas_v4 as b

R=Path(__file__).resolve().parent
O=R/'assets/v5'; O.mkdir(parents=True,exist_ok=True)
INK=a.INK; BLUE=a.BLUE; LAV=a.LAV; GOLD=a.GOLD; MUT=a.MUT
STATES=np.array([[1.,0.],[0.,1.],[-1.,0.]])
K=np.array([1.,0.]); D=np.array([0.,.7]); W=np.eye(2)

def cover(t=1):
    s=a.SVG('Steer the boat. Or change the river.',
        'A rule written once. An action computed again. The same local change can take either form.',
        '01 / EDO RIVER ALLEGORY')
    s.a[0]=s.a[0].replace('height="1000"','height="1200"').replace('0 0 1600 1000','0 0 1600 1200')
    s.a.append('<svg x="0" y="180" width="1600" height="910" viewBox="0 180 1600 910">')
    s.image(R/'art/edo-river-and-rudder.png',205,0,1190,1190)
    s.a.append('</svg>')
    s.text(650,247,'Change the writer',32,INK,True)
    s.lines(650,286,['Store a rule that acts','on every arriving state.'],23,dy=29)
    s.path([(650,330),(585,350),(420,425)],BLUE,1.5)
    s.circle(420,425,5,GOLD)
    s.text(1030,247,'Steer the state',32,INK,True)
    s.lines(1030,286,['Apply a move now—or','recompute it on every state.'],23,dy=29)
    s.path([(1020,330),(1010,570),(1135,767)],BLUE,1.5)
    s.circle(1135,767,5,GOLD)
    s.box(48,1100,1504,62,'#edf2fa',12)
    s.text(800,1139,'A stored weight rule can become a live steering policy.',30,INK,True,anchor='middle')
    s.text(800,1185,'Original Figma watercolor • Edo-inspired people and landscape • an analogy, not a measured Qwen manifold',15,MUT,anchor='middle')
    return s

def boat(s,x,y,c=BLUE):
    # Editable paper token: deliberately diagrammatic, not a fake measured state.
    s.path([(x-23,y),(x+24,y),(x+13,y+11),(x-11,y+11)],c,1.2,fill='#e9edf7',close=True)
    s.path([(x-18,y-1),(x+4,y-22),(x+4,y-1)],c,1,fill='#fffdf8',close=True)
    s.path([(x+4,y-22),(x+20,y-1),(x+4,y-1)],c,1,fill='#dce7f4',close=True)
    s.line((x-18,y+15),(x+22,y+15),c,.8,opacity=.4)

def river(s,x,y):
    xx=np.linspace(x+38,x+622,100)
    curve=6*np.sin((xx-x)*.012)
    for off,op in [(19,.12),(10,.18),(0,.38)]:
        top=np.c_[xx,y-19+curve+off];bot=np.c_[xx[::-1],y+25+curve[::-1]+off]
        s.path(np.vstack([top,bot]),'#c8d6e9',.7,opacity=op,fill='#c2d5eb',close=True)
    for dy in [-8,0,8]:
        s.path(np.c_[xx,y+curve+dy],BLUE,.7,opacity=.22)

def mechanism(t=1):
    total=min(2.999999,t*3);j=int(total);local=total-j
    state=STATES[j];gate=float(K@state);u=D*gate
    phase=0 if local<.28 else 1 if local<.56 else 2
    written=float(np.clip((local-.28)/.28,0,1))
    # Explicit read, local write, and transport stages. Horizontal movement is
    # execution order; vertical displacement is the activation increment.
    travel=min(local/.28,1)
    if local<.28: bx=110+210*travel
    elif local<.56: bx=320
    else: bx=320+250*min((local-.56)/.22,1)
    s=a.SVG('One rule. Two implementations.',
        'Give both paths the same current activation. Watch their signed changes agree, state by state.',
        '02 / EXACT LINEAR-WRITER IDENTITY')
    s.box(64,201,1472,101,'#f3f6fb',12)
    s.number(100,238,j+1)
    s.text(135,245,f'Input {"ABC"[j]}',27,INK,True)
    sv=['(1, 0)','(0, 1)','(−1, 0)'][j]
    s.text(280,245,f'a = {sv}',29,BLUE)
    s.text(610,245,f's = kᵀa = {gate:+.0f}',29,BLUE)
    s.text(1030,245,f'Δh = (0, {u[1]:+.2f})',29,INK,True)
    s.text(135,282,f'State {j+1} of 3 · earlier results retained below',18,MUT)
    s.text(610,282,'k = (1, 0) reads the state',18,MUT)
    s.text(1030,282,'d = (0, 0.70) sets the write direction',18,MUT)
    phases=['READ THE CURRENT STATE','APPLY THE SIGNED MOVE','COMPARE RESULTS · HISTORY BELOW']
    s.text(800,336,phases[phase],17,MUT,False,'sans-serif','middle',2)
    for col,x in enumerate([64,838]):
        color=BLUE if col==0 else LAV
        s.text(x+22,389,'Installed in the weights' if col==0 else 'Recomputed by a live hook',29,INK,True)
        s.text(x+22,428,'ΔW = d kᵀ  ·  unchanged across inputs' if col==0 else 'u(a) = d (kᵀa)  ·  called on each input',22,MUT)
        y=558
        river(s,x,y)
        s.line((x+60,y),(x+610,y),'#a5b6cf',1,'5 6')
        # Three reachable scalar shifts, displayed in an explicit diagram scale.
        for g in [-1,1]:
            s.line((x+320,y-84*g),(x+590,y-84*g),'#d6dfea',1,'2 6',.8)
        s.text(x+615,y-78,'+d',19,MUT)
        s.text(x+615,y+6,'0',19,MUT)
        s.text(x+615,y+90,'−d',19,MUT)
        s.text(x+615,448,'Δh ↑',17,MUT)
        b.arrow(s,(x+70,653),(x+255,653),MUT,1.2)
        s.text(x+75,674,'execution order',15,MUT)
        # The installation is constant; the external call lights up each time.
        s.box(x+279,452,82,36, '#eaf0f8' if col==0 else '#f0edf8',5)
        s.text(x+320,477,'d kᵀ' if col==0 else 'u(a)',24,color,True,anchor='middle')
        s.line((x+320,492),(x+320,662),color,1,'3 6',.45)
        bend=np.array([[x+110,y],[x+320,y],[x+320,y-84*gate],[x+570,y-84*gate]])
        s.path(bend,color,2.3,opacity=.30)
        if phase>=1:
            b.arrow(s,(x+320,y),(x+320,y-84*gate*written),GOLD,4)
        py=y-84*gate*written
        boat(s,x+bx,py,color)
        s.circle(x+bx,py-35,12,'white',color,1.4)
        s.text(x+bx,py-30,'ABC'[j],15,color,True,anchor='middle')
        if local>=.78:
            s.circle(x+570,py,30,'none',GOLD,1.5)
        s.text(x+22,704,'(W + d kᵀ) a' if col==0 else 'Wa + d (kᵀa)',30,INK,True)
        s.text(x+678,704,'same h′',20,color,True,anchor='end')
    s.text(800,558,'=',40,GOLD,True,anchor='middle')
    s.line((64,728),(1536,728),'#e0e8f3',1)
    s.text(80,760,'Change written to the state',22,INK,True)
    for i,cx in enumerate([790,1060,1340]):
        s.text(cx,760,f'Input {"ABC"[i]}',21,INK,True,anchor='middle')
        completed=(i<j)or(i==j and phase==2)
        if i==j:s.box(cx-85,773,170,83,'#f2f5fa',7)
        val=['+d','0','−d'][i] if completed else '·'
        s.text(cx,803,val,25,BLUE,True,anchor='middle')
        one=['+d','0','0'][i] if completed else '·'
        s.text(cx,845,one,23,MUT,False,anchor='middle')
        if i==2 and completed:s.text(cx+70,845,'≠',23,GOLD,True)
    s.text(80,803,'Stored rule = live policy',23,BLUE,True)
    s.text(80,845,'A single push on A, then no intervention',21,MUT)
    s.text(800,881,'Left → right: execution order   ·   vertical offset: activation change   ·   boats: input tokens',17,MUT,anchor='middle')
    s.footer('Compile the policy into weights—or execute it on each activation.',
        'Exact local linear writer • W = I • a one-shot push is not a policy • multi-layer matching requires the current intervened activations')
    return s

def verify():
    lhs=np.array([(W+np.outer(D,K))@v for v in STATES])
    rhs=np.array([W@v+D*(K@v) for v in STATES])
    assert np.array_equal(lhs,rhs)
    shifts=np.array([D*(K@v) for v in STATES])
    assert np.allclose(shifts,[[0,.7],[0,0],[0,-.7]])
    one=np.array([[0,.7],[0,0],[0,0]])
    assert np.array_equal(shifts[:2],one[:2]) and not np.array_equal(shifts[2],one[2])
    data={'classification':'exact linear-writer toy; not a Qwen trajectory',
          'states':STATES.tolist(),'W':W.tolist(),'k':K.tolist(),'d':D.tolist(),
          'weight_outputs':lhs.tolist(),'hook_outputs':rhs.tolist(),
          'shifts':shifts.tolist(),'one_shot_shifts':one.tolist(),
          'max_absolute_discrepancy':float(np.max(np.abs(lhs-rhs))),
          'motion_axes':{'horizontal':'execution order','vertical':'activation increment along d'}}
    (O/'model.json').write_text(json.dumps(data,indent=2)+'\n')

if __name__=='__main__':
    import sys
    verify();b.O=O
    for name in sys.argv[1:] or ['cover','mechanism']:
        b.save(name,globals()[name],0 if name=='cover' else 108,100)
    for label,t in [('A',.30),('B',.63),('C',.97)]:
        (O/f'mechanism-{label}.svg').write_text(mechanism(t).finish())
