#!/usr/bin/env python3
"""Rebuild selected article figures using the shared article KaTeX typography."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess

import atlas_v3 as v3
import atlas_v4 as v4
import atlas_v5 as v5
import geometry_v24 as geometry
import constraints_v24 as constraints
import measurements_v24 as measurements
import atlas_v24_common as common
import execution_v23 as execution
import math_typesetting as typeset

ROOT = Path(__file__).resolve().parent


def jobs():
    return [
        ('anatomy','v23/execution/execution',execution.figure,288),
        ('reconstruction','v24/measurements/reconstruction',measurements.reconstruction,0),
        ('controls','v24/measurements/controls',measurements.controls,0),
        ('fisher','v24/geometry/fisher',geometry.fisher,288),
        ('reachability','v24/constraints/reachability',constraints.reachability,288),
        ('duality','v24/geometry/duality',geometry.duality,288),
        ('efficiency','v24/geometry/efficiency',geometry.efficiency,288),
        ('coordinates','v24/constraints/coordinates',constraints.coordinates,288),
        ('impossibility','v24/constraints/impossibility',constraints.impossibility,288),
    ]


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--stills-only',action='store_true')
    parser.add_argument('--only',nargs='+',choices=[j[0] for j in jobs()])
    args=parser.parse_args()
    selected=[j for j in jobs() if not args.only or j[0] in args.only]
    snapshot = ROOT.parent.parent/'output/math-typesetting/before'
    snapshot.mkdir(parents=True,exist_ok=True)
    for _,stem,_,_ in selected:
        for suffix in ('.png','.svg'):
            source=ROOT/'assets'/(stem+suffix)
            target=snapshot/(stem.replace('/','-')+suffix)
            if source.exists() and not target.exists():shutil.copy2(source,target)
    with typeset.collect():
        for _,_,fn,frames in selected:
            fn()
            for i in range(frames):fn(i/(frames-1))
    typeset.prepare()
    # These checks concern only unchanged model/data definitions.
    geometry.verify();constraints.verify();measurements.verify();execution.verify()
    for fid,stem,fn,frames in selected:
        if args.stills_only or not frames:
            path=ROOT/'assets'/(stem+'.svg');path.write_text(fn().finish())
            subprocess.run(['rsvg-convert','-o',str(path.with_suffix('.png')),str(path)],check=True)
        elif fid=='anatomy':
            execution.save_still();execution.render_motion()
        else:common.render_motion((ROOT/'assets'/stem).parent,fid,fn)
        print('Rendered '+fid+(' (still)' if args.stills_only else ''),flush=True)
    result={'scope':'Selected-figure rebuild using shared KaTeX; current exact model/data checks passed.',
            'katex_runtime_sha256':typeset.RUNTIME_HASH,'render_scale':typeset.SCALE,
            'unique_labels':len(typeset.REQUESTS),'stills_only':args.stills_only,'selected':[j[0] for j in selected],
            'figures':{fid:{'path':stem+'.svg','sha256':hashlib.sha256((ROOT/'assets'/(stem+'.svg')).read_bytes()).hexdigest()} for fid,stem,_,_ in jobs()}}
    (ROOT/'assets/math/verification.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':main()
