"""Causal editorial plates: original Figma art + exact, reproducible toy models.

Revision 4 addresses a visual-audit finding: the earlier animation moved markers
without showing enough of the computation. These frames expose its dependencies.
The raster painting is generated in Figma; SVG text and geometry stay editable.
"""
from pathlib import Path
import io, json, math, subprocess
import numpy as np
from PIL import Image
import atlas_v3 as a

R=Path(__file__).resolve().parent
O=R/'assets/v4'; O.mkdir(exist_ok=True,parents=True)
SVG=a.SVG; BLUE=a.BLUE; LAV=a.LAV; GOLD=a.GOLD; INK=a.INK; MUT=a.MUT
TH=np.arange(8)*2*np.pi/8
A=np.array([np.cos(TH),np.sin(TH)])
k=np.array([.9,-.45]); d=np.array([.35,.8]); G=k@A
D=np.outer(d,k)
V=np.array([.35*np.cos(TH)+.38*np.cos(2*TH),.55*np.sin(TH)+.42*np.sin(3*TH)])
W=V@np.linalg.pinv(A); U=W@A; RES=V-U
P0=np.array([.62,.23,.15]); P1=np.array([.14,.26,.60])

def arrow(s,p,q,c=BLUE,w=3,opacity=1):
    p=np.array(p,dtype=float);q=np.array(q,dtype=float);v=q-p;ln=np.linalg.norm(v)
    if ln<.4:s.circle(*p,3,c);return
    v/=ln;n=np.array([-v[1],v[0]]);b=q-v*min(11,ln*.45)
    s.path([p,q],c,w,opacity=opacity)
    s.path([q,b+n*4.5,b-n*4.5],c,1,opacity=opacity,fill=c,close=True)

def field(s,cx,cy,scale=190):
    """A linear chart for a two-dimensional activation plane (not an embedding)."""
    def f(q):
        x,y=q;return np.array([cx+scale*(.93*x-.42*y),cy+scale*(.22*x+.55*y)])
    corners=np.array([[-1.45,-1.45],[1.45,-1.45],[1.45,1.45],[-1.45,1.45]])
    xy=np.array([f(q) for q in corners])
    for dy,op in [(22,.12),(11,.18),(0,.34)]:
        s.path(xy+[0,dy],'#cedaee',.6,opacity=op,fill='#d9e5f5',close=True)
    for z in np.linspace(-1.4,1.4,11):
        s.line(f((z,-1.45)),f((z,1.45)),'#9fb4d1',.65,opacity=.55)
        s.line(f((-1.45,z)),f((1.45,z)),'#bab6d6',.65,opacity=.55)
    return f

def cover(t=1):
    s=SVG('Steer the boat. Or change the river.',
          'Two ways to influence a trajectory—and a constraint that connects them.',
          '01 / ORIGINAL ALLEGORY')
    # Reframe only empty margins; the content bitmap remains an unretouched Figma output.
    s.a.append('<svg x="140" y="170" width="1320" height="727" viewBox="0 80 1536 846">')
    s.image(R/'art/river-and-rudder.png',0,0,1536,1024);s.a.append('</svg>')
    s.text(505,263,'Change the river',34,INK,True)
    s.lines(506,302,['A stored rule acts again','on each state that arrives.'],23,dy=28)
    s.path([(505,350),(440,350),(378,400)],BLUE,1.5)
    s.circle(378,400,5,GOLD)
    s.text(1080,275,'Steer one boat',34,INK,True)
    s.lines(1080,314,['An intervention changes','the present activation.'],23,dy=28)
    s.path([(1195,363),(1195,410),(1178,657)],BLUE,1.5)
    s.circle(1178,657,5,GOLD)
    s.footer('A weight edit stores a rule. An activation intervention executes a move.',
        'Original Figma-generated watercolor • a causal analogy, not a measured neural landscape • shared weights constrain the rule')
    return s

def anatomy(t=.23):
    s=SVG('One edit. Eight different pushes.',
          'The same stored matrix reads each input, then scales a single write direction.',
          '02 / EXACT LINEAR-WRITER MODEL')
    # Eight input states visited in order; holds allow each arithmetic step to be read.
    j=min(7,int(t*8)); av=A[:,j];g=float(G[j])
    s.number(88,227,1);s.text(121,236,'Read the state',28,INK,True)
    s.text(75,293,f'a = ({av[0]:+.2f}, {av[1]:+.2f})',30,BLUE)
    s.text(75,333,f'input {j+1} of 8',21,MUT)
    arrow(s,(440,283),(520,283),LAV,2)
    s.number(570,227,2);s.text(604,236,'Compute the gate',28,INK,True)
    s.text(560,293,f's = kᵀa = {g:+.2f}',31,BLUE)
    s.text(560,333,'k = (0.90, −0.45)',22,MUT)
    arrow(s,(930,283),(1015,283),LAV,2)
    s.number(1060,227,3);s.text(1094,236,'Write the move',28,INK,True)
    s.text(1050,293,'Δh = d · s',33,BLUE)
    s.text(1050,333,'d = (0.35, 0.80)',22,MUT)
    s.line((1335,350),(1335,245),'#d4dfed',2)
    arrow(s,(1335,300),(1335+60*g*.35,300-60*g*.8),GOLD,5)
    s.line((64,371),(1536,371),'#e0e8f3',1)
    s.text(95,420,'A constant push',29,INK,True)
    s.text(95,456,'the same vector at every state',23,MUT)
    s.text(855,420,'A rule stored in the weights',29,INK,True)
    s.text(855,456,'the direction is shared; the signed amount varies',23,MUT)
    for col,cx in enumerate([410,1190]):
        f=field(s,cx,653,165)
        for i in range(8):
            base=A[:,i];u=d*.65 if col==0 else d*G[i]
            p=f(base);q=f(base+u*.66)
            s.circle(*p,5,'#8196b4','white',1)
            arrow(s,p,q,('#a6b3c7' if col==0 else BLUE if G[i]>0 else LAV),3)
            if i==j:
                s.circle(*p,12,'white',GOLD,2);s.circle(*p,4,GOLD)
                arrow(s,p,q,GOLD,5)
                s.text(q[0]+12,q[1]-10,f'{(.65 if col==0 else G[i]):+.2f}',22,INK,True)
        s.text(cx,846,'Δhᵢ = 0.65 d' if col==0 else 'Δhᵢ = (d kᵀ) aᵢ = d (kᵀaᵢ)',28,INK,False,anchor='middle')
    s.footer('State dependence is in the multiplication—not in an extra controller.',
        'Eight unit-circle inputs • arrows scaled equally • exact toy arithmetic • does not establish a detector of natural loops')
    return s

def reachability(t=1):
    s=SVG('Eight wishes. One shared matrix.',
          'A direct steering field can ask for eight different moves. One linear writer must tie them together.',
          '06A / EXACT MULTI-INPUT PROJECTION')
    # Animate a common matrix, not independent arrow interpolation.
    alpha=min(1,t/0.78); wt=alpha*W; ut=wt@A
    norm=np.linalg.norm(V-ut)/np.linalg.norm(V)
    s.text(82,236,'The requested field',31,INK,True)
    s.text(82,277,'Eight independently chosen vectors vᵢ',23,MUT)
    s.text(860,236,'What one writer can deliver',31,INK,True)
    s.text(860,277,'Every arrow below is generated by the same ΔW.',23,MUT)
    for col,cx in enumerate([410,1190]):
        f=field(s,cx,528,172)
        for i in range(8):
            p=f(A[:,i]);target=f(A[:,i]+V[:,i]*.8)
            s.circle(*p,5,INK)
            if col==0:
                arrow(s,p,target,BLUE,3.7)
            else:
                actual=f(A[:,i]+ut[:,i]*.8)
                arrow(s,p,target,'#c3d0e1',1.7,opacity=.65)
                arrow(s,p,actual,LAV,4)
                s.line(actual,target,GOLD,2,'4 4')
                s.circle(*target,3,'white',GOLD,1)
    s.box(73,752,640,108,'#f2f6fb',12)
    s.text(95,790,'ΔW* = argmin Σᵢ ‖ΔW aᵢ − vᵢ‖²',29,BLUE)
    s.text(95,833,'Solution: ΔW* = V A⁺     (Euclidean toy metric)',23,MUT)
    s.text(868,761,f'ΔW = {alpha:.2f} × diag(0.35, 0.55)',27,INK)
    s.text(868,808,f'Relative residual: {norm:.1%}',28,INK,True)
    s.box(868,831,590,10,'#e5eaf3',5);s.box(868,831,590*norm,10,GOLD,5)
    s.footer('Even the best shared edit leaves a component it cannot write.',
        'Blue: desired • lavender: realized • gold: residual • all vectors computed • a Fisher metric changes which projection is closest')
    return s

def coordinates(t=.5):
    s=SVG('One distribution. Two ways of seeing it.',
          'Equal progress in probabilities produces unequal progress in log-odds.',
          '07 / EXACT SOFTMAX COORDINATE DUALITY')
    s.text(85,236,'Natural coordinates',31,INK,True)
    s.text(85,277,'h = (log p₁/p₃, log p₂/p₃)',26,MUT)
    s.text(940,236,'Expectation coordinates',31,INK,True)
    s.text(940,277,'η = (p₁, p₂);  p₃ = 1 − p₁ − p₂',26,MUT)
    f=lambda h:np.array([379+132*h[0],520-132*h[1]])
    # Minimal log-odds chart. Curved probability-coordinate grid is exactly transformed.
    s.box(80,310,610,390,'#f5f8fc',3)
    for z in [-2,-1,0,1,2]:
        s.line(f((z,-1.28)),f((z,1.28)),'#d6e1ef',.8)
        s.line(f((-2.1,z/2)),f((2.1,z/2)),'#d6e1ef',.8)
    for value in [.15,.25,.4,.6]:
        q=np.linspace(.07,1-value-.07,100)
        for swap in [False,True]:
            p=np.c_[np.full(len(q),value),q,1-value-q]
            if swap:p[:,[0,1]]=p[:,[1,0]]
            hh=np.log(p[:,:2]/p[:,2,None]);valid=(np.abs(hh[:,0])<2.05)&(np.abs(hh[:,1])<1.35)
            s.path([f(h)for h in hh[valid]],LAV,1,opacity=.45)
    # Affine simplex chart, with no negative or clamped probability values.
    verts=np.array([[960,675],[1490,675],[1225,330]])
    b=lambda p: p@verts
    s.path(verts,'#aabbd6',1.4,fill='#eff3fa',close=True)
    for z in [.2,.4,.6,.8]:
        for i in range(3):
            p=np.zeros(3);q=np.zeros(3);p[i]=q[i]=z;p[(i+1)%3]=1-z;q[(i+2)%3]=1-z
            s.line(b(p),b(q),'#c6cde3',.8)
    for point,lab in zip(verts,['p₁ = 1','p₂ = 1','p₃ = 1']):s.text(point[0],point[1]+(30 if point[1]>500 else -16),lab,21,MUT,anchor='middle')
    tt=np.linspace(0,1,101);ps=P0[None,:]+tt[:,None]*(P1-P0);hh=np.log(ps[:,:2]/ps[:,2,None])
    s.path([f(h)for h in hh],BLUE,3.5);s.path([b(p)for p in ps],BLUE,3.5)
    for j in [0,25,50,75,100]:
        for q in [f(hh[j]),b(ps[j])]:s.circle(*q,5,'white',BLUE,1.5)
    p=P0+t*(P1-P0);h=np.log(p[:2]/p[2]);lp=f(h);rp=b(p)
    for q in [lp,rp]:s.circle(*q,11,GOLD,'white',2)
    s.text(lp[0]-15,lp[1]-22,f't = {t:.2f}',22,INK,True,anchor='end')
    s.text(rp[0]+18,rp[1]-16,f't = {t:.2f}',22,INK,True)
    s.text(790,449,'same',24,MUT,False,anchor='middle');s.text(790,478,'state',24,MUT,False,anchor='middle')
    arrow(s,(720,507),(860,507),LAV,2)
    s.text(790,558,'η = ∇ψ(h)',27,INK,False,anchor='middle')
    s.text(80,747,'The shared probability state',25,INK,True)
    for i,(prob,col) in enumerate(zip(p,[BLUE,LAV,GOLD])):
        x=80+485*i;s.text(x,793,f'p{i+1} = {prob:.3f}',25,INK)
        s.box(x,811,385,16,'#e9eef6',6);s.box(x,811,385*prob,16,col,6)
    s.text(800,872,'η̇ = q     ⇔     ḣ = F(h)⁻¹ q',31,INK,False,anchor='middle')
    s.footer('The metric converts a straight probability path into its natural-coordinate motion.',
        'Exact three-class softmax • white ticks: equal time intervals • gold points and bars: the same state • not hidden-layer coordinates')
    return s

def save(name,fn,n=0,duration=100):
    svg=fn().finish();(O/f'{name}.svg').write_text(svg)
    subprocess.run(['rsvg-convert','-o',str(O/f'{name}.png'),str(O/f'{name}.svg')],check=True)
    if n:
        images=[]
        for i in range(n):
            # The last frame holds before resetting; do not play the computation backwards.
            raw=fn(i/(n-1)).finish().encode()
            png=subprocess.check_output(['rsvg-convert','-w','1120'],input=raw)
            images.append(Image.open(io.BytesIO(png)).convert('RGB'))
        # Derive the palette from multiple states so negative gates and residuals retain color.
        contact=Image.new('RGB',(1120,700*3),'white')
        for j,im in enumerate([images[0],images[n//2],images[-1]]):contact.paste(im,(0,700*j))
        palette=contact.quantize(colors=256)
        ims=[im.quantize(palette=palette,dither=Image.Dither.NONE)for im in images]
        ims[0].save(O/f'{name}.gif',save_all=True,append_images=ims[1:],duration=[duration]*(n-1)+[1400],loop=0,optimize=True)
        tmp=O/f'.{name}-frames';tmp.mkdir(exist_ok=True)
        for i,im in enumerate(images):im.save(tmp/f'{i:04}.png')
        subprocess.run(['ffmpeg','-y','-loglevel','error','-framerate',str(1000/duration),'-i',str(tmp/'%04d.png'),'-vf','tpad=stop_mode=clone:stop_duration=1.4','-c:v','libx264','-pix_fmt','yuv420p','-movflags','+faststart',str(O/f'{name}.mp4')],check=True)
        for p in tmp.iterdir():p.unlink()
        tmp.rmdir()
    print(name,flush=True)

def verify():
    assert np.allclose(D@A,d[:,None]*G)
    assert np.allclose(W,np.diag([.35,.55]))
    assert np.linalg.norm(RES@A.T)<1e-12
    assert np.linalg.norm(RES)>0
    p=P0+np.linspace(0,1,101)[:,None]*(P1-P0)
    h=np.log(p[:,:2]/p[:,2,None]);q=np.c_[np.exp(h),np.ones(len(p))];q/=q.sum(1)[:,None]
    assert np.allclose(q,p) and np.all(p>0)
    # Verify the animated path's differential identity at several interior points.
    for t in [.1,.4,.8]:
        p=P0+t*(P1-P0);eta=p[:2];F=np.diag(eta)-np.outer(eta,eta)
        q=(P1-P0)[:2];hdot=q/eta-(P1-P0)[2]/p[2]
        assert np.allclose(F@hdot,q)
    data={'classification':'exact mathematical toy; not a Qwen measurement',
          'A':A.tolist(),'V':V.tolist(),'W_star':W.tolist(),'realized':U.tolist(),
          'residual_fraction':float(np.linalg.norm(RES)/np.linalg.norm(V)),
          'normal_equation_residual':float(np.linalg.norm(RES@A.T)),
          'k':k.tolist(),'d':d.tolist(),'gates':G.tolist(),'p0':P0.tolist(),'p1':P1.tolist()}
    (O/'model.json').write_text(json.dumps(data,indent=2)+'\n')
    print('v4 computation and coordinate invariants passed',flush=True)

if __name__=='__main__':
    import sys
    verify()
    for name in sys.argv[1:] or ['cover','anatomy','reachability','coordinates']:
        save(name,globals()[name],0 if name=='cover' else 48,125)
