"""Shared scientific-plate style and deterministic, low-storage media renderer.

Frame functions take a normalized editorial time, not an optimization step.
All mathematical labels use the article's vendored KaTeX via atlas_v3.SVG.
"""
from pathlib import Path
import io
import subprocess
import numpy as np
from PIL import Image
import atlas_v3 as atlas

PAPER='#fffefc'
INK,MUT,BLUE,LAV,GOLD,CORAL='#263653','#72829a','#4c83be','#9892c7','#c6a164','#be7d79'

def ease(t):
    t=np.clip(t,0.,1.)
    return t*t*(3.-2.*t)

def plate(title, subtitle, tag):
    s=atlas.SVG(title,subtitle,tag)
    s.a[0]=s.a[0].replace('fill="#fff"',f'fill="{PAPER}"')
    s.a.append('<defs><radialGradient id="metric-wash"><stop stop-color="#b7cce6" stop-opacity=".24"/><stop offset="1" stop-color="#e6edf7" stop-opacity=".06"/></radialGradient><linearGradient id="violet-wash" x2="1" y2="1"><stop stop-color="#bcb7da" stop-opacity=".27"/><stop offset="1" stop-color="#f0edf6" stop-opacity=".08"/></linearGradient></defs>')
    return s

def arrow(s,p,q,color=GOLD,width=3.5,opacity=1):
    p,q=np.asarray(p,float),np.asarray(q,float)
    v=q-p;length=np.linalg.norm(v)
    if length<1.:return
    u=v/length;n=np.array([-u[1],u[0]])
    head=min(12.,length*.32)
    s.line(p,q,color,width,opacity=opacity)
    s.path([q,q-head*u+head*.38*n,q-head*u-head*.38*n],color,0,opacity=opacity,fill=color,close=True)

def dot(s,p,color=BLUE,r=10,hollow=False):
    s.circle(*p,r,PAPER if hollow else color,color if hollow else PAPER,2.4)

def ellipse(F,center=(0.,0.),cost=.5,n=160):
    vals,U=np.linalg.eigh(F)
    invroot=U@np.diag(1/np.sqrt(vals))@U.T
    a=np.linspace(0,2*np.pi,n)
    return np.asarray(center)+np.c_[np.cos(a),np.sin(a)]@invroot.T*np.sqrt(2*cost)

def footer(s,tex,note='',size=32):
    s.line((96,887),(1504,887),'#dce3ec',1)
    s.math(800,945,tex,size,INK,anchor='middle',max_width=1450)
    if note:s.text(800,984,note,17,MUT,anchor='middle')

def write_still(out,name,fn,t=1.):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    path=out/(name+'.svg');path.write_text(fn(t).finish())
    subprocess.run(['rsvg-convert','-o',str(path.with_suffix('.png')),str(path)],check=True)

def render_motion(out,name,fn,duration=12.,fps=24,static_t=1.):
    """MP4 and GIF share rendered frames; no optical interpolation or morphing.

    A final paper dissolve makes reset explicit, not reverse physical motion.
    No full-resolution frame sequence is left on disk.
    """
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    write_still(out,name,fn,static_t)
    proc=subprocess.Popen(['ffmpeg','-y','-v','error','-f','image2pipe','-vcodec','png','-framerate',str(fps),'-i','-','-an','-c:v','libx264','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(out/(name+'.mp4'))],stdin=subprocess.PIPE)
    gif=[]
    total=round(duration*fps)
    for i in range(total):
        t=i/(total-1)
        raw=fn(t).finish()
        # Fade the chart through paper at both loop boundaries; geometry is unchanged.
        opacity=float(min(ease(t/.045),1-ease((t-.94)/.06)))
        if opacity<1:
            raw=raw.replace('</svg>',f'<rect width="1600" height="1000" fill="{PAPER}" opacity="{1-opacity:.5f}"/></svg>')
        png=subprocess.check_output(['rsvg-convert','-w','1280'],input=raw.encode())
        proc.stdin.write(png)
        if i%2==0:
            im=Image.open(io.BytesIO(png)).convert('RGB');im.thumbnail((960,600));gif.append(im)
        if i%96==0:print(f'{name}: frame {i}/{total}',flush=True)
    proc.stdin.close()
    if proc.wait()!=0:raise RuntimeError('ffmpeg failed: '+name)
    sheet=Image.new('RGB',(960,2400),PAPER)
    for k,j in enumerate([8,len(gif)//3,2*len(gif)//3,len(gif)-12]):sheet.paste(gif[j],(0,k*600))
    palette=sheet.quantize(colors=224)
    frames=[im.quantize(palette=palette,dither=Image.Dither.NONE) for im in gif]
    durations=[80,80,90]*(len(frames)//3)+[80]*(len(frames)%3)
    # Exactly 12 fps in centiseconds over a full three-frame cycle.
    frames[0].save(out/(name+'.gif'),save_all=True,append_images=frames[1:],duration=durations,loop=0,optimize=True,disposal=1)
    sheet.save(out/(name+'-motion-check.jpg'),quality=90)
    print(f'{name}: still, MP4, GIF complete',flush=True)
