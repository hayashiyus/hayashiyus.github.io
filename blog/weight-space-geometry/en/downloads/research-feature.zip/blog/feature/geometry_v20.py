"""Geometry v20: three editable, equation-driven intuition plates.

All numbers are analytic toys. SVG paths, surfaces, prose and markers remain
editable; math retains its TeX source with embedded KaTeX glyph renderings.
PNG/GIF/MP4 are derived from the same frame function.
"""
from pathlib import Path
import io, json, math, subprocess, sys
import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parent))
import atlas_v3 as atlas

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "assets" / "v20" / "geometry"
OUT.mkdir(parents=True, exist_ok=True)
INK, MUT, BLUE, LAV, GOLD = "#263653", "#71819a", "#4b83c7", "#9b98d3", "#d2a252"
WASHI = "#fffefc"

# Exact toy models shared with atlas_v4.reachability.
TH = np.arange(8) * 2 * np.pi / 8
A8 = np.array([np.cos(TH), np.sin(TH)])
V8 = np.array([.35*np.cos(TH) + .38*np.cos(2*TH),
               .55*np.sin(TH) + .42*np.sin(3*TH)])
W8 = V8 @ np.linalg.pinv(A8)
U8 = W8 @ A8
R8 = V8 - U8

F = np.array([[2., .5], [.5, 1.]])
v = np.array([.8, 1.4])
b = np.array([1., .8])
c = .6
F_INV = np.linalg.inv(F)
d_star = c * F_INV @ b / (b @ F_INV @ b)
d_euclid = c * b / (b @ b)

def plate(title, tag):
    s=atlas.SVG(title,'',tag)
    s.a[0]=s.a[0].replace('fill="#fff"',f'fill="{WASHI}"')
    s.a.append('<defs><radialGradient id="bluewash"><stop stop-color="#b7cce8" stop-opacity=".72"/><stop offset="1" stop-color="#dbe6f3" stop-opacity=".28"/></radialGradient><radialGradient id="violetwash"><stop stop-color="#c4bbdf" stop-opacity=".72"/><stop offset="1" stop-color="#e1dcee" stop-opacity=".28"/></radialGradient></defs>')
    return s

def arrow(s,p,q,color=BLUE,width=3,opacity=1):
    p,q=np.asarray(p,float),np.asarray(q,float);vec=q-p;length=np.linalg.norm(vec)
    if length<1e-7:s.circle(*p,2.5,color,'none',0);return
    d=vec/length;n=np.array([-d[1],d[0]]);end=q-d*min(12,length*.3)
    s.path([p,q],color,width,opacity=opacity)
    s.path([q,end+n*4.5,end-n*4.5],color,1,opacity=opacity,fill=color,close=True)

def camera(points,target=(160,265,1210,535),zscale=.62):
    def raw(q):
        q=np.asarray(q,float)
        return np.stack((.83*q[...,0]-.56*q[...,1],.26*q[...,0]+.36*q[...,1]-zscale*q[...,2]),axis=-1)
    r=raw(np.asarray(points));lo=r.min(0);hi=r.max(0);x,y,w,h=target
    return lambda q: np.array([x,y])+((raw(q)-lo)/(hi-lo))*np.array([w,h])

def bowl(s,F,center,rmax,target,zscale=.62):
    # The domain is an ellipse of equal quadratic cost, not a rectangular crop.
    eig,U=np.linalg.eigh(F);invroot=U@np.diag(1/np.sqrt(eig))@U.T
    rr=np.linspace(0,rmax,23);tt=np.linspace(0,2*np.pi,65)
    R,T=np.meshgrid(rr,tt,indexing='ij')
    D=np.stack((R*np.cos(T),R*np.sin(T)),axis=-1)@invroot.T
    XY=D+np.asarray(center);Z=.5*R**2;P=np.dstack((XY,Z))
    cam=camera(P.reshape(-1,3),target,zscale);Q=cam(P)
    faces=[]
    for i in range(len(rr)-1):
        for j in range(len(tt)-1):
            ids=[(i,j),(i,j+1),(i+1,j+1),(i+1,j)]
            points=np.array([P[a,b]for a,b in ids]);depth=points[:,0].mean()+points[:,1].mean()
            faces.append((depth,ids,i))
    for _,ids,i in sorted(faces,key=lambda a:a[0]):
        f=(i+.5)/(len(rr)-1);q=[Q[a,b]for a,b in ids]
        # Muted glaze, fading toward the rim. Geometry remains fully editable.
        col=np.round(np.array([193,203,227])*(1-f*.55)+np.array([249,249,252])*f*.55).astype(int)
        s.path(q,'none',0,opacity=.68,fill=f'rgb({col[0]},{col[1]},{col[2]})',close=True)
    for i in range(3,len(rr),3):s.path(Q[i],LAV,.8,opacity=.52)
    for j in range(0,len(tt)-1,4):s.path(Q[:,j],BLUE,.65,opacity=.24)
    s.path(Q[-1],LAV,1,opacity=.30)
    return cam,invroot

def point(s,p,color,r=9):
    s.circle(*p,r+4,'#fffefc','none',0);s.circle(*p,r,color,'#fffefc',1.4)

def leader(s,p,label,offset,color=INK):
    q=np.asarray(p)+np.asarray(offset);anchor='start'if offset[0]>=0 else'end'
    s.line(p,q,color,1,opacity=.55);s.text(q[0]+(7 if anchor=='start'else -7),q[1]+5,label,24,color,False,anchor=anchor)

def reachability(t=1.):
    s=plate('Eight requests. One shared rule.','EXACT MODEL / REACHABILITY')
    # Identical charts, separated vertically; correspondence is not a residual.
    def chart(p,level):
        p=np.asarray(p);return np.stack((800+270*(.84*p[...,0]-.56*p[...,1]),level+95*(.30*p[...,0]+.44*p[...,1])),axis=-1)
    corners=np.array([[-1.7,-1.7],[1.7,-1.7],[1.7,1.7],[-1.7,1.7]])
    for i in range(8):s.line(chart(A8[:,i],385),chart(A8[:,i],675),'#a5b3c8',1,'4 7',.5)
    for level,fill in [(675,'violetwash'),(385,'bluewash')]:
        s.path(chart(corners,level),LAV,1,opacity=.9,fill=f'url(#{fill})',close=True)
        for a in np.linspace(-1.7,1.7,13):
            s.path(chart(np.array([[a,-1.7],[a,1.7]]),level),'#aebdd3',.7,opacity=.45)
            s.path(chart(np.array([[-1.7,a],[1.7,a]]),level),'#aebdd3',.7,opacity=.45)
    alpha=float(np.clip(t,0,1));alpha=alpha*alpha*(3-2*alpha);U=alpha*U8
    for i in range(8):
        a=A8[:,i];target=a+.68*V8[:,i];actual=a+.68*U[:,i]
        top=chart(a,385);bot=chart(a,675);goal=chart(target,675);got=chart(actual,675)
        s.circle(*top,4,'white',INK,1);s.circle(*bot,4,'white',INK,1)
        arrow(s,top,chart(target,385),BLUE,4)
        arrow(s,bot,goal,'#b6bfce',1.2,.45)
        arrow(s,bot,got,LAV,4)
        s.line(got,goal,GOLD,2.2,'5 4');s.circle(*goal,3.5,'white',GOLD,1)
    s.text(110,280,'desired steering',27,BLUE,True)
    s.text(110,570,'one weight edit',27,LAV,True)
    s.text(1180,825,'unreachable part',23,GOLD)
    s.line((1130,817),(1165,817),GOLD,2.2,'5 4')
    s.math(800,926,r'\Delta W^*=VA^+',34,INK,anchor='middle')
    return s

def duality(t=1.):
    s=plate('The closest move you can actually make.','EXACT MODEL / FISHER PROJECTION')
    cam,invroot=bowl(s,F,v,2.15,(145,260,1240,550),.68)
    cost=lambda d:.5*np.einsum('...i,ij,...j->...',np.asarray(d)-v,F,np.asarray(d)-v)
    xs=np.linspace(-.6,2.5,260);pts=np.c_[xs,np.zeros_like(xs)];z=cost(pts);pts=pts[z<=2.15**2/2];z=cost(pts)
    # Faint floor trace and height drops link location to cost.
    s.path(cam(np.c_[pts,np.zeros(len(pts))]),BLUE,1.2,dash='5 6',opacity=.35)
    s.path(cam(np.c_[pts,z]),BLUE,4.4)
    opt=np.array([1.15,0.]);eu=np.array([.8,0.]);desired=cam(np.r_[v,0]);po=cam(np.r_[opt,cost(opt)]);pe=cam(np.r_[eu,cost(eu)])
    for d in [opt,eu]:s.line(cam(np.r_[d,0]),cam(np.r_[d,cost(d)]),LAV,1.2,'4 5',.6)
    point(s,desired,GOLD,9);point(s,po,BLUE,10);s.circle(*pe,6,'#fffefc',MUT,2)
    a=np.clip(t,0,1);a=a*a*(3-2*a);mov=np.array([-.10+(1.15+.10)*a,0.]);pm=cam(np.r_[mov,cost(mov)])
    point(s,pm,BLUE,8)
    leader(s,desired,'requested',(-120,55),GOLD)
    leader(s,po,'closest reachable',(60,72),BLUE)
    leader(s,pe,'Euclidean',(-80,-45),MUT)
    s.text(110,220,'height = mismatch cost',23,MUT)
    s.math(800,926,r'\frac{1}{2}(u-v)^\top F(u-v)',32,INK,anchor='middle')
    return s

def efficiency(t=1.):
    s=plate('The same effect can cost less.','EXACT MODEL / NATURAL DIRECTION')
    cam,invroot=bowl(s,F,np.zeros(2),1.25,(145,260,1240,550),1.10)
    cost=lambda d:.5*np.einsum('...i,ij,...j->...',d,F,d)
    tangent=np.array([b[1],-b[0]])/np.linalg.norm(b)
    u=np.linspace(-1.1,1.1,260);pts=d_star+u[:,None]*tangent;valid=cost(pts)<1.25**2/2;pts=pts[valid]
    s.path(cam(np.c_[pts,np.zeros(len(pts))]),GOLD,1.4,dash='5 6',opacity=.5)
    s.path(cam(np.c_[pts,cost(pts)]),GOLD,4.5)
    alt=d_star+.65*tangent;other=cam(np.r_[alt,cost(alt)]);best=cam(np.r_[d_star,cost(d_star)])
    for d in [alt,d_star]:
        s.line(cam(np.r_[d,0]),cam(np.r_[d,cost(d)]),MUT,1.2,'4 5',.6)
        s.circle(*cam(np.r_[d,0]),3,MUT,'none',0)
    # A true equal-cost contour touches the equal-effect line at its minimum.
    tt=np.linspace(0,2*np.pi,161);contour=np.c_[np.cos(tt),np.sin(tt)]@invroot.T*np.sqrt(2*cost(d_star))
    s.path(cam(np.c_[contour,np.full(len(tt),cost(d_star))]),LAV,2,opacity=.7)
    s.circle(*other,7,'#fffefc',MUT,2);point(s,best,BLUE,10)
    a=np.clip(t,0,1);a=a*a*(3-2*a);d=(1-a)*alt+a*d_star;point(s,cam(np.r_[d,cost(d)]),GOLD,7)
    leader(s,other,'another edit',(55,-35),MUT)
    leader(s,best,'cheapest',(65,75),BLUE)
    # Gold line, rather than a paragraph, carries the shared-effect constraint.
    label=cam(np.r_[pts[35],cost(pts[35])]);leader(s,label,'same effect',(-100,-40),GOLD)
    s.text(110,220,'height = output change',23,MUT)
    s.math(800,926,r'b^\top d=c\qquad\text{cost}=\frac{1}{2}d^\top Fd',30,INK,anchor='middle')
    return s

def save_media(name,fn,frames=96):
    final=fn(1).finish();(OUT/f'{name}.svg').write_text(final)
    subprocess.run(['rsvg-convert','-o',str(OUT/f'{name}.png'),str(OUT/f'{name}.svg')],check=True)
    tmp=OUT/f'.{name}-frames';tmp.mkdir(exist_ok=True);ims=[]
    for i in range(frames):
        raw=fn(i/(frames-1)).finish().encode();png=subprocess.check_output(['rsvg-convert','-w','1120'],input=raw)
        (tmp/f'{i:04d}.png').write_bytes(png)
        if i%2==0:ims.append(Image.open(io.BytesIO(png)).convert('RGB'))
    # The GIF samples the same motion; pause at the same solution.
    ims[-1]=Image.open(io.BytesIO(subprocess.check_output(['rsvg-convert','-w','1120'],input=final.encode()))).convert('RGB')
    contact=Image.new('RGB',(1120,2100),WASHI)
    for k,j in enumerate((0,len(ims)//2,len(ims)-1)):contact.paste(ims[j],(0,700*k))
    pal=contact.quantize(colors=192);qs=[im.quantize(palette=pal,dither=Image.Dither.NONE)for im in ims]
    durations=[80,80,90]*16;durations[-1]+=2000
    qs[0].save(OUT/f'{name}.gif',save_all=True,append_images=qs[1:],duration=durations,loop=0,optimize=True)
    subprocess.run(['ffmpeg','-y','-loglevel','error','-framerate','24','-i',str(tmp/'%04d.png'),'-vf','tpad=stop_mode=clone:stop_duration=2','-c:v','libx264','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',str(OUT/f'{name}.mp4')],check=True)
    for p in tmp.iterdir():p.unlink()
    tmp.rmdir()

def verify():
    assert np.allclose(W8, np.diag([.35, .55]))
    assert np.allclose(U8, W8 @ A8)
    assert np.linalg.norm(R8 @ A8.T) < 1e-12
    assert np.isclose(np.linalg.norm(R8)/np.linalg.norm(V8), .6558522160191071)
    assert np.allclose(F, F.T) and np.all(np.linalg.eigvalsh(F) > 0)
    assert np.allclose(d_star, [0.24324324324324326, 0.44594594594594594])
    assert np.isclose(b @ d_star, c) and np.isclose(b @ d_euclid, c)
    assert .5*d_star@F@d_star < .5*d_euclid@F@d_euclid
    data = {"classification":"exact analytic toys; no empirical model claim",
            "reachability":{"A":A8.tolist(),"V":V8.tolist(),"W_star":W8.tolist(),"realized":U8.tolist(),"residual":R8.tolist(),"residual_fraction":float(np.linalg.norm(R8)/np.linalg.norm(V8))},
            "duality":{"F":F.tolist(),"v":v.tolist(),"reachable_point":[1.15,0.0],"euclidean_point":[.8,0.0]},
            "efficiency":{"F":F.tolist(),"b":b.tolist(),"c":c,"d_star":d_star.tolist(),"d_euclid":d_euclid.tolist(),"cost_star":float(.5*d_star@F@d_star),"cost_euclid":float(.5*d_euclid@F@d_euclid)}}
    (OUT/"model.json").write_text(json.dumps(data, indent=2)+"\n")
    print("geometry v20 numerical checks passed")

if __name__ == "__main__":
    verify()
    for name, fn in (("reachability", reachability), ("duality", duality), ("efficiency", efficiency)):
        save_media(name, fn)
